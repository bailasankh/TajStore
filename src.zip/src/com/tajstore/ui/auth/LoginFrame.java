package com.tajstore.ui.auth;

import com.tajstore.model.UserAccount;
import com.tajstore.service.AuthService;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui1.MainFrame;
import com.tajstore.ui.components.BaseFrame;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;
import com.tajstore.util.Validator;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginFrame extends BaseFrame {

    private final AuthService authService = new AuthService();

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheck;
    private PrimaryButton loginButton;
    private SecondaryButton registerButton;

    private int shimmerX = -220;

    private static final Color BG_TOP = new Color(7, 4, 3);
    private static final Color BG_BOTTOM = new Color(18, 10, 6);
    private static final Color GOLD = new Color(212, 175, 55);
    private static final Color GOLD_LIGHT = new Color(245, 225, 170);
    private static final Color TEXT_MAIN = new Color(245, 238, 230);
    private static final Color TEXT_SOFT = new Color(205, 188, 160);
    private static final Color CARD_BG = new Color(0, 0, 0, 165);
    private static final Color FIELD_BG = new Color(38, 24, 16);

    public LoginFrame() {
        super("Taj Store - Login", 920, 760);
        initUI();
        setResizable(true);
        setMinimumSize(new Dimension(820, 700));
    }

    @Override
    protected void initUI() {
        JPanel root = new JPanel(new BorderLayout(0, 20)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                int width = getWidth();
                int height = getHeight();

                GradientPaint background = new GradientPaint(
                        0, 0, BG_TOP,
                        0, height, BG_BOTTOM
                );
                g2d.setPaint(background);
                g2d.fillRect(0, 0, width, height);

                Point center = new Point(width / 2, height / 3);
                float radius = Math.max(width, height) * 0.95f;
                float[] dist = {0.0f, 0.28f, 0.7f, 1.0f};
                Color[] colors = {
                        new Color(110, 68, 22, 170),
                        new Color(60, 32, 10, 90),
                        new Color(20, 10, 5, 35),
                        new Color(0, 0, 0, 0)
                };
                RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
                g2d.setPaint(spotlight);
                g2d.fillRect(0, 0, width, height);

                int haloX = width / 2;
                int haloY = height / 2 - 20;
                int haloRadius = 280;
                RadialGradientPaint halo = new RadialGradientPaint(
                        new Point(haloX, haloY),
                        haloRadius,
                        new float[]{0.0f, 0.45f, 1.0f},
                        new Color[]{
                                new Color(224, 190, 78, 50),
                                new Color(180, 140, 40, 16),
                                new Color(0, 0, 0, 0)
                        }
                );
                g2d.setPaint(halo);
                g2d.fillOval(haloX - haloRadius, haloY - haloRadius, haloRadius * 2, haloRadius * 2);

                GradientPaint shimmer = new GradientPaint(
                        shimmerX, 0, new Color(255, 235, 180, 0),
                        shimmerX + 120, 0, new Color(255, 220, 140, 18),
                        true
                );
                g2d.setPaint(shimmer);
                g2d.fillRect(0, 0, width, height);

                g2d.dispose();
            }
        };

        root.setOpaque(false);
        root.setBorder(BorderFactory.createEmptyBorder(26, 34, 28, 34));

        root.add(buildHeader(), BorderLayout.NORTH);
        root.add(buildCenterArea(), BorderLayout.CENTER);
        root.add(buildFooter(), BorderLayout.SOUTH);

        setContentPane(root);
        startBackgroundAnimation(root);
    }

    private JPanel buildHeader() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel brand = new JLabel("TAJ STORE");
        brand.setAlignmentX(Component.CENTER_ALIGNMENT);
        brand.setFont(new Font("Serif", Font.BOLD, 42));
        brand.setForeground(GOLD);

        JLabel line = new JLabel("━━━━━━━━━━━━━━━━━━━━");
        line.setAlignmentX(Component.CENTER_ALIGNMENT);
        line.setFont(new Font("Serif", Font.PLAIN, 18));
        line.setForeground(new Color(170, 130, 45));

        JLabel subtitle = new JLabel("Luxury Gold Shop Management System");
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 18));
        subtitle.setForeground(new Color(235, 222, 205));

        panel.add(Box.createVerticalStrut(6));
        panel.add(brand);
        panel.add(Box.createVerticalStrut(4));
        panel.add(line);
        panel.add(Box.createVerticalStrut(8));
        panel.add(subtitle);

        return panel;
    }

    private JPanel buildCenterArea() {
        JPanel center = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        center.setOpaque(false);
        center.add(buildCenterCard());
        return center;
    }

    private JPanel buildCenterCard() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setPreferredSize(new Dimension(560, 470));
        wrapper.setMaximumSize(new Dimension(560, 470));

        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 28, 28);

                g2.setColor(new Color(212, 175, 55, 115));
                g2.setStroke(new BasicStroke(1.4f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 28, 28);

                g2.setColor(new Color(255, 230, 170, 35));
                g2.drawRoundRect(8, 8, getWidth() - 17, getHeight() - 17, 22, 22);

                g2.dispose();
                super.paintComponent(g);
            }
        };

        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(34, 38, 32, 38));

        SectionTitle sectionTitle = new SectionTitle("Login", "Sign in to access your dashboard");

        usernameField = new JTextField();
        passwordField = new JPasswordField();
        showPasswordCheck = new JCheckBox("Show Password");

        styleLuxuryField(usernameField);
        styleLuxuryField(passwordField);

        showPasswordCheck.setOpaque(false);
        showPasswordCheck.setForeground(TEXT_SOFT);
        showPasswordCheck.setFont(UIStyle.FONT_BODY);
        showPasswordCheck.setAlignmentX(Component.LEFT_ALIGNMENT);
        showPasswordCheck.setFocusPainted(false);
        showPasswordCheck.addActionListener(e ->
                passwordField.setEchoChar(showPasswordCheck.isSelected() ? (char) 0 : '\u2022')
        );
        passwordField.setEchoChar('\u2022');

        loginButton = new PrimaryButton("LOGIN");
        registerButton = new SecondaryButton("GO TO REGISTER");

        stylePrimaryActionButton(loginButton);
        styleSecondaryActionButton(registerButton);

        loginButton.addActionListener(e -> doLogin());
        registerButton.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new RegisterFrame().setVisible(true));
        });

        JLabel forgotLabel = new JLabel("Forgot Password?");
        forgotLabel.setForeground(new Color(188, 164, 128));
        forgotLabel.setFont(UIStyle.FONT_SMALL);
        forgotLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        forgotLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                forgotLabel.setForeground(GOLD_LIGHT);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                forgotLabel.setForeground(new Color(188, 164, 128));
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                handleForgotPassword();
            }
        });

        JPanel optionsRow = new JPanel(new GridLayout(1, 2, 10, 0));
        optionsRow.setOpaque(false);
        optionsRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel leftBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        leftBox.setOpaque(false);
        leftBox.add(showPasswordCheck);

        JPanel rightBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightBox.setOpaque(false);
        rightBox.add(forgotLabel);

        optionsRow.add(leftBox);
        optionsRow.add(rightBox);

        card.add(sectionTitle);
        card.add(Box.createVerticalStrut(22));
        card.add(createLabeledField("Username", usernameField));
        card.add(Box.createVerticalStrut(16));
        card.add(createLabeledField("Password", passwordField));
        card.add(Box.createVerticalStrut(14));
        card.add(optionsRow);
        card.add(Box.createVerticalStrut(26));
        card.add(loginButton);
        card.add(Box.createVerticalStrut(12));
        card.add(registerButton);

        wrapper.add(card, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel buildFooter() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setOpaque(false);

        JLabel footer = new JLabel("Secure login with role-based access");
        footer.setFont(UIStyle.FONT_SMALL);
        footer.setForeground(new Color(180, 160, 130));

        panel.add(footer);
        return panel;
    }

    private JPanel createLabeledField(String labelText, javax.swing.JComponent field) {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 7));
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 78));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(TEXT_MAIN);

        panel.add(label);
        panel.add(field);

        return panel;
    }

    private void styleLuxuryField(javax.swing.JComponent field) {
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        field.setPreferredSize(new Dimension(430, 48));
        field.setBackground(FIELD_BG);
        field.setForeground(TEXT_MAIN);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(160, 120, 55), 1, true),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));

        if (field instanceof JTextField) {
            ((JTextField) field).setCaretColor(GOLD);
            ((JTextField) field).setFont(UIStyle.FONT_BODY);
        }

        if (field instanceof JPasswordField) {
            ((JPasswordField) field).setCaretColor(GOLD);
            ((JPasswordField) field).setFont(UIStyle.FONT_BODY);
        }
    }

    private void stylePrimaryActionButton(PrimaryButton button) {
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        button.setPreferredSize(new Dimension(430, 50));
        button.setFont(new Font("SansSerif", Font.BOLD, 15));
        button.setBackground(GOLD);
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
    }

    private void styleSecondaryActionButton(SecondaryButton button) {
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        button.setPreferredSize(new Dimension(430, 48));
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(new Color(18, 12, 8));
        button.setForeground(GOLD_LIGHT);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(150, 115, 45), 1, true));
    }

    private void startBackgroundAnimation(JPanel root) {
        Timer timer = new Timer(40, e -> {
            shimmerX += 4;
            if (shimmerX > getWidth() + 180) {
                shimmerX = -220;
            }
            root.repaint();
        });
        timer.start();
    }

    private void doLogin() {
        try {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            Validator.validateUsername(username);
            Validator.validatePassword(password);

            UserAccount user = authService.login(username, password);

            MessageUtil.showSuccess(this, "Welcome, " + user.getFullName() + " (" + user.getRoleName() + ")");
            dispose();
            new MainFrame().setVisible(true);

        } catch (Exception ex) {
            MessageUtil.showError(this, ex.getMessage());
        }
    }

    private void handleForgotPassword() {
        JPanel resetPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        resetPanel.setOpaque(false);

        JTextField userField = new JTextField();
        styleLuxuryField(userField);
        resetPanel.add(new JLabel("Enter your Username:"));
        resetPanel.add(userField);

        int result = JOptionPane.showConfirmDialog(
                this,
                resetPanel,
                "Reset Password",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            String uname = userField.getText().trim();
            if (!uname.isEmpty()) {
                try {
                    String tempSalt = com.tajstore.security.PasswordHasher.generateSalt();
                    String tempHash = com.tajstore.security.PasswordHasher.hash("123456", tempSalt);

                    com.tajstore.dao.UserAccountDao userDao = new com.tajstore.dao.UserAccountDao();
                    userDao.resetPassword(uname, tempHash, tempSalt);

                    MessageUtil.showSuccess(
                            this,
                            "Password reset successfully for: " + uname
                                    + "\nYour temporary password is: 123456"
                                    + "\nPlease change it after login."
                    );
                } catch (Exception ex) {
                    MessageUtil.showError(this, "Username not found or error: " + ex.getMessage());
                }
            }
        }
    }
}