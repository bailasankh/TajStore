package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;

import java.math.BigDecimal;
import java.sql.*;

public class SalesDao {

    public int createSale(
            int customerId,
            int employeeId,
            int itemId,
            int quantity,
            BigDecimal salePrice,
            BigDecimal goldPriceAtSale,
            BigDecimal makingCostAtSale,
            int paymentMethodId,
            BigDecimal paymentAmount,
            String paymentNote
    ) {
        Connection connection = null;

        try {
            connection = ConnectionManager.getConnection();
            connection.setAutoCommit(false);

            int invoiceId = insertInvoice(connection, customerId, employeeId, salePrice, paymentAmount);
            insertInvoiceDetail(connection, invoiceId, itemId, quantity, salePrice, goldPriceAtSale, makingCostAtSale);
            insertPayment(connection, invoiceId, paymentMethodId, paymentAmount, paymentNote);
            decreaseInventory(connection, itemId, quantity);
            insertInventoryMovement(connection, itemId, invoiceId, quantity);

            connection.commit();
            return invoiceId;

        } catch (Exception e) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (Exception ignored) {
                }
            }
            throw new RuntimeException("Failed to create sale transaction.", e);
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(true);
                    connection.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private int insertInvoice(Connection connection, int customerId, int employeeId,
                              BigDecimal totalAmount, BigDecimal paymentAmount) throws Exception {
        String status;
        int comparison = paymentAmount.compareTo(totalAmount);

        if (comparison >= 0) {
            status = "PAID";
        } else if (paymentAmount.compareTo(BigDecimal.ZERO) > 0) {
            status = "PARTIAL";
        } else {
            status = "UNPAID";
        }

        String sql = "INSERT INTO invoice (customer_id, employee_id, total_amount, status) VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, customerId);
            statement.setInt(2, employeeId);
            statement.setBigDecimal(3, totalAmount);
            statement.setString(4, status);

            statement.executeUpdate();

            try (ResultSet rs = statement.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        throw new RuntimeException("Failed to create invoice.");
    }

    private void insertInvoiceDetail(Connection connection, int invoiceId, int itemId, int quantity,
                                     BigDecimal salePrice, BigDecimal goldPriceAtSale,
                                     BigDecimal makingCostAtSale) throws Exception {
        String sql = "INSERT INTO invoice_details (invoice_id, item_id, quantity, sale_price, gold_price_at_sale, making_cost_at_sale) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            statement.setInt(2, itemId);
            statement.setInt(3, quantity);
            statement.setBigDecimal(4, salePrice);
            statement.setBigDecimal(5, goldPriceAtSale);
            statement.setBigDecimal(6, makingCostAtSale);
            statement.executeUpdate();
        }
    }

    private void insertPayment(Connection connection, int invoiceId, int paymentMethodId,
                               BigDecimal paymentAmount, String paymentNote) throws Exception {
        if (paymentAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return;
        }

        String sql = "INSERT INTO payment (invoice_id, method_id, amount, note) VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, invoiceId);
            statement.setInt(2, paymentMethodId);
            statement.setBigDecimal(3, paymentAmount);
            statement.setString(4, paymentNote);
            statement.executeUpdate();
        }
    }

    private void decreaseInventory(Connection connection, int itemId, int quantityToSell) throws Exception {
        String checkSql = "SELECT qty FROM inventory WHERE item_id = ?";
        try (PreparedStatement check = connection.prepareStatement(checkSql)) {
            check.setInt(1, itemId);

            try (ResultSet rs = check.executeQuery()) {
                if (!rs.next()) {
                    throw new IllegalArgumentException("Inventory record not found for selected item.");
                }

                int qty = rs.getInt("qty");
                if (qty < quantityToSell) {
                    throw new IllegalArgumentException("Selected quantity is greater than the available stock.");
                }
            }
        }

        String updateSql = "UPDATE inventory SET qty = qty - ? WHERE item_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(updateSql)) {
            statement.setInt(1, quantityToSell);
            statement.setInt(2, itemId);
            statement.executeUpdate();
        }
    }

    private void insertInventoryMovement(Connection connection, int itemId, int invoiceId, int quantity) throws Exception {
        String sql = "INSERT INTO inventory_movement (item_id, move_type, ref_invoice_id, note) VALUES (?, 'OUT', ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, itemId);
            statement.setInt(2, invoiceId);
            statement.setString(3, "Sold to customer - Qty: " + quantity);
            statement.executeUpdate();
        }
    }
}
