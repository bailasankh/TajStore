package com.tajstore.theme;

public enum ThemeMode {
    LIGHT,
    DARK
}