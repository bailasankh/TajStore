package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PrimaryButton extends JButton {

    public PrimaryButton(String text) {
        super(text);
        initStyle();
    }

    private void initStyle() {
        UIStyle.stylePrimaryButton(this);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(brighten(ThemeManager.getTheme().getPrimary(), 18));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(ThemeManager.getTheme().getPrimary());
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(ThemeManager.getTheme().getPrimaryDark());
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(contains(e.getPoint())
                            ? brighten(ThemeManager.getTheme().getPrimary(), 18)
                            : ThemeManager.getTheme().getPrimary());
                }
            }
        });
    }

    private Color brighten(Color base, int amount) {
        return new Color(
                Math.min(base.getRed() + amount, 255),
                Math.min(base.getGreen() + amount, 255),
                Math.min(base.getBlue() + amount, 255)
        );
    }
}
