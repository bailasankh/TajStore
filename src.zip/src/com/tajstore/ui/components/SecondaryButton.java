package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SecondaryButton extends JButton {

    public SecondaryButton(String text) {
        super(text);
        initStyle();
    }

    private void initStyle() {
        UIStyle.styleSecondaryButton(this);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(brighten(ThemeManager.getTheme().getSurfaceAlt(), 10));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(ThemeManager.getTheme().getSurfaceAlt());
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(ThemeManager.getTheme().getSurface());
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (isEnabled()) {
                    setBackground(contains(e.getPoint())
                            ? brighten(ThemeManager.getTheme().getSurfaceAlt(), 10)
                            : ThemeManager.getTheme().getSurfaceAlt());
                }
            }
        });
    }

    private Color brighten(Color base, int amount) {
        return new Color(
                Math.min(base.getRed() + amount, 255),
                Math.min(base.getGreen() + amount, 255),
                Math.min(base.getBlue() + amount, 255)
        );
    }
}
