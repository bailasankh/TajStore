package com.tajstore.service;

import com.tajstore.dao.PurchaseDao;
import com.tajstore.dao.PurchaseSupportDao;
import com.tajstore.model.Employee;
import com.tajstore.model.PurchaseItemOption;
import com.tajstore.model.Supplier;

import java.math.BigDecimal;
import java.util.List;

public class PurchaseService {

    private final PurchaseSupportDao purchaseSupportDao;
    private final PurchaseDao purchaseDao;

    public PurchaseService() {
        this.purchaseSupportDao = new PurchaseSupportDao();
        this.purchaseDao = new PurchaseDao();
    }

    public List<Supplier> getSuppliers() {
        return purchaseSupportDao.findAllSuppliers();
    }

    public List<Employee> getEmployees() {
        return purchaseSupportDao.findAllEmployees();
    }

    public List<PurchaseItemOption> getItems() {
        return purchaseSupportDao.findAllItems();
    }

    public int createPurchase(
            Supplier supplier,
            Employee employee,
            PurchaseItemOption item,
            String quantityText,
            String pricePerUnitText
    ) {
        if (supplier == null) {
            throw new IllegalArgumentException("Please select a supplier.");
        }

        if (employee == null) {
            throw new IllegalArgumentException("Please select an employee.");
        }

        if (item == null) {
            throw new IllegalArgumentException("Please select an item.");
        }

        int quantity = parsePositiveInt(quantityText, "Quantity");
        BigDecimal pricePerUnit = parsePositiveMoney(pricePerUnitText, "Price per unit");
        BigDecimal subtotal = pricePerUnit.multiply(BigDecimal.valueOf(quantity));

        return purchaseDao.createPurchase(
                supplier.getSupplierId(),
                employee.getEmployeeId(),
                item.getItemId(),
                quantity,
                pricePerUnit,
                subtotal
        );
    }

    private int parsePositiveInt(String value, String fieldName) {
        try {
            int result = Integer.parseInt(value.trim());
            if (result <= 0) {
                throw new IllegalArgumentException(fieldName + " must be greater than zero.");
            }
            return result;
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException(fieldName + " must be a valid integer.");
        }
    }

    private BigDecimal parsePositiveMoney(String value, String fieldName) {
        try {
            BigDecimal result = new BigDecimal(value.trim());
            if (result.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException(fieldName + " must be greater than zero.");
            }
            return result;
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException(fieldName + " must be a valid number.");
        }
    }
}