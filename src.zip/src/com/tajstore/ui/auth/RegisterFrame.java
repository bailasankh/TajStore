package com.tajstore.ui.auth;

import com.tajstore.model.Role;
import com.tajstore.service.AuthService;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BaseFrame;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;
import com.tajstore.util.Validator;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.util.List;

public class RegisterFrame extends BaseFrame {

    private final AuthService authService = new AuthService();

    private JTextField fullNameField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JComboBox<Role> roleComboBox;
    private JCheckBox showPasswordsCheck;
    private PrimaryButton registerButton;
    private SecondaryButton backToLoginButton;

    private int shimmerX = -220;

    private static final Color BG_TOP = new Color(7, 4, 3);
    private static final Color BG_BOTTOM = new Color(18, 10, 6);
    private static final Color GOLD = new Color(212, 175, 55);
    private static final Color GOLD_LIGHT = new Color(245, 225, 170);
    private static final Color TEXT_MAIN = new Color(245, 238, 230);
    private static final Color TEXT_SOFT = new Color(205, 188, 160);
    private static final Color CARD_BG = new Color(0, 0, 0, 170);
    private static final Color FIELD_BG = new Color(38, 24, 16);

    public RegisterFrame() {
        super("Taj Store - Register", 900, 860);
        initUI();
        setResizable(true);
        setMinimumSize(new Dimension(820, 760));
    }

    @Override
    protected void initUI() {
        JPanel root = new JPanel(new BorderLayout(0, 18)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                int width = getWidth();
                int height = getHeight();

                GradientPaint background = new GradientPaint(
                        0, 0, BG_TOP,
                        0, height, BG_BOTTOM
                );
                g2d.setPaint(background);
                g2d.fillRect(0, 0, width, height);

                Point center = new Point(width / 2, height / 3);
                float radius = Math.max(width, height) * 0.95f;
                float[] dist = {0.0f, 0.28f, 0.7f, 1.0f};
                Color[] colors = {
                        new Color(110, 68, 22, 170),
                        new Color(60, 32, 10, 90),
                        new Color(20, 10, 5, 35),
                        new Color(0, 0, 0, 0)
                };
                RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
                g2d.setPaint(spotlight);
                g2d.fillRect(0, 0, width, height);

                int haloX = width / 2;
                int haloY = height / 2 - 20;
                int haloRadius = 320;
                RadialGradientPaint halo = new RadialGradientPaint(
                        new Point(haloX, haloY),
                        haloRadius,
                        new float[]{0.0f, 0.45f, 1.0f},
                        new Color[]{
                                new Color(224, 190, 78, 50),
                                new Color(180, 140, 40, 16),
                                new Color(0, 0, 0, 0)
                        }
                );
                g2d.setPaint(halo);
                g2d.fillOval(haloX - haloRadius, haloY - haloRadius, haloRadius * 2, haloRadius * 2);

                GradientPaint shimmer = new GradientPaint(
                        shimmerX, 0, new Color(255, 235, 180, 0),
                        shimmerX + 130, 0, new Color(255, 220, 140, 18),
                        true
                );
                g2d.setPaint(shimmer);
                g2d.fillRect(0, 0, width, height);

                g2d.dispose();
            }
        };

        root.setOpaque(false);
        root.setBorder(BorderFactory.createEmptyBorder(20, 28, 22, 28));

        root.add(buildHeader(), BorderLayout.NORTH);
        root.add(buildCenterArea(), BorderLayout.CENTER);
        root.add(buildFooter(), BorderLayout.SOUTH);

        setContentPane(root);
        startBackgroundAnimation(root);
    }

    private JPanel buildHeader() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel brand = new JLabel("TAJ STORE");
        brand.setAlignmentX(Component.CENTER_ALIGNMENT);
        brand.setFont(new Font("Serif", Font.BOLD, 46));
        brand.setForeground(GOLD);

        JLabel line = new JLabel("━━━━━━━━━━━━━━━━━━━━");
        line.setAlignmentX(Component.CENTER_ALIGNMENT);
        line.setFont(new Font("Serif", Font.PLAIN, 18));
        line.setForeground(new Color(170, 130, 45));

        JLabel subtitle = new JLabel("Create a New Luxury System Account");
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 17));
        subtitle.setForeground(new Color(235, 222, 205));

        panel.add(Box.createVerticalStrut(6));
        panel.add(brand);
        panel.add(Box.createVerticalStrut(4));
        panel.add(line);
        panel.add(Box.createVerticalStrut(8));
        panel.add(subtitle);

        return panel;
    }

    private JPanel buildCenterArea() {
        JPanel center = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        center.setOpaque(false);
        center.add(buildCenterCard());
        return center;
    }

    private JPanel buildCenterCard() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setPreferredSize(new Dimension(560, 560));
        wrapper.setMaximumSize(new Dimension(560, 560));

        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);

                g2.setColor(new Color(212, 175, 55, 115));
                g2.setStroke(new BasicStroke(1.4f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);

                g2.setColor(new Color(255, 230, 170, 35));
                g2.drawRoundRect(8, 8, getWidth() - 17, getHeight() - 17, 24, 24);

                g2.dispose();
                super.paintComponent(g);
            }
        };

        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(30, 34, 28, 34));

        SectionTitle sectionTitle = new SectionTitle("Register", "Add a new Taj Store user account");

        fullNameField = new JTextField();
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        confirmPasswordField = new JPasswordField();
        roleComboBox = new JComboBox<>();
        showPasswordsCheck = new JCheckBox("Show Passwords");

        styleLuxuryField(fullNameField);
        styleLuxuryField(usernameField);
        styleLuxuryField(passwordField);
        styleLuxuryField(confirmPasswordField);
        styleLuxuryComboBox(roleComboBox);

        loadRoles();

        showPasswordsCheck.setOpaque(false);
        showPasswordsCheck.setForeground(TEXT_SOFT);
        showPasswordsCheck.setFont(UIStyle.FONT_BODY);
        showPasswordsCheck.setAlignmentX(Component.LEFT_ALIGNMENT);
        showPasswordsCheck.setFocusPainted(false);
        showPasswordsCheck.addActionListener(e -> {
            char echo = showPasswordsCheck.isSelected() ? (char) 0 : '\u2022';
            passwordField.setEchoChar(echo);
            confirmPasswordField.setEchoChar(echo);
        });

        passwordField.setEchoChar('\u2022');
        confirmPasswordField.setEchoChar('\u2022');

        registerButton = new PrimaryButton("CREATE ACCOUNT");
        backToLoginButton = new SecondaryButton("BACK TO LOGIN");

        stylePrimaryActionButton(registerButton);
        styleSecondaryActionButton(backToLoginButton);

        registerButton.addActionListener(e -> doRegister());
        backToLoginButton.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        });

        card.add(sectionTitle);
        card.add(Box.createVerticalStrut(18));
        card.add(createLabeledField("Full Name", fullNameField));
        card.add(Box.createVerticalStrut(12));
        card.add(createLabeledField("Username", usernameField));
        card.add(Box.createVerticalStrut(12));
        card.add(createLabeledField("Password", passwordField));
        card.add(Box.createVerticalStrut(12));
        card.add(createLabeledField("Confirm Password", confirmPasswordField));
        card.add(Box.createVerticalStrut(12));
        card.add(createLabeledField("Role", roleComboBox));
        card.add(Box.createVerticalStrut(10));
        card.add(showPasswordsCheck);
        card.add(Box.createVerticalStrut(20));
        card.add(registerButton);
        card.add(Box.createVerticalStrut(10));
        card.add(backToLoginButton);
        card.add(Box.createVerticalStrut(6));

        JScrollPane scrollPane = new JScrollPane(card);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));

        wrapper.add(scrollPane, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel buildFooter() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.setOpaque(false);

        JLabel footer = new JLabel("Passwords are encrypted using SHA-256 & Salt Hashing");
        footer.setFont(UIStyle.FONT_SMALL);
        footer.setForeground(new Color(180, 160, 130));

        panel.add(footer);
        return panel;
    }

    private JPanel createLabeledField(String labelText, javax.swing.JComponent field) {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 7));
        panel.setOpaque(false);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 76));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(TEXT_MAIN);

        panel.add(label);
        panel.add(field);

        return panel;
    }

    private void styleLuxuryField(javax.swing.JComponent field) {
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        field.setPreferredSize(new Dimension(420, 46));
        field.setBackground(FIELD_BG);
        field.setForeground(TEXT_MAIN);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(160, 120, 55), 1, true),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));

        if (field instanceof JTextField) {
            ((JTextField) field).setCaretColor(GOLD);
            ((JTextField) field).setFont(UIStyle.FONT_BODY);
        }

        if (field instanceof JPasswordField) {
            ((JPasswordField) field).setCaretColor(GOLD);
            ((JPasswordField) field).setFont(UIStyle.FONT_BODY);
        }
    }

    private void styleLuxuryComboBox(JComboBox<Role> comboBox) {
        comboBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        comboBox.setPreferredSize(new Dimension(420, 46));
        comboBox.setBackground(FIELD_BG);
        comboBox.setForeground(TEXT_MAIN);
        comboBox.setFont(UIStyle.FONT_BODY);
        comboBox.setBorder(BorderFactory.createLineBorder(new Color(160, 120, 55), 1, true));
    }

    private void stylePrimaryActionButton(PrimaryButton button) {
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        button.setPreferredSize(new Dimension(420, 48));
        button.setFont(new Font("SansSerif", Font.BOLD, 15));
        button.setBackground(GOLD);
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
    }

    private void styleSecondaryActionButton(SecondaryButton button) {
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        button.setPreferredSize(new Dimension(420, 46));
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(new Color(18, 12, 8));
        button.setForeground(GOLD_LIGHT);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(150, 115, 45), 1, true));
    }

    private void startBackgroundAnimation(JPanel root) {
        Timer timer = new Timer(40, e -> {
            shimmerX += 4;
            if (shimmerX > getWidth() + 180) {
                shimmerX = -220;
            }
            root.repaint();
        });
        timer.start();
    }

    private void loadRoles() {
        List<Role> roles = authService.getAllRoles();
        roleComboBox.removeAllItems();
        for (Role role : roles) {
            roleComboBox.addItem(role);
        }
    }

    private void doRegister() {
        try {
            String fullName = fullNameField.getText().trim();
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());
            Role selectedRole = (Role) roleComboBox.getSelectedItem();

            Validator.validateFullName(fullName);
            Validator.validateUsername(username);
            Validator.validatePassword(password);
            Validator.validatePasswordConfirmation(password, confirmPassword);

            if (selectedRole == null) {
                throw new IllegalArgumentException("Please select a role.");
            }

            authService.register(fullName, username, password, selectedRole.getRoleId());

            MessageUtil.showSuccess(this, "Account created successfully.");
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));

        } catch (Exception ex) {
            MessageUtil.showError(this, ex.getMessage());
        }
    }
}