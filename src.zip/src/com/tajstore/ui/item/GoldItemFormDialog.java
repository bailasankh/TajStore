package com.tajstore.ui.item;

import com.tajstore.model.Category;
import com.tajstore.model.GoldItem;
import com.tajstore.service.GoldItemService;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.util.List;

public class GoldItemFormDialog extends JDialog {

    private final GoldItemService goldItemService = new GoldItemService();

    private JTextField itemNameField;
    private JTextField serialNoField;
    private JComboBox<Category> categoryComboBox;
    private JTextField weightField;
    private JComboBox<Integer> karatComboBox;
    private JTextField makingCostField;
    private JTextField imagePathField;
    private JCheckBox activeCheckBox;
    private PrimaryButton saveButton;
    private SecondaryButton cancelButton;
    private boolean saved;

    public GoldItemFormDialog(Frame owner, String title, GoldItem item) {
        super(owner, title, true);
        setSize(700, 760);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(true);
        initUI(item);
    }

    private void initUI(GoldItem item) {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBackground(ThemeManager.getTheme().getBackground());
        root.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        SectionTitle sectionTitle = new SectionTitle(getTitle(), "Gold item information, pricing, and optional image path");
        JPanel formPanel = buildForm(item);

        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(ThemeManager.getTheme().getBackground());

        root.add(sectionTitle, BorderLayout.NORTH);
        root.add(scrollPane, BorderLayout.CENTER);
        root.add(buildButtons(), BorderLayout.SOUTH);

        setContentPane(root);
    }

    private JPanel buildForm(GoldItem item) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(ThemeManager.getTheme().getSurface());
        panel.setBorder(UIStyle.createCardBorder());

        itemNameField = new JTextField();
        serialNoField = new JTextField();
        categoryComboBox = new JComboBox<>();
        weightField = new JTextField();
        karatComboBox = new JComboBox<>(new Integer[]{18, 21, 24});
        makingCostField = new JTextField();
        imagePathField = new JTextField();
        activeCheckBox = new JCheckBox("Active");

        UIStyle.styleField(itemNameField);
        UIStyle.styleField(serialNoField);
        UIStyle.styleField(categoryComboBox);
        UIStyle.styleField(weightField);
        UIStyle.styleField(karatComboBox);
        UIStyle.styleField(makingCostField);
        UIStyle.styleField(imagePathField);

        activeCheckBox.setOpaque(false);
        activeCheckBox.setForeground(ThemeManager.getTheme().getText());
        activeCheckBox.setFont(UIStyle.FONT_BODY);

        loadCategories();

        if (item != null) {
            itemNameField.setText(item.getItemName());
            serialNoField.setText(item.getSerialNo());
            weightField.setText(item.getWeightGram() != null ? item.getWeightGram().toPlainString() : "");
            karatComboBox.setSelectedItem(item.getKarat());
            makingCostField.setText(item.getMakingCost() != null ? item.getMakingCost().toPlainString() : "");
            imagePathField.setText(item.getImagePath() != null ? item.getImagePath() : "");
            activeCheckBox.setSelected(item.isActive());

            for (int i = 0; i < categoryComboBox.getItemCount(); i++) {
                Category category = categoryComboBox.getItemAt(i);
                if (category.getCategoryId() == item.getCategoryId()) {
                    categoryComboBox.setSelectedIndex(i);
                    break;
                }
            }
        } else {
            activeCheckBox.setSelected(true);
        }

        panel.add(createLabeledField("Item Name", itemNameField));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createLabeledField("Serial Number", serialNoField));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createLabeledField("Category", categoryComboBox));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createLabeledField("Weight (gram)", weightField));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createLabeledField("Karat", karatComboBox));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createLabeledField("Making Cost", makingCostField));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createImagePathField());
        panel.add(Box.createVerticalStrut(12));

        JPanel activePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        activePanel.setOpaque(false);
        activePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        activePanel.add(activeCheckBox);

        panel.add(activePanel);
        panel.add(Box.createVerticalStrut(8));
        return panel;
    }

    private JPanel createImagePathField() {
        JPanel wrapper = new JPanel();
        wrapper.setOpaque(false);
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel label = new JLabel("Image Path");
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        SecondaryButton browseButton = new SecondaryButton("Browse");
        browseButton.addActionListener(e -> chooseImage());

        row.add(imagePathField, BorderLayout.CENTER);
        row.add(browseButton, BorderLayout.EAST);

        JLabel helper = new JLabel("Optional. Save a local image path for this gold item.");
        helper.setFont(UIStyle.FONT_SMALL);
        helper.setForeground(ThemeManager.getTheme().getTextMuted());
        helper.setAlignmentX(Component.LEFT_ALIGNMENT);

        wrapper.add(label);
        wrapper.add(Box.createVerticalStrut(6));
        wrapper.add(row);
        wrapper.add(Box.createVerticalStrut(6));
        wrapper.add(helper);
        return wrapper;
    }

    private void chooseImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose gold item image");
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile() != null) {
            imagePathField.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void loadCategories() {
        List<Category> categories = goldItemService.getAllCategories();
        categoryComboBox.removeAllItems();
        for (Category category : categories) {
            categoryComboBox.addItem(category);
        }
    }

    private JPanel createLabeledField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 6));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());

        panel.add(label);
        panel.add(field);
        return panel;
    }

    private JPanel buildButtons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panel.setOpaque(false);

        saveButton = new PrimaryButton("Save");
        cancelButton = new SecondaryButton("Cancel");

        saveButton.addActionListener(e -> onSave());
        cancelButton.addActionListener(e -> dispose());

        panel.add(cancelButton);
        panel.add(saveButton);
        return panel;
    }

    private void onSave() {
        if (itemNameField.getText().trim().isEmpty()) {
            MessageUtil.showError(this, "Item name is required.");
            return;
        }
        if (serialNoField.getText().trim().isEmpty()) {
            MessageUtil.showError(this, "Serial number is required.");
            return;
        }

        saved = true;
        dispose();
    }

    public boolean isSaved() {
        return saved;
    }

    public String getItemNameValue() {
        return itemNameField.getText().trim();
    }

    public String getSerialNoValue() {
        return serialNoField.getText().trim();
    }

    public Category getSelectedCategory() {
        return (Category) categoryComboBox.getSelectedItem();
    }

    public String getWeightValue() {
        return weightField.getText().trim();
    }

    public int getKaratValue() {
        Integer selected = (Integer) karatComboBox.getSelectedItem();
        return selected != null ? selected : 21;
    }

    public String getMakingCostValue() {
        return makingCostField.getText().trim();
    }

    public String getImagePathValue() {
        return imagePathField.getText().trim();
    }

    public boolean isActiveValue() {
        return activeCheckBox.isSelected();
    }
}
