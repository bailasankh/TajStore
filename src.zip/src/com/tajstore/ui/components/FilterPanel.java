package com.tajstore.ui.components;

import javax.swing.JPanel;
import java.awt.FlowLayout;

public class FilterPanel extends JPanel {

    public FilterPanel() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 0));
    }
}