package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;

import javax.swing.JFrame;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;

public abstract class BaseFrame extends JFrame {

    protected BaseFrame(String title, int width, int height) {
        super(title);
        setSize(width, height);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(ThemeManager.getTheme().getBackground());
    }

    protected abstract void initUI();

    protected void refreshTheme() {
        getContentPane().setBackground(ThemeManager.getTheme().getBackground());
        repaint();
        revalidate();
    }
}