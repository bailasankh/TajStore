package com.tajstore.ui.sales;

import com.tajstore.db.ConnectionManager;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class InvoiceDetailsDialog extends JDialog {

    private final int invoiceId;

    private JLabel invoiceInfoLabel;
    private JTable detailsTable;
    private DefaultTableModel tableModel;

    public InvoiceDetailsDialog(Frame owner, int invoiceId) {
        super(owner, "Invoice Details - #" + invoiceId, true);
        this.invoiceId = invoiceId;

        setSize(850, 550);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(true);

        initUI();
        loadInvoiceData();
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBackground(ThemeManager.getTheme().getBackground());
        root.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Invoice Details");
        titleLabel.setFont(UIStyle.FONT_TITLE);
        titleLabel.setForeground(ThemeManager.getTheme().getPrimary());

        invoiceInfoLabel = new JLabel("Loading invoice information...");
        invoiceInfoLabel.setFont(UIStyle.FONT_BODY);
        invoiceInfoLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        JPanel topPanel = new JPanel();
        topPanel.setOpaque(false);
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.add(titleLabel);
        topPanel.add(Box.createVerticalStrut(10));
        topPanel.add(invoiceInfoLabel);

        tableModel = new DefaultTableModel(
                new Object[]{"Item ID", "Item Name", "Serial No", "Quantity", "Sale Price", "Gold Price At Sale", "Making Cost At Sale"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        detailsTable = new JTable(tableModel);
        detailsTable.setRowHeight(28);
        detailsTable.setFont(UIStyle.FONT_BODY);
        detailsTable.getTableHeader().setFont(UIStyle.FONT_BODY);

        JScrollPane scrollPane = new JScrollPane(detailsTable);
        scrollPane.setBorder(null);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setOpaque(false);

        javax.swing.JButton closeButton = new javax.swing.JButton("Close");
        UIStyle.styleSecondaryButton(closeButton);
        closeButton.addActionListener(e -> dispose());
        footer.add(closeButton);

        root.add(topPanel, BorderLayout.NORTH);
        root.add(scrollPane, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);

        setContentPane(root);
    }

    private void loadInvoiceData() {
        loadInvoiceHeader();
        loadInvoiceDetails();
    }

    private void loadInvoiceHeader() {
        String sql =
                "SELECT i.invoice_id, i.invoice_date, i.total_amount, i.status, " +
                "c.full_name AS customer_name, e.full_name AS employee_name " +
                "FROM invoice i " +
                "JOIN customer c ON i.customer_id = c.customer_id " +
                "JOIN employee e ON i.employee_id = e.employee_id " +
                "WHERE i.invoice_id = ?";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, invoiceId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    invoiceInfoLabel.setText(
                            "<html>" +
                                    "<b>Invoice ID:</b> " + rs.getInt("invoice_id") +
                                    " &nbsp;&nbsp; <b>Date:</b> " + rs.getTimestamp("invoice_date") +
                                    " &nbsp;&nbsp; <b>Customer:</b> " + rs.getString("customer_name") +
                                    " &nbsp;&nbsp; <b>Employee:</b> " + rs.getString("employee_name") +
                                    " &nbsp;&nbsp; <b>Total:</b> " + rs.getBigDecimal("total_amount") +
                                    " &nbsp;&nbsp; <b>Status:</b> " + rs.getString("status") +
                                    "</html>"
                    );
                } else {
                    invoiceInfoLabel.setText("Invoice not found.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            invoiceInfoLabel.setText("Failed to load invoice header.");
        }
    }

    private void loadInvoiceDetails() {
        tableModel.setRowCount(0);

        String sql =
                "SELECT d.item_id, g.item_name, g.serial_no, d.quantity, d.sale_price, d.gold_price_at_sale, d.making_cost_at_sale " +
                "FROM invoice_details d " +
                "JOIN gold_item g ON d.item_id = g.item_id " +
                "WHERE d.invoice_id = ?";

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, invoiceId);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    tableModel.addRow(new Object[]{
                            rs.getInt("item_id"),
                            rs.getString("item_name"),
                            rs.getString("serial_no"),
                            rs.getInt("quantity"),
                            rs.getBigDecimal("sale_price"),
                            rs.getBigDecimal("gold_price_at_sale"),
                            rs.getBigDecimal("making_cost_at_sale")
                    });
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
