package com.tajstore.app;

public class App {
    public static void main(String[] args) {
        AppLauncher.launch();
    }
}