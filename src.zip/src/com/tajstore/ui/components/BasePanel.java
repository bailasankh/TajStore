package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public abstract class BasePanel extends JPanel {

    protected BasePanel() {
        setLayout(new BorderLayout());
        setOpaque(false);
        setBackground(ThemeManager.getTheme().getBackground());
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Color top = ThemeManager.isDarkMode()
                ? new Color(22, 16, 12, 130)
                : new Color(255, 255, 255, 120);
        Color bottom = ThemeManager.isDarkMode()
                ? new Color(38, 24, 16, 160)
                : new Color(245, 245, 245, 140);

        g2.setPaint(new java.awt.GradientPaint(
                0, 0, top,
                0, getHeight(), bottom
        ));
        g2.fillRect(0, 0, getWidth(), getHeight());

        g2.dispose();
    }

    protected abstract void initUI();

    public void refreshTheme() {
        setBackground(ThemeManager.getTheme().getBackground());
        repaint();
        revalidate();
    }
}