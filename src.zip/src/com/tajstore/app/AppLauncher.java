package com.tajstore.app;

import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.ThemeMode;
import com.tajstore.ui.auth.Splashscreen;
import com.tajstore.ui.auth.LoginFrame;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public final class AppLauncher {

    private AppLauncher() {
    }

    public static void launch() {
        SwingUtilities.invokeLater(() -> {
            applySystemLookAndFeel();
            ThemeManager.initialize(ThemeMode.DARK);
            
            // === السحر هنا: افتح الـ Splash Screen بدل اللوجين المباشر ===
            new Splashscreen().setVisible(true);
            
            // تم إزالة سطر الـ LoginFrame من هنا
        });
    }

    private static void applySystemLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
    }
}