package com.tajstore.model;

import java.math.BigDecimal;

public class SalesItemOption {

    private int itemId;
    private String itemName;
    private String serialNo;
    private String categoryName;
    private BigDecimal weightGram;
    private int karat;
    private BigDecimal makingCost;
    private int qty;

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getWeightGram() {
        return weightGram;
    }

    public void setWeightGram(BigDecimal weightGram) {
        this.weightGram = weightGram;
    }

    public int getKarat() {
        return karat;
    }

    public void setKarat(int karat) {
        this.karat = karat;
    }

    public BigDecimal getMakingCost() {
        return makingCost;
    }

    public void setMakingCost(BigDecimal makingCost) {
        this.makingCost = makingCost;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    @Override
    public String toString() {
        return itemName + " | " + serialNo + " | Qty: " + qty;
    }
}