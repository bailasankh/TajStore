package com.tajstore.ui.sales;

import com.tajstore.model.Customer;
import com.tajstore.model.Employee;
import com.tajstore.model.GoldPriceHistory;
import com.tajstore.model.PaymentMethod;
import com.tajstore.model.SalesItemOption;
import com.tajstore.service.SalesService;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SearchPanel;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class SalesPanel extends BasePanel {

    private final SalesService salesService = new SalesService();

    private JComboBox<Customer> customerComboBox;
    private JComboBox<Employee> employeeComboBox;
    private JComboBox<SalesItemOption> itemComboBox;
    private JComboBox<PaymentMethod> paymentMethodComboBox;
    private JTextField quantityField;
    private JTextField salePriceField;
    private JTextField goldPriceField;
    private JTextField paymentAmountField;
    private JTextArea noteArea;
    private JLabel itemInfoLabel;
    private JLabel helperLabel;
    private JLabel totalAmountLabel;
    private SearchPanel searchPanel;
    private PrimaryButton createSaleButton;

    public SalesPanel() {
        initUI();
        loadData();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int width = getWidth();
        int height = getHeight();
        g2d.setColor(ThemeManager.isDarkMode() ? new Color(5, 2, 2) : new Color(248, 244, 236));
        g2d.fillRect(0, 0, width, height);

        Point center = new Point(width / 2, 0);
        float radius = Math.max(width, height) * 0.9f;
        float[] dist = {0.0f, 0.4f, 1.0f};
        Color[] colors = {
            ThemeManager.isDarkMode() ? new Color(70, 40, 10, 180) : new Color(201, 162, 39, 65),
            ThemeManager.isDarkMode() ? new Color(35, 18, 5, 100) : new Color(201, 162, 39, 30),
            new Color(0, 0, 0, 0)
        };
        RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
        g2d.setPaint(spotlight);
        g2d.fillRect(0, 0, width, height);
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(16, 16));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setOpaque(false);

        add(buildHeader(), BorderLayout.NORTH);
        add(buildFormCard(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle("Sales", "Create sales invoice and payment");

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setOpaque(false);

        searchPanel = new SearchPanel();
        searchPanel.getSearchField().setText("Reload customers, staff, items, and payment methods");
        searchPanel.getSearchField().setEditable(false);
        searchPanel.getSearchButton().setVisible(false);

        SecondaryButton refreshButton = searchPanel.getRefreshButton();
        refreshButton.addActionListener(e -> loadData());

        rightPanel.add(searchPanel);

        panel.add(sectionTitle, BorderLayout.WEST);
        panel.add(rightPanel, BorderLayout.EAST);

        return panel;
    }

    private JPanel buildFormCard() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(glassColor());
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(24, 24, 24, 24)
        ));

        customerComboBox = new JComboBox<>();
        employeeComboBox = new JComboBox<>();
        itemComboBox = new JComboBox<>();
        paymentMethodComboBox = new JComboBox<>();
        quantityField = new JTextField("1");
        salePriceField = new JTextField();
        goldPriceField = new JTextField();
        paymentAmountField = new JTextField();
        noteArea = new JTextArea(4, 20);

        UIStyle.styleField(customerComboBox);
        UIStyle.styleField(employeeComboBox);
        UIStyle.styleField(itemComboBox);
        UIStyle.styleField(paymentMethodComboBox);
        UIStyle.styleField(quantityField);
        UIStyle.styleField(salePriceField);
        UIStyle.styleField(goldPriceField);
        UIStyle.styleField(paymentAmountField);

        noteArea.setFont(UIStyle.FONT_BODY);
        noteArea.setBackground(ThemeManager.getTheme().getSurface());
        noteArea.setForeground(ThemeManager.getTheme().getText());
        noteArea.setBorder(UIStyle.createRoundedLineBorder());
        noteArea.setLineWrap(true);
        noteArea.setWrapStyleWord(true);

        itemInfoLabel = new JLabel("Select an item to view details.");
        itemInfoLabel.setFont(UIStyle.FONT_BODY);
        itemInfoLabel.setForeground(ThemeManager.getTheme().getPrimary());

        helperLabel = new JLabel("Selecting an item will auto-fill the suggested gold price, sale price, and payment amount.");
        helperLabel.setFont(UIStyle.FONT_SMALL);
        helperLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        itemComboBox.addActionListener(e -> updateSelectedItemInfo());
        createSaleButton = new PrimaryButton("Create Sale");
        createSaleButton.addActionListener(e -> createSale());
        quantityField.getDocument().addDocumentListener(new SimpleDocumentListener(this::updateCalculatedFieldsFromSelection));
        salePriceField.getDocument().addDocumentListener(new SimpleDocumentListener(this::updateDraftSummary));
        paymentAmountField.getDocument().addDocumentListener(new SimpleDocumentListener(this::updateDraftSummary));

        JPanel topFieldsGrid = new JPanel(new GridLayout(4, 2, 20, 12));
        topFieldsGrid.setOpaque(false);
        topFieldsGrid.add(createLabeledField("Customer", customerComboBox));
        topFieldsGrid.add(createLabeledField("Sale Price", salePriceField));
        topFieldsGrid.add(createLabeledField("Employee", employeeComboBox));
        topFieldsGrid.add(createLabeledField("Gold Price At Sale", goldPriceField));
        topFieldsGrid.add(createLabeledField("Gold Item", itemComboBox));
        topFieldsGrid.add(createLabeledField("Quantity", quantityField));
        topFieldsGrid.add(createLabeledField("Payment Amount", paymentAmountField));

        form.add(topFieldsGrid);
        form.add(Box.createVerticalStrut(12));
        form.add(helperLabel);
        form.add(Box.createVerticalStrut(10));
        form.add(createItemInfoCard());
        form.add(Box.createVerticalStrut(20));

        JPanel bottomGrid = new JPanel(new GridLayout(1, 2, 20, 12));
        bottomGrid.setOpaque(false);
        bottomGrid.add(createLabeledField("Payment Method", paymentMethodComboBox));
        bottomGrid.add(createLabeledArea("Note", noteArea));
        form.add(bottomGrid);

        JScrollPane scrollPane = new JScrollPane(form);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));

        outer.add(scrollPane, BorderLayout.CENTER);
        outer.add(buildBottomTotalBar(), BorderLayout.SOUTH);
        return outer;
    }

    private JPanel buildBottomTotalBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(true);
        bar.setBackground(innerGlassColor());
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderSoftColor(), 1, true),
                BorderFactory.createEmptyBorder(16, 24, 16, 24)
        ));

        JLabel totalLabel = new JLabel("Draft Total:");
        totalLabel.setFont(UIStyle.FONT_SUBTITLE);
        totalLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        totalAmountLabel = new JLabel("0.00");
        totalAmountLabel.setFont(UIStyle.FONT_TITLE);
        totalAmountLabel.setForeground(ThemeManager.getTheme().getPrimary());

        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftPanel.setOpaque(false);
        leftPanel.add(totalLabel);
        leftPanel.add(totalAmountLabel);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(createSaleButton);

        bar.add(leftPanel, BorderLayout.WEST);
        bar.add(rightPanel, BorderLayout.EAST);
        return bar;
    }

    private JPanel createItemInfoCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setOpaque(true);
        card.setBackground(innerGlassColor());
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderSoftColor(), 1, true),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        card.add(itemInfoLabel, BorderLayout.WEST);
        return card;
    }

    private JPanel createLabeledField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 6));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());

        panel.add(label);
        panel.add(field);
        return panel;
    }

    private JPanel createLabeledArea(String labelText, JComponent area) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());

        panel.add(label, BorderLayout.NORTH);

        JScrollPane areaScrollPane = new JScrollPane(area);
        areaScrollPane.setBorder(null);
        areaScrollPane.setOpaque(false);
        areaScrollPane.getViewport().setOpaque(false);
        panel.add(areaScrollPane, BorderLayout.CENTER);
        return panel;
    }

    private void loadData() {
        try {
            List<Customer> customers = salesService.getCustomers();
            List<Employee> employees = salesService.getEmployees();
            List<SalesItemOption> items = salesService.getAvailableItems();
            List<PaymentMethod> methods = salesService.getPaymentMethods();

            customerComboBox.removeAllItems();
            for (Customer customer : customers) {
                customerComboBox.addItem(customer);
            }

            employeeComboBox.removeAllItems();
            for (Employee employee : employees) {
                employeeComboBox.addItem(employee);
            }

            itemComboBox.removeAllItems();
            for (SalesItemOption item : items) {
                itemComboBox.addItem(item);
            }

            paymentMethodComboBox.removeAllItems();
            for (PaymentMethod method : methods) {
                paymentMethodComboBox.addItem(method);
            }

            createSaleButton.setEnabled(!customers.isEmpty() && !employees.isEmpty() && !items.isEmpty() && !methods.isEmpty());
            helperLabel.setText(buildAvailabilityMessage(customers, employees, items, methods));
            updateSelectedItemInfo();
            updateDraftSummary();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void updateSelectedItemInfo() {
        SalesItemOption item = (SalesItemOption) itemComboBox.getSelectedItem();

        if (item == null) {
            itemInfoLabel.setText("No sellable gold item is available right now. Review inventory first.");
            quantityField.setText("1");
            goldPriceField.setText("");
            salePriceField.setText("");
            paymentAmountField.setText("");
            return;
        }

        itemInfoLabel.setText(
                "Category: " + item.getCategoryName()
                        + " | Weight: " + item.getWeightGram()
                        + " | Karat: " + item.getKarat()
                        + " | Making Cost: " + item.getMakingCost()
                        + " | Qty: " + item.getQty()
        );

        if (quantityField.getText().trim().isEmpty()) {
            quantityField.setText("1");
        }
        updateCalculatedFieldsFromSelection();
        updateDraftSummary();
    }

    private void updateCalculatedFieldsFromSelection() {
        SalesItemOption item = (SalesItemOption) itemComboBox.getSelectedItem();
        if (item == null) {
            return;
        }
        autoFillSaleFields(item);
        updateDraftSummary();
    }

    private void autoFillSaleFields(SalesItemOption item) {
        GoldPriceHistory latestPrice = salesService.getLatestGoldPrice();
        BigDecimal goldPrice = getGoldPriceForKarat(item, latestPrice);
        BigDecimal weight = item.getWeightGram() == null ? BigDecimal.ZERO : item.getWeightGram();
        BigDecimal makingCost = item.getMakingCost() == null ? BigDecimal.ZERO : item.getMakingCost();
        int quantity = parseQuantityOrDefault();
        BigDecimal unitSalePrice = weight.multiply(goldPrice).add(makingCost).setScale(2, RoundingMode.HALF_UP);
        BigDecimal suggestedSalePrice = unitSalePrice.multiply(BigDecimal.valueOf(quantity)).setScale(2, RoundingMode.HALF_UP);

        if (goldPrice.compareTo(BigDecimal.ZERO) > 0) {
            goldPriceField.setText(goldPrice.setScale(2, RoundingMode.HALF_UP).toPlainString());
            helperLabel.setText("Latest saved " + item.getKarat() + "K gold price was used to build a suggested sale total for quantity " + quantity + ".");
        } else {
            goldPriceField.setText("");
            helperLabel.setText("No saved gold price matches this item yet. Enter the gold price manually before saving.");
        }

        salePriceField.setText(suggestedSalePrice.toPlainString());
        paymentAmountField.setText(suggestedSalePrice.toPlainString());
    }

    private int parseQuantityOrDefault() {
        String raw = quantityField.getText().trim();
        if (raw.isEmpty()) {
            return 1;
        }

        try {
            int quantity = Integer.parseInt(raw);
            return Math.max(quantity, 1);
        } catch (NumberFormatException ex) {
            return 1;
        }
    }

    private BigDecimal getGoldPriceForKarat(SalesItemOption item, GoldPriceHistory latestPrice) {
        if (item == null || latestPrice == null) {
            return BigDecimal.ZERO;
        }

        return switch (item.getKarat()) {
            case 24 -> BigDecimal.valueOf(latestPrice.getPrice24k());
            case 21 -> BigDecimal.valueOf(latestPrice.getPrice21k());
            case 18 -> BigDecimal.valueOf(latestPrice.getPrice18k());
            default -> BigDecimal.ZERO;
        };
    }

    private void updateDraftSummary() {
        String amount = salePriceField.getText().trim();
        if (amount.isEmpty()) {
            totalAmountLabel.setText("0.00");
            return;
        }

        try {
            BigDecimal total = new BigDecimal(amount);
            totalAmountLabel.setText(total.compareTo(BigDecimal.ZERO) > 0 ? total.toPlainString() : "0.00");
        } catch (NumberFormatException ex) {
            totalAmountLabel.setText("0.00");
        }
    }

    private void createSale() {
        try {
            Customer customer = (Customer) customerComboBox.getSelectedItem();
            Employee employee = (Employee) employeeComboBox.getSelectedItem();
            SalesItemOption item = (SalesItemOption) itemComboBox.getSelectedItem();
            PaymentMethod paymentMethod = (PaymentMethod) paymentMethodComboBox.getSelectedItem();
            validateSaleForm(customer, employee, item, paymentMethod);

            int invoiceId = salesService.createSale(
                    customer,
                    employee,
                    item,
                    paymentMethod,
                    quantityField.getText(),
                    salePriceField.getText(),
                    goldPriceField.getText(),
                    paymentAmountField.getText(),
                    noteArea.getText()
            );

            MessageUtil.showSuccess(this, "Sale saved successfully. Invoice ID: " + invoiceId);

            quantityField.setText("1");
            salePriceField.setText("");
            goldPriceField.setText("");
            paymentAmountField.setText("");
            noteArea.setText("");
            loadData();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void validateSaleForm(Customer customer, Employee employee, SalesItemOption item, PaymentMethod paymentMethod) {
        if (customer == null || employee == null || item == null || paymentMethod == null) {
            throw new IllegalArgumentException("Please reload the lists and make sure customer, employee, item, and payment method are selected.");
        }

        int quantity = parsePositiveQuantity(quantityField.getText().trim());
        BigDecimal salePrice = parsePositiveDecimal(salePriceField.getText().trim(), "sale price");
        parsePositiveDecimal(goldPriceField.getText().trim(), "gold price");
        BigDecimal paymentAmount = parsePositiveDecimal(paymentAmountField.getText().trim(), "payment amount");

        if (quantity > item.getQty()) {
            throw new IllegalArgumentException("Selected quantity is greater than the available stock for this item.");
        }

        if (paymentAmount.compareTo(salePrice) > 0) {
            throw new IllegalArgumentException("Payment amount should not be greater than the sale price.");
        }
    }

    private BigDecimal parsePositiveDecimal(String value, String label) {
        if (value.isEmpty()) {
            throw new IllegalArgumentException("Please enter the " + label + ".");
        }

        BigDecimal number;
        try {
            number = new BigDecimal(value);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Please enter a valid " + label + ".");
        }

        if (number.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("The " + label + " must be greater than zero.");
        }
        return number;
    }

    private int parsePositiveQuantity(String value) {
        if (value.isEmpty()) {
            throw new IllegalArgumentException("Please enter the quantity.");
        }

        try {
            int quantity = Integer.parseInt(value);
            if (quantity <= 0) {
                throw new IllegalArgumentException("Quantity must be greater than zero.");
            }
            return quantity;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Please enter a valid whole quantity.");
        }
    }

    private String buildAvailabilityMessage(
            List<Customer> customers,
            List<Employee> employees,
            List<SalesItemOption> items,
            List<PaymentMethod> methods) {

        if (customers.isEmpty() || employees.isEmpty() || items.isEmpty() || methods.isEmpty()) {
            return "Some required lists are empty. Make sure customers, staff, items, and payment methods are ready before saving.";
        }
        return "Ready to create a sale. Review the draft total, payment amount, and selected item before saving.";
    }

    private Color glassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 120) : new Color(255, 255, 255, 215);
    }

    private Color innerGlassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 160) : new Color(248, 248, 248, 220);
    }

    private Color borderColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 80) : ThemeManager.getTheme().getBorder();
    }

    private Color borderSoftColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 100) : new Color(201, 162, 39, 90);
    }

    private static class SimpleDocumentListener implements javax.swing.event.DocumentListener {
        private final Runnable onChange;

        private SimpleDocumentListener(Runnable onChange) {
            this.onChange = onChange;
        }

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }
    }
}
