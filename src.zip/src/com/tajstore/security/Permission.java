package com.tajstore.security;

public enum Permission {
    VIEW_DASHBOARD,
    MANAGE_CUSTOMERS,
    MANAGE_SUPPLIERS,
    MANAGE_ITEMS,
    VIEW_INVENTORY,
    MANAGE_SALES,
    MANAGE_PURCHASES,
    VIEW_REPORTS,
    MANAGE_USERS,
    TOGGLE_THEME
}