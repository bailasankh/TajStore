package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.Customer;
import com.tajstore.model.Employee;
import com.tajstore.model.PaymentMethod;
import com.tajstore.model.SalesItemOption;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SalesSupportDao {

    private static final String FIND_CUSTOMERS_SQL =
            "SELECT customer_id, full_name, phone, address, created_at FROM customer ORDER BY full_name";

    private static final String FIND_EMPLOYEES_SQL =
            "SELECT employee_id, full_name FROM employee WHERE is_active = 1 ORDER BY full_name";

    private static final String FIND_PAYMENT_METHODS_SQL =
            "SELECT method_id, name FROM payment_method ORDER BY name";

    private static final String FIND_AVAILABLE_ITEMS_SQL =
            "SELECT g.item_id, g.item_name, g.serial_no, c.category_name, g.weight_gram, g.karat, g.making_cost, i.qty " +
            "FROM gold_item g " +
            "JOIN category c ON g.category_id = c.category_id " +
            "JOIN inventory i ON g.item_id = i.item_id " +
            "WHERE g.is_active = 1 AND i.qty > 0 " +
            "ORDER BY g.item_name";

    public List<Customer> findAllCustomers() {
        List<Customer> customers = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_CUSTOMERS_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                Customer customer = new Customer();
                customer.setCustomerId(rs.getInt("customer_id"));
                customer.setFullName(rs.getString("full_name"));
                customer.setPhone(rs.getString("phone"));
                customer.setAddress(rs.getString("address"));
                customers.add(customer);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load customers for sales.", e);
        }

        return customers;
    }

    public List<Employee> findAllEmployees() {
        List<Employee> employees = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_EMPLOYEES_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt("employee_id"),
                        rs.getString("full_name")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load employees for sales.", e);
        }

        return employees;
    }

    public List<PaymentMethod> findAllPaymentMethods() {
        List<PaymentMethod> methods = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_PAYMENT_METHODS_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                methods.add(new PaymentMethod(
                        rs.getInt("method_id"),
                        rs.getString("name")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load payment methods.", e);
        }

        return methods;
    }

    public List<SalesItemOption> findAvailableItems() {
        List<SalesItemOption> items = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_AVAILABLE_ITEMS_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                SalesItemOption item = new SalesItemOption();
                item.setItemId(rs.getInt("item_id"));
                item.setItemName(rs.getString("item_name"));
                item.setSerialNo(rs.getString("serial_no"));
                item.setCategoryName(rs.getString("category_name"));
                item.setWeightGram(rs.getBigDecimal("weight_gram"));
                item.setKarat(rs.getInt("karat"));
                item.setMakingCost(rs.getBigDecimal("making_cost"));
                item.setQty(rs.getInt("qty"));
                items.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load available gold items.", e);
        }

        return items;
    }
}