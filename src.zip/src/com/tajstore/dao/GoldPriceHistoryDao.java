package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.GoldPriceHistory;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class GoldPriceHistoryDao {

    // ===== آخر سعر =====
    private static final String GET_LATEST =
            "SELECT * FROM gold_price_history ORDER BY price_date DESC LIMIT 1";

    // ===== كل الأسعار (للتقرير) =====
    private static final String GET_ALL =
            "SELECT * FROM gold_price_history ORDER BY price_date DESC";

    // ===== إضافة سعر جديد =====
    private static final String INSERT =
            "INSERT INTO gold_price_history " +
            "(price_date, price_per_gram_24k, price_per_gram_21k, price_per_gram_18k) " +
            "VALUES (?, ?, ?, ?)";
    private static final String UPDATE_BY_DATE =
            "UPDATE gold_price_history " +
            "SET price_per_gram_24k = ?, price_per_gram_21k = ?, price_per_gram_18k = ? " +
            "WHERE price_date = ?";

    // =======================
    // 1. GET LATEST PRICE
    
    public GoldPriceHistory getLatestPrice() {

        try (Connection con = ConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(GET_LATEST);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return map(rs);
            }

        } catch (Exception e) {
            throw new RuntimeException("Error getting latest gold price", e);
        }

        return null;
    }

    // =======================
    // 2. GET ALL (REPORT)
    
    public List<GoldPriceHistory> getAllPrices() {

        List<GoldPriceHistory> list = new ArrayList<>();

        try (Connection con = ConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(GET_ALL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(map(rs));
            }

        } catch (Exception e) {
            throw new RuntimeException("Error getting gold price history list", e);
        }

        return list;
    }

    // =======================
    // 3. INSERT NEW PRICE
  
    public void insert(GoldPriceHistory g) {

        try (Connection con = ConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(INSERT)) {

            ps.setDate(1, Date.valueOf(g.getPriceDate()));
            ps.setDouble(2, g.getPrice24k());
            ps.setDouble(3, g.getPrice21k());
            ps.setDouble(4, g.getPrice18k());

            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Error inserting gold price", e);
        }
    }

    // =======================
    // 4. MAPPER (IMPORTANT)

    private GoldPriceHistory map(ResultSet rs) throws Exception {

        GoldPriceHistory g = new GoldPriceHistory();

        g.setPriceId(rs.getInt("price_id"));
        g.setPriceDate(rs.getDate("price_date").toLocalDate());
        g.setPrice24k(rs.getDouble("price_per_gram_24k"));
        g.setPrice21k(rs.getDouble("price_per_gram_21k"));
        g.setPrice18k(rs.getDouble("price_per_gram_18k"));
        g.setCreatedAt(rs.getTimestamp("created_at"));

        return g;
    }
    public boolean isTodayUpdated() {
        String sql =
                "SELECT COUNT(*) " +
                "FROM gold_price_history " +
                "WHERE price_date = CURDATE()";

        try (
                Connection con =
                        ConnectionManager.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql);

                ResultSet rs =
                        ps.executeQuery()
        ) {

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            throw new RuntimeException("Error checking today's gold price update", e);
        }

        return false;
    }

    public GoldPriceHistory getByDate(LocalDate date) {
        String sql = "SELECT * FROM gold_price_history WHERE price_date = ? LIMIT 1";

        try (Connection con = ConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error getting gold price by date", e);
        }

        return null;
    }

    public GoldPriceHistory getLatestBeforeOrOn(LocalDate date) {
        String sql = "SELECT * FROM gold_price_history WHERE price_date <= ? ORDER BY price_date DESC LIMIT 1";

        try (Connection con = ConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error getting latest gold price before or on date", e);
        }

        return null;
    }

    public void upsertByDate(GoldPriceHistory g) {
        GoldPriceHistory existing = getByDate(g.getPriceDate());
        if (existing == null) {
            insert(g);
            return;
        }

        try (Connection con = ConnectionManager.getConnection();
             PreparedStatement ps = con.prepareStatement(UPDATE_BY_DATE)) {
            ps.setDouble(1, g.getPrice24k());
            ps.setDouble(2, g.getPrice21k());
            ps.setDouble(3, g.getPrice18k());
            ps.setDate(4, Date.valueOf(g.getPriceDate()));
            ps.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException("Error updating gold price by date", e);
        }
    }
}
