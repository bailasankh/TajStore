package com.tajstore.theme;

import java.awt.Color;

public class AppTheme {

    private final ThemeMode mode;
    private final Color background;
    private final Color surface;
    private final Color surfaceAlt;
    private final Color primary;
    private final Color primaryDark;
    private final Color text;
    private final Color textMuted;
    private final Color border;
    private final Color success;
    private final Color danger;
    private final Color warning;

    public AppTheme(
            ThemeMode mode,
            Color background,
            Color surface,
            Color surfaceAlt,
            Color primary,
            Color primaryDark,
            Color text,
            Color textMuted,
            Color border,
            Color success,
            Color danger,
            Color warning
    ) {
        this.mode = mode;
        this.background = background;
        this.surface = surface;
        this.surfaceAlt = surfaceAlt;
        this.primary = primary;
        this.primaryDark = primaryDark;
        this.text = text;
        this.textMuted = textMuted;
        this.border = border;
        this.success = success;
        this.danger = danger;
        this.warning = warning;
    }

    public ThemeMode getMode() {
        return mode;
    }

    public Color getBackground() {
        return background;
    }

    public Color getSurface() {
        return surface;
    }

    public Color getSurfaceAlt() {
        return surfaceAlt;
    }

    public Color getPrimary() {
        return primary;
    }

    public Color getPrimaryDark() {
        return primaryDark;
    }

    public Color getText() {
        return text;
    }

    public Color getTextMuted() {
        return textMuted;
    }

    public Color getBorder() {
        return border;
    }

    public Color getSuccess() {
        return success;
    }

    public Color getDanger() {
        return danger;
    }

    public Color getWarning() {
        return warning;
    }
}