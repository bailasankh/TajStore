package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;

import java.awt.Dimension;

public class ThemeToggleButton extends SecondaryButton {

    public ThemeToggleButton() {
        super(ThemeManager.isDarkMode() ? "Light Mode" : "Dark Mode");
        setMinimumSize(new Dimension(135, 42));
        setPreferredSize(new Dimension(135, 42));
    }

    public void refreshText() {
        setText(ThemeManager.isDarkMode() ? "Light Mode" : "Dark Mode");
    }
}