package com.tajstore.ui.supplier;

import com.tajstore.model.Supplier;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;

public class SupplierFormDialog extends JDialog {

    private JTextField supplierNameField;
    private JTextField phoneField;
    private JTextArea addressArea;
    private PrimaryButton saveButton;
    private SecondaryButton cancelButton;

    private boolean saved;

    public SupplierFormDialog(Frame owner, String title, Supplier supplier) {
        super(owner, title, true);
        setSize(560, 470);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        initUI(supplier);
        setResizable(true);
    }

    private void initUI(Supplier supplier) {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBackground(ThemeManager.getTheme().getBackground());
        root.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        SectionTitle sectionTitle = new SectionTitle(getTitle(), "Supplier information form");

        root.add(sectionTitle, BorderLayout.NORTH);
        root.add(buildForm(supplier), BorderLayout.CENTER);
        root.add(buildButtons(), BorderLayout.SOUTH);

        setContentPane(root);
    }

    private JPanel buildForm(Supplier supplier) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(true);
        panel.setBackground(ThemeManager.getTheme().getSurface());
        panel.setBorder(UIStyle.createCardBorder());

        supplierNameField = new JTextField();
        phoneField = new JTextField();
        addressArea = new JTextArea(5, 20);

        UIStyle.styleField(supplierNameField);
        UIStyle.styleField(phoneField);
        addressArea.setFont(UIStyle.FONT_BODY);
        addressArea.setBackground(ThemeManager.getTheme().getSurface());
        addressArea.setForeground(ThemeManager.getTheme().getText());
        addressArea.setBorder(UIStyle.createRoundedLineBorder());
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);

        if (supplier != null) {
            supplierNameField.setText(supplier.getSupplierName());
            phoneField.setText(supplier.getPhone() != null ? supplier.getPhone() : "");
            addressArea.setText(supplier.getAddress() != null ? supplier.getAddress() : "");
        }

        panel.add(createLabeledField("Supplier Name", supplierNameField));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createLabeledField("Phone", phoneField));
        panel.add(Box.createVerticalStrut(12));
        panel.add(createLabeledArea("Address", addressArea));

        return panel;
    }

    private JPanel createLabeledField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 6));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());

        panel.add(label);
        panel.add(field);

        return panel;
    }

    private JPanel createLabeledArea(String labelText, JComponent area) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 170));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());

        panel.add(label, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);

        return panel;
    }

    private JPanel buildButtons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panel.setOpaque(false);

        saveButton = new PrimaryButton("Save");
        cancelButton = new SecondaryButton("Cancel");

        saveButton.addActionListener(e -> onSave());
        cancelButton.addActionListener(e -> dispose());

        panel.add(cancelButton);
        panel.add(saveButton);

        return panel;
    }

    private void onSave() {
        if (supplierNameField.getText().trim().isEmpty()) {
            MessageUtil.showError(this, "Supplier name is required.");
            return;
        }
        saved = true;
        dispose();
    }

    public boolean isSaved() {
        return saved;
    }

    public String getSupplierNameValue() {
        return supplierNameField.getText().trim();
    }

    public String getPhoneValue() {
        return phoneField.getText().trim();
    }

    public String getAddressValue() {
        return addressArea.getText().trim();
    }
}