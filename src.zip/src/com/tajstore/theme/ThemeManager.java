package com.tajstore.theme;

public final class ThemeManager {

    private static AppTheme currentTheme;

    private ThemeManager() {
    }

    public static void initialize(ThemeMode mode) {
        currentTheme = createTheme(mode);
    }

    public static void toggleTheme() {
        if (currentTheme == null) {
            initialize(ThemeMode.DARK);
            return;
        }

        if (currentTheme.getMode() == ThemeMode.DARK) {
            currentTheme = createTheme(ThemeMode.LIGHT);
        } else {
            currentTheme = createTheme(ThemeMode.DARK);
        }
    }

    public static void setTheme(ThemeMode mode) {
        currentTheme = createTheme(mode);
    }

    public static AppTheme getTheme() {
        if (currentTheme == null) {
            initialize(ThemeMode.DARK);
        }
        return currentTheme;
    }

    public static boolean isDarkMode() {
        return getTheme().getMode() == ThemeMode.DARK;
    }

    private static AppTheme createTheme(ThemeMode mode) {
        if (mode == ThemeMode.LIGHT) {
            return new AppTheme(
                    ThemeMode.LIGHT,
                    ColorPalette.LIGHT_BACKGROUND,
                    ColorPalette.LIGHT_SURFACE,
                    ColorPalette.LIGHT_SURFACE_ALT,
                    ColorPalette.GOLD_PRIMARY,
                    ColorPalette.GOLD_DARK,
                    ColorPalette.LIGHT_TEXT,
                    ColorPalette.LIGHT_TEXT_MUTED,
                    ColorPalette.LIGHT_BORDER,
                    ColorPalette.LIGHT_SUCCESS,
                    ColorPalette.LIGHT_DANGER,
                    ColorPalette.LIGHT_WARNING
            );
        }

        return new AppTheme(
                ThemeMode.DARK,
                ColorPalette.DARK_BACKGROUND,
                ColorPalette.DARK_SURFACE,
                ColorPalette.DARK_SURFACE_ALT,
                ColorPalette.GOLD_PRIMARY,
                ColorPalette.GOLD_DARK,
                ColorPalette.DARK_TEXT,
                ColorPalette.DARK_TEXT_MUTED,
                ColorPalette.DARK_BORDER,
                ColorPalette.DARK_SUCCESS,
                ColorPalette.DARK_DANGER,
                ColorPalette.DARK_WARNING
        );
    }
}