package com.tajstore.service;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.InventoryMovement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class InventoryMovementService {

    private static final String FIND_ALL_SQL =
            "SELECT m.move_id, m.item_id, g.item_name, g.serial_no, m.move_type, " +
            "m.ref_invoice_id, m.ref_po_id, m.move_date, m.note " +
            "FROM inventory_movement m " +
            "JOIN gold_item g ON m.item_id = g.item_id " +
            "ORDER BY m.move_date DESC, m.move_id DESC";

    private static final String SEARCH_SQL =
            "SELECT m.move_id, m.item_id, g.item_name, g.serial_no, m.move_type, " +
            "m.ref_invoice_id, m.ref_po_id, m.move_date, m.note " +
            "FROM inventory_movement m " +
            "JOIN gold_item g ON m.item_id = g.item_id " +
            "WHERE g.item_name LIKE ? OR g.serial_no LIKE ? OR m.move_type LIKE ? OR m.note LIKE ? " +
            "ORDER BY m.move_date DESC, m.move_id DESC";

    public List<InventoryMovement> getAllMovements() {
        List<InventoryMovement> movements = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                movements.add(mapRow(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load inventory movements.", e);
        }

        return movements;
    }

    public List<InventoryMovement> searchMovements(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllMovements();
        }

        List<InventoryMovement> movements = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_SQL)) {

            String value = "%" + keyword.trim() + "%";
            statement.setString(1, value);
            statement.setString(2, value);
            statement.setString(3, value);
            statement.setString(4, value);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    movements.add(mapRow(rs));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to search inventory movements.", e);
        }

        return movements;
    }

    private InventoryMovement mapRow(ResultSet rs) throws Exception {
        InventoryMovement movement = new InventoryMovement();
        movement.setMoveId(rs.getInt("move_id"));
        movement.setItemId(rs.getInt("item_id"));
        movement.setItemName(rs.getString("item_name"));
        movement.setSerialNo(rs.getString("serial_no"));
        movement.setMoveType(rs.getString("move_type"));

        int invoiceId = rs.getInt("ref_invoice_id");
        movement.setRefInvoiceId(rs.wasNull() ? null : invoiceId);

        int poId = rs.getInt("ref_po_id");
        movement.setRefPoId(rs.wasNull() ? null : poId);

        Timestamp ts = rs.getTimestamp("move_date");
        if (ts != null) {
            movement.setMoveDate(ts.toLocalDateTime());
        }

        movement.setNote(rs.getString("note"));
        return movement;
    }
}