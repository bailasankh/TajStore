-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: taj_store
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(80) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `idx_category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Ring','2026-03-07 12:59:33'),(2,'Necklace','2026-03-07 12:59:33'),(3,'Bracelet','2026-03-07 12:59:33'),(4,'Earrings','2026-03-07 12:59:33');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Mohammad Ali','0599111111','Nablus','2026-03-07 12:57:45'),(2,'Sara Hasan','0599222222','Ramallah','2026-03-07 12:57:45'),(4,'Omer Yasin','0599333333','Jenin','2026-03-30 17:31:40'),(6,'khaled','0569899999','tubas','2026-05-05 09:58:23'),(7,'Yara','0569555555','Nablus','2026-05-05 09:58:23'),(8,'sara','0569888888','ramallah','2026-05-05 09:58:23');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT '0.00',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`employee_id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Aseel Ahmad','0599000001','2024-01-10',3500.00,1,'2026-03-07 12:54:05'),(2,'Bailasan Tarboush','0599000002','2024-02-15',3200.00,1,'2026-03-07 12:54:05'),(3,'Lina Saleh','0599000003','2024-03-01',3000.00,1,'2026-03-07 12:54:05');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gold_item`
--

DROP TABLE IF EXISTS `gold_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gold_item` (
  `item_id` int NOT NULL AUTO_INCREMENT,
  `item_name` varchar(120) NOT NULL,
  `serial_no` varchar(60) NOT NULL,
  `category_id` int NOT NULL,
  `weight_gram` decimal(10,3) NOT NULL,
  `karat` tinyint NOT NULL,
  `making_cost` decimal(10,2) DEFAULT '0.00',
  `image_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `serial_no` (`serial_no`),
  KEY `fk_item_category` (`category_id`),
  KEY `idx_item_name` (`item_name`),
  CONSTRAINT `fk_item_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_item`
--

LOCK TABLES `gold_item` WRITE;
/*!40000 ALTER TABLE `gold_item` DISABLE KEYS */;
INSERT INTO `gold_item` VALUES (1,'Classic Gold Ring','SN1001',1,5.500,21,50.00,'C:\\Users\\HP\\Downloads\\gold\\classic-ring.png',1,'2026-03-07 12:59:43'),(2,'Diamond Necklace','SN1002',2,12.300,21,120.00,'C:\\Users\\HP\\Downloads\\gold\\diamond-necklac.png',1,'2026-03-07 12:59:43'),(3,'Luxury Bracelet','SN1003',3,8.200,21,70.00,'C:\\Users\\HP\\Downloads\\gold\\luxury-bracelet.png',1,'2026-03-07 12:59:43'),(4,'Luxury Earrings','SN1004',4,4.200,21,45.00,'C:\\Users\\HP\\Downloads\\gold\\Luxury - Earrings.png',1,'2026-05-09 15:22:36'),(5,'Royal Ring','SN1005',3,6.100,24,65.00,'C:\\Users\\HP\\Downloads\\gold\\ring2.png',1,'2026-05-09 15:41:15'),(6,'Pearl Necklace','SN1006',3,11.800,18,95.00,'C:\\Users\\HP\\Downloads\\gold\\nec2.png',1,'2026-05-09 15:42:31'),(7,'Channl Earrings','SN1007',3,4.200,24,50.00,'C:\\Users\\HP\\Downloads\\gold\\brac2.png',1,'2026-05-09 15:43:30');
/*!40000 ALTER TABLE `gold_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gold_price_history`
--

DROP TABLE IF EXISTS `gold_price_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gold_price_history` (
  `price_id` int NOT NULL AUTO_INCREMENT,
  `price_date` date NOT NULL,
  `price_per_gram_24k` decimal(10,2) NOT NULL,
  `price_per_gram_21k` decimal(10,2) NOT NULL,
  `price_per_gram_18k` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`price_id`),
  UNIQUE KEY `price_date` (`price_date`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gold_price_history`
--

LOCK TABLES `gold_price_history` WRITE;
/*!40000 ALTER TABLE `gold_price_history` DISABLE KEYS */;
INSERT INTO `gold_price_history` VALUES (1,'2026-03-01',240.00,210.00,180.00,'2026-03-07 13:01:34'),(2,'2026-03-02',242.00,212.00,182.00,'2026-03-07 13:01:34'),(3,'2026-03-03',245.00,215.00,185.00,'2026-03-07 13:01:34'),(4,'2026-05-05',240.00,230.00,220.00,'2026-05-05 08:56:45'),(5,'2026-05-09',245.00,235.00,225.00,'2026-05-09 14:01:07');
/*!40000 ALTER TABLE `gold_price_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `inventory_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `qty` int NOT NULL DEFAULT '0',
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`inventory_id`),
  UNIQUE KEY `item_id` (`item_id`),
  CONSTRAINT `fk_inv_item` FOREIGN KEY (`item_id`) REFERENCES `gold_item` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,1,1,'2026-03-07 13:00:35'),(2,2,3,'2026-05-09 16:02:16'),(3,3,3,'2026-05-09 16:01:54'),(4,5,3,'2026-05-09 16:01:14'),(5,4,3,'2026-05-09 15:48:24'),(6,7,2,'2026-05-09 16:00:40');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movement`
--

DROP TABLE IF EXISTS `inventory_movement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_movement` (
  `move_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `move_type` enum('IN','OUT','ADJUST') NOT NULL,
  `ref_invoice_id` int DEFAULT NULL,
  `ref_po_id` int DEFAULT NULL,
  `move_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`move_id`),
  KEY `fk_move_item` (`item_id`),
  KEY `fk_move_invoice` (`ref_invoice_id`),
  KEY `fk_move_po` (`ref_po_id`),
  CONSTRAINT `fk_move_invoice` FOREIGN KEY (`ref_invoice_id`) REFERENCES `invoice` (`invoice_id`),
  CONSTRAINT `fk_move_item` FOREIGN KEY (`item_id`) REFERENCES `gold_item` (`item_id`),
  CONSTRAINT `fk_move_po` FOREIGN KEY (`ref_po_id`) REFERENCES `purchase_order` (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movement`
--

LOCK TABLES `inventory_movement` WRITE;
/*!40000 ALTER TABLE `inventory_movement` DISABLE KEYS */;
INSERT INTO `inventory_movement` VALUES (1,1,'OUT',1,NULL,'2026-03-07 17:07:22','Sold to customer'),(2,2,'IN',NULL,1,'2026-03-07 17:07:22','Purchased from supplier'),(3,5,'IN',NULL,2,'2026-05-09 18:47:51','Purchased from supplier'),(4,4,'IN',NULL,3,'2026-05-09 18:48:24','Purchased from supplier'),(5,5,'OUT',2,NULL,'2026-05-09 18:50:07','Sold to customer'),(6,7,'IN',NULL,4,'2026-05-09 19:00:40','Purchased from supplier'),(7,5,'IN',NULL,5,'2026-05-09 19:01:14','Purchased from supplier'),(8,3,'IN',NULL,6,'2026-05-09 19:01:54','Purchased from supplier'),(9,2,'IN',NULL,7,'2026-05-09 19:02:16','Purchased from supplier');
/*!40000 ALTER TABLE `inventory_movement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `invoice_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `invoice_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` enum('PAID','PARTIAL','UNPAID') NOT NULL DEFAULT 'UNPAID',
  PRIMARY KEY (`invoice_id`),
  KEY `fk_invoice_customer` (`customer_id`),
  KEY `fk_invoice_employee` (`employee_id`),
  CONSTRAINT `fk_invoice_customer` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `fk_invoice_employee` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,1,2,'2026-03-04 00:00:00',600.00,'PAID'),(2,6,2,'2026-05-09 18:50:07',420.00,'PAID');
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_details`
--

DROP TABLE IF EXISTS `invoice_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_details` (
  `invoice_detail_id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `item_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `sale_price` decimal(12,2) NOT NULL,
  `gold_price_at_sale` decimal(10,2) DEFAULT NULL,
  `making_cost_at_sale` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`invoice_detail_id`),
  UNIQUE KEY `uq_inv_item` (`item_id`),
  KEY `fk_invdet_invoice` (`invoice_id`),
  CONSTRAINT `fk_invdet_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`),
  CONSTRAINT `fk_invdet_item` FOREIGN KEY (`item_id`) REFERENCES `gold_item` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_details`
--

LOCK TABLES `invoice_details` WRITE;
/*!40000 ALTER TABLE `invoice_details` DISABLE KEYS */;
INSERT INTO `invoice_details` VALUES (1,1,1,1,600.00,215.00,50.00),(2,2,5,1,420.00,230.00,65.00);
/*!40000 ALTER TABLE `invoice_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `method_id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `fk_payment_invoice` (`invoice_id`),
  KEY `fk_payment_method` (`method_id`),
  CONSTRAINT `fk_payment_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`),
  CONSTRAINT `fk_payment_method` FOREIGN KEY (`method_id`) REFERENCES `payment_method` (`method_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,1,1,600.00,'2026-03-07 17:07:10','Full payment'),(2,2,1,420.00,'2026-05-09 18:50:07','Paid in full');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_method`
--

DROP TABLE IF EXISTS `payment_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_method` (
  `method_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`method_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_method`
--

LOCK TABLES `payment_method` WRITE;
/*!40000 ALTER TABLE `payment_method` DISABLE KEYS */;
INSERT INTO `payment_method` VALUES (2,'Card'),(1,'Cash'),(3,'Transfer');
/*!40000 ALTER TABLE `payment_method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_details`
--

DROP TABLE IF EXISTS `purchase_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_details` (
  `purchase_details_id` int NOT NULL AUTO_INCREMENT,
  `purchase_id` int NOT NULL,
  `item_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`purchase_details_id`),
  KEY `fk_pd_purchase` (`purchase_id`),
  KEY `fk_pd_item` (`item_id`),
  CONSTRAINT `fk_pd_item` FOREIGN KEY (`item_id`) REFERENCES `gold_item` (`item_id`),
  CONSTRAINT `fk_pd_purchase` FOREIGN KEY (`purchase_id`) REFERENCES `purchase_order` (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_details`
--

LOCK TABLES `purchase_details` WRITE;
/*!40000 ALTER TABLE `purchase_details` DISABLE KEYS */;
INSERT INTO `purchase_details` VALUES (1,1,1,1,200.00,200.00),(2,1,2,1,350.00,350.00),(3,2,5,2,230.00,460.00),(4,3,4,3,180.00,540.00),(5,4,7,2,180.00,360.00),(6,5,5,2,230.00,460.00),(7,6,3,2,260.00,520.00),(8,7,2,2,350.00,700.00);
/*!40000 ALTER TABLE `purchase_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order` (
  `purchase_id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `purchase_date` date NOT NULL,
  `total_amount` decimal(12,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`purchase_id`),
  KEY `fk_po_supplier` (`supplier_id`),
  KEY `fk_po_employee` (`employee_id`),
  CONSTRAINT `fk_po_employee` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`),
  CONSTRAINT `fk_po_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order`
--

LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` VALUES (1,1,1,'2026-03-01',5000.00,'2026-03-07 13:06:08'),(2,5,3,'2026-05-09',460.00,'2026-05-09 15:47:51'),(3,2,3,'2026-05-09',540.00,'2026-05-09 15:48:24'),(4,1,1,'2026-05-09',360.00,'2026-05-09 16:00:40'),(5,5,1,'2026-05-09',460.00,'2026-05-09 16:01:14'),(6,2,3,'2026-05-09',520.00,'2026-05-09 16:01:54'),(7,5,1,'2026-05-09',700.00,'2026-05-09 16:02:16');
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Admin'),(3,'Cashier'),(2,'Manager');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(120) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'Golden Supply Co','0599444444','Dubai','2026-03-07 12:59:06'),(2,'Middle East Gold','0599555555','Amman','2026-03-07 12:59:06'),(5,'Elite Supply','0599001122','USA','2026-05-09 15:37:20');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_table`
--

DROP TABLE IF EXISTS `test_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_table` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_table`
--

LOCK TABLES `test_table` WRITE;
/*!40000 ALTER TABLE `test_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_account`
--

DROP TABLE IF EXISTS `user_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_account` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `salt` varchar(64) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `role_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_user_role` (`role_id`),
  CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_account`
--

LOCK TABLES `user_account` WRITE;
/*!40000 ALTER TABLE `user_account` DISABLE KEYS */;
INSERT INTO `user_account` VALUES (1,'admin','admin',NULL,'System Administrator',1,1,'2026-03-30 11:17:12'),(2,'afnan_1','123456',NULL,'afnan esam',1,1,'2026-03-30 17:05:18'),(3,'afnan','123456','','afnan esam',1,1,'2026-03-30 20:09:48'),(4,'afnan1','123456','','afnan1',1,3,'2026-04-02 00:40:23'),(5,'afnan2','123456','','afnan2',1,2,'2026-04-02 00:41:25'),(6,'bailasan','0946082630831f423b9a7d559e00c10818aebd4c3e6962605a38019d869f7573','wvkIUf2MDquwkDvEuWtTVA==','bailasan',1,1,'2026-05-05 03:12:39'),(7,'bailasan.c','432ea74a1d38886619600324ee193a3ea7a251de0fdf65647719f247cce22da2','AogpmQQCsRflK4XdlYe2Dg==','bailasanCashier',1,3,'2026-05-05 12:07:46'),(8,'bailasan.m','2dfe7b3a2e3eb648c2fe05d5690b6f93fc787a06462b8cbc0c8df341cbd367ec','dd34WmmFhdjAwyU+v0jZQQ==','bailasanManager',1,2,'2026-05-05 12:08:55'),(9,'esam','d610038f6b11fa0c7b110fcbac3a965335db40e1fa201e7cec9e3f6750bd4d39','tZM0fazL87+UmoWhlfuA0g==','hala',1,1,'2026-05-09 10:58:54');
/*!40000 ALTER TABLE `user_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'taj_store'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-09 21:34:00
