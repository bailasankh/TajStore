package com.tajstore.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class NotificationUtil {

    private static final Color INFO_BG = new Color(28, 18, 12, 235);
    private static final Color SUCCESS_BG = new Color(24, 45, 28, 235);
    private static final Color WARNING_BG = new Color(90, 60, 15, 235);
    private static final Color ERROR_BG = new Color(80, 22, 22, 235);

    private static final Color GOLD = new Color(224, 190, 78);
    private static final Color TEXT = new Color(255, 248, 235);

    public static void showInfo(Component parent, String message) {
        showToast(parent, message, INFO_BG, "ℹ");
    }

    public static void showSuccess(Component parent, String message) {
        showToast(parent, message, SUCCESS_BG, "✔");
    }

    public static void showWarning(Component parent, String message) {
        showToast(parent, message, WARNING_BG, "⚠");
    }

    public static void showError(Component parent, String message) {
        showToast(parent, message, ERROR_BG, "✖");
    }

    private static void showToast(Component parent, String message, Color bgColor, String iconText) {
        Window owner = parent != null ? SwingUtilities.getWindowAncestor(parent) : null;
        JWindow toast = owner != null ? new JWindow(owner) : new JWindow();

        JPanel panel = new JPanel(new BorderLayout(12, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(bgColor);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);

                g2.setColor(new Color(212, 175, 55, 95));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 22, 22);

                g2.dispose();
                super.paintComponent(g);
            }
        };
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(14, 16, 14, 16));

        JLabel iconLabel = new JLabel(iconText);
        iconLabel.setForeground(GOLD);
        iconLabel.setFont(new Font("Segoe UI Symbol", Font.BOLD, 18));

        JLabel messageLabel = new JLabel("<html><body style='width:260px'>" + message + "</body></html>");
        messageLabel.setForeground(TEXT);
        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        panel.add(iconLabel, BorderLayout.WEST);
        panel.add(messageLabel, BorderLayout.CENTER);

        toast.setBackground(new Color(0, 0, 0, 0));
        toast.setContentPane(panel);
        toast.pack();

        int x;
        int y;

        if (owner != null) {
            int margin = 20;
            x = owner.getX() + owner.getWidth() - toast.getWidth() - margin;
            y = owner.getY() + margin + 50;
        } else {
            Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
            x = screen.width - toast.getWidth() - 30;
            y = 40;
        }

        toast.setLocation(x, y);

        try {
            toast.setOpacity(0f);
        } catch (Exception e) {
            toast.setVisible(true);
            new Timer(2500, ev -> toast.dispose()).start();
            return;
        }

        toast.setVisible(true);

        Timer fadeIn = new Timer(20, null);
        fadeIn.addActionListener(e -> {
            float opacity = toast.getOpacity() + 0.08f;
            if (opacity >= 1f) {
                toast.setOpacity(1f);
                fadeIn.stop();

                Timer hold = new Timer(2200, ev -> {
                    Timer fadeOut = new Timer(20, null);
                    fadeOut.addActionListener(ev2 -> {
                        float out = toast.getOpacity() - 0.08f;
                        if (out <= 0f) {
                            toast.setOpacity(0f);
                            fadeOut.stop();
                            toast.dispose();
                        } else {
                            toast.setOpacity(out);
                        }
                    });
                    fadeOut.start();
                });
                hold.setRepeats(false);
                hold.start();
            } else {
                toast.setOpacity(opacity);
            }
        });
        fadeIn.start();
    }
}