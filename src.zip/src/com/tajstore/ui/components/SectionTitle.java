package com.tajstore.ui.components;

import com.tajstore.theme.UIStyle;
import com.tajstore.theme.ThemeManager;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Component;

public class SectionTitle extends JPanel {

    private final JLabel titleLabel;
    private final JLabel subtitleLabel;

    public SectionTitle(String title, String subtitle) {
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setAlignmentX(Component.LEFT_ALIGNMENT);

        titleLabel = new JLabel(title);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        titleLabel.setFont(UIStyle.FONT_TITLE);
        titleLabel.setForeground(ThemeManager.getTheme().getText());

        subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        subtitleLabel.setFont(UIStyle.FONT_SUBTITLE);
        subtitleLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        add(titleLabel);
        add(Box.createVerticalStrut(6));
        add(subtitleLabel);
    }

    public void setTitleText(String text) {
        titleLabel.setText(text);
    }

    public void setSubtitleText(String text) {
        subtitleLabel.setText(text);
    }
}