package com.tajstore.ui.sales;

import com.tajstore.model.InvoiceHistoryRow;
import com.tajstore.service.InvoiceHistoryService;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.ModernTable;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SearchPanel;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.util.List;

public class InvoiceHistoryPanel extends BasePanel {

    private final InvoiceHistoryService invoiceHistoryService = new InvoiceHistoryService();

    private ModernTable invoiceTable;
    private DefaultTableModel tableModel;
    private SearchPanel searchPanel;
    private JLabel summaryLabel;

    public InvoiceHistoryPanel() {
        initUI();
        loadInvoices();
    }

    // === 1. دالة الخلفية الملكية ===
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int width = getWidth();
        int height = getHeight();
        g2d.setColor(ThemeManager.isDarkMode() ? new Color(5, 2, 2) : new Color(248, 244, 236));
        g2d.fillRect(0, 0, width, height);

        Point center = new Point(width / 2, 0);
        float radius = Math.max(width, height) * 0.9f;
        float[] dist = {0.0f, 0.4f, 1.0f};
        Color[] colors = {
            ThemeManager.isDarkMode() ? new Color(70, 40, 10, 180) : new Color(201, 162, 39, 65),
            ThemeManager.isDarkMode() ? new Color(35, 18, 5, 100) : new Color(201, 162, 39, 30),
            new Color(0, 0, 0, 0)
        };
        RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
        g2d.setPaint(spotlight);
        g2d.fillRect(0, 0, width, height);
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(16, 16));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setOpaque(false); // مهم عشان الخلفية تبان

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTableSection(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel mainHeader = new JPanel(new BorderLayout(12, 12));
        mainHeader.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle(
                "Invoice History",
                "View sales invoices and open invoice details"
        );

        // === شريط أدوات زجاجي واحد يجمع البحث والأزرار ===
        JPanel toolBarCard = new JPanel(new BorderLayout(10, 10));
        toolBarCard.setOpaque(true);
        toolBarCard.setBackground(glassColor()); // خلفية متوافقة مع الثيم
        toolBarCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(10, 16, 10, 16)
        ));

        searchPanel = new SearchPanel();
        searchPanel.getSearchButton().addActionListener(e -> searchInvoices());
        searchPanel.getRefreshButton().addActionListener(e -> loadInvoices());

        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actionsPanel.setOpaque(false);

        PrimaryButton openDetailsButton = new PrimaryButton("Open Details");
        SecondaryButton reloadButton = new SecondaryButton("Reload");

        openDetailsButton.addActionListener(e -> openInvoiceDetails());
        reloadButton.addActionListener(e -> loadInvoices());

        actionsPanel.add(openDetailsButton);
        actionsPanel.add(reloadButton);

        toolBarCard.add(searchPanel, BorderLayout.CENTER);
        toolBarCard.add(actionsPanel, BorderLayout.EAST);

        mainHeader.add(sectionTitle, BorderLayout.WEST);
        mainHeader.add(toolBarCard, BorderLayout.EAST);

        return mainHeader;
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(true);
        
        // === 2. الكارت الزجاجي الداكن ===
        panel.setBackground(glassColor()); 
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(14, 14, 14, 14)
        ));

        // === 3. شريط الإحصائيات الذهبي ===
        JPanel summaryStrip = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        summaryStrip.setOpaque(true);
        summaryStrip.setBackground(innerGlassColor()); 
        summaryStrip.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderSoftColor(), 1, true),
                BorderFactory.createEmptyBorder(10, 16, 10, 16)
        ));

        JLabel lbl = new JLabel("Total Invoices: ");
        lbl.setFont(UIStyle.FONT_BODY);
        lbl.setForeground(ThemeManager.getTheme().getTextMuted());
        
        summaryLabel = new JLabel("0");
        summaryLabel.setFont(UIStyle.FONT_HEADING);
        summaryLabel.setForeground(new Color(224, 190, 78)); // ذهبي

        JLabel hint = new JLabel("  |  Double-click any row to open details");
        hint.setFont(UIStyle.FONT_SMALL);
        hint.setForeground(ThemeManager.getTheme().getTextMuted());

        summaryStrip.add(lbl);
        summaryStrip.add(summaryLabel);
        summaryStrip.add(hint);

        // === إعداد الجدول ===
        tableModel = new DefaultTableModel(
                new Object[]{"Invoice ID", "Customer", "Employee", "Invoice Date", "Total Amount", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        invoiceTable = new ModernTable();
        invoiceTable.setModel(tableModel);
        
        // === 4. توزيع الأعمدة وتوسيعها عشان ما تتهشم ===
        invoiceTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        invoiceTable.getColumnModel().getColumn(0).setPreferredWidth(100); // Invoice ID
        invoiceTable.getColumnModel().getColumn(1).setPreferredWidth(180); // Customer
        invoiceTable.getColumnModel().getColumn(2).setPreferredWidth(150); // Employee
        invoiceTable.getColumnModel().getColumn(3).setPreferredWidth(180); // Invoice Date
        invoiceTable.getColumnModel().getColumn(4).setPreferredWidth(130); // Total Amount
        invoiceTable.getColumnModel().getColumn(5).setPreferredWidth(100); // Status

        // تحسين النقر المزدوج لفتح الفاتورة
        invoiceTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    openInvoiceDetails();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(invoiceTable);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        // وضع الشريط فوق الجدول
        panel.add(summaryStrip, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void loadInvoices() {
        try {
            fillTable(invoiceHistoryService.getAllInvoices());
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void searchInvoices() {
        try {
            fillTable(invoiceHistoryService.searchInvoices(searchPanel.getSearchText()));
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void fillTable(List<InvoiceHistoryRow> invoices) {
        tableModel.setRowCount(0);

        for (InvoiceHistoryRow invoice : invoices) {
            tableModel.addRow(new Object[]{
                    invoice.getInvoiceId(),
                    invoice.getCustomerName(),
                    invoice.getEmployeeName(),
                    invoice.getInvoiceDate(),
                    invoice.getTotalAmount(),
                    invoice.getStatus()
            });
        }

        // === تحديث شريط الإحصائيات بالرقم الجديد ===
        if (summaryLabel != null) {
            summaryLabel.setText(String.valueOf(invoices.size()));
        }
    }

    private Color glassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 120) : new Color(255, 255, 255, 215);
    }

    private Color innerGlassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 100) : new Color(248, 248, 248, 220);
    }

    private Color borderColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 80) : ThemeManager.getTheme().getBorder();
    }

    private Color borderSoftColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 50) : new Color(201, 162, 39, 90);
    }

    private void openInvoiceDetails() {
        int selectedRow = invoiceTable.getSelectedRow();
        if (selectedRow == -1) {
            MessageUtil.showError(this, "Please select an invoice.");
            return;
        }

        int invoiceId = (Integer) tableModel.getValueAt(selectedRow, 0);

        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        InvoiceDetailsDialog dialog = new InvoiceDetailsDialog(owner, invoiceId);
        dialog.setVisible(true);
    }
}