package com.tajstore.ui.purchase;

import com.tajstore.model.Employee;
import com.tajstore.model.PurchaseItemOption;
import com.tajstore.model.Supplier;
import com.tajstore.service.PurchaseService;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SearchPanel;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.math.BigDecimal;
import java.util.List;

public class PurchasePanel extends BasePanel {

    private final PurchaseService purchaseService = new PurchaseService();

    private JComboBox<Supplier> supplierComboBox;
    private JComboBox<Employee> employeeComboBox;
    private JComboBox<PurchaseItemOption> itemComboBox;
    private JTextField quantityField;
    private JTextField pricePerUnitField;
    private JLabel itemInfoLabel;
    private JLabel subtotalLabel;
    private JLabel helperLabel;
    private SearchPanel searchPanel;
    private PrimaryButton createPurchaseButton;

    public PurchasePanel() {
        initUI();
        loadData();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int width = getWidth();
        int height = getHeight();
        g2d.setColor(ThemeManager.isDarkMode() ? new Color(5, 2, 2) : new Color(248, 244, 236));
        g2d.fillRect(0, 0, width, height);

        Point center = new Point(width / 2, 0);
        float radius = Math.max(width, height) * 0.9f;
        float[] dist = {0.0f, 0.4f, 1.0f};
        Color[] colors = {
            ThemeManager.isDarkMode() ? new Color(70, 40, 10, 180) : new Color(201, 162, 39, 65),
            ThemeManager.isDarkMode() ? new Color(35, 18, 5, 100) : new Color(201, 162, 39, 30),
            new Color(0, 0, 0, 0)
        };
        RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
        g2d.setPaint(spotlight);
        g2d.fillRect(0, 0, width, height);
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(16, 16));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setOpaque(false);

        add(buildHeader(), BorderLayout.NORTH);
        add(buildFormCard(), BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    private JPanel buildHeader() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle(
                "Purchases",
                "Create purchase order and increase stock"
        );

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setOpaque(false);

        searchPanel = new SearchPanel();
        searchPanel.getSearchField().setText("Reload suppliers, staff, and items");
        searchPanel.getSearchField().setEditable(false);
        searchPanel.getSearchButton().setVisible(false);

        SecondaryButton refreshButton = searchPanel.getRefreshButton();
        refreshButton.addActionListener(e -> loadData());

        rightPanel.add(searchPanel);

        panel.add(sectionTitle, BorderLayout.WEST);
        panel.add(rightPanel, BorderLayout.EAST);

        return panel;
    }

    private JPanel buildFormCard() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(glassColor());
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(24, 24, 24, 24)
        ));

        supplierComboBox = new JComboBox<>();
        employeeComboBox = new JComboBox<>();
        itemComboBox = new JComboBox<>();
        quantityField = new JTextField();
        pricePerUnitField = new JTextField();

        UIStyle.styleField(supplierComboBox);
        UIStyle.styleField(employeeComboBox);
        UIStyle.styleField(itemComboBox);
        UIStyle.styleField(quantityField);
        UIStyle.styleField(pricePerUnitField);

        itemInfoLabel = new JLabel("Select an item to view details.");
        itemInfoLabel.setFont(UIStyle.FONT_BODY);
        itemInfoLabel.setForeground(ThemeManager.getTheme().getPrimary());

        subtotalLabel = new JLabel("0.00");
        subtotalLabel.setFont(UIStyle.FONT_TITLE);
        subtotalLabel.setForeground(ThemeManager.getTheme().getPrimary());

        helperLabel = new JLabel("Review the available supplier, employee, and item lists before saving.");
        helperLabel.setFont(UIStyle.FONT_SMALL);
        helperLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        itemComboBox.addActionListener(e -> updateSelectedItemInfo());
        createPurchaseButton = new PrimaryButton("Create Purchase");
        createPurchaseButton.addActionListener(e -> createPurchase());

        quantityField.getDocument().addDocumentListener(new SimpleDocumentListener(this::updateSubtotal));
        pricePerUnitField.getDocument().addDocumentListener(new SimpleDocumentListener(this::updateSubtotal));

        JPanel topFieldsGrid = new JPanel(new GridLayout(3, 2, 20, 12));
        topFieldsGrid.setOpaque(false);
        topFieldsGrid.add(createLabeledField("Supplier", supplierComboBox));
        topFieldsGrid.add(createLabeledField("Quantity", quantityField));
        topFieldsGrid.add(createLabeledField("Employee", employeeComboBox));
        topFieldsGrid.add(createLabeledField("Price Per Unit", pricePerUnitField));
        topFieldsGrid.add(createLabeledField("Gold Item", itemComboBox));

        JPanel empty = new JPanel();
        empty.setOpaque(false);
        topFieldsGrid.add(empty);

        form.add(topFieldsGrid);
        form.add(Box.createVerticalStrut(12));
        form.add(helperLabel);
        form.add(Box.createVerticalStrut(10));
        form.add(createItemInfoCard());
        form.add(Box.createVerticalStrut(20));

        JScrollPane scrollPane = new JScrollPane(form);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));

        outer.add(scrollPane, BorderLayout.CENTER);
        outer.add(buildBottomTotalBar(), BorderLayout.SOUTH);
        return outer;
    }

    private JPanel createItemInfoCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setOpaque(true);
        card.setBackground(innerGlassColor());
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderSoftColor(), 1, true),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        card.add(itemInfoLabel, BorderLayout.WEST);
        return card;
    }

    private JPanel buildBottomTotalBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(true);
        bar.setBackground(innerGlassColor());
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderSoftColor(), 1, true),
                BorderFactory.createEmptyBorder(16, 24, 16, 24)
        ));

        JLabel totalLabel = new JLabel("Subtotal Due:");
        totalLabel.setFont(UIStyle.FONT_SUBTITLE);
        totalLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftPanel.setOpaque(false);
        leftPanel.add(totalLabel);
        leftPanel.add(subtotalLabel);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(createPurchaseButton);

        bar.add(leftPanel, BorderLayout.WEST);
        bar.add(rightPanel, BorderLayout.EAST);

        return bar;
    }

    private JPanel createLabeledField(String labelText, JComponent field) {
        JPanel panel = new JPanel(new GridLayout(2, 1, 0, 6));
        panel.setOpaque(false);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());

        panel.add(label);
        panel.add(field);
        return panel;
    }

    private void loadData() {
        try {
            List<Supplier> suppliers = purchaseService.getSuppliers();
            List<Employee> employees = purchaseService.getEmployees();
            List<PurchaseItemOption> items = purchaseService.getItems();

            supplierComboBox.removeAllItems();
            for (Supplier supplier : suppliers) {
                supplierComboBox.addItem(supplier);
            }

            employeeComboBox.removeAllItems();
            for (Employee employee : employees) {
                employeeComboBox.addItem(employee);
            }

            itemComboBox.removeAllItems();
            for (PurchaseItemOption item : items) {
                itemComboBox.addItem(item);
            }

            createPurchaseButton.setEnabled(!suppliers.isEmpty() && !employees.isEmpty() && !items.isEmpty());
            helperLabel.setText(buildAvailabilityMessage(suppliers, employees, items));
            updateSelectedItemInfo();
            updateSubtotal();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void updateSelectedItemInfo() {
        PurchaseItemOption item = (PurchaseItemOption) itemComboBox.getSelectedItem();

        if (item == null) {
            itemInfoLabel.setText("No purchasable gold item is available yet. Add stock first, then return here.");
            return;
        }

        itemInfoLabel.setText(
                "Category: " + item.getCategoryName()
                        + " | Weight: " + item.getWeightGram()
                        + " | Karat: " + item.getKarat()
                        + " | Making Cost: " + item.getMakingCost()
        );

        if (pricePerUnitField.getText().trim().isEmpty() && item.getMakingCost() != null) {
            pricePerUnitField.setText(item.getMakingCost().toPlainString());
        }
    }

    private void updateSubtotal() {
        try {
            int qty = Integer.parseInt(quantityField.getText().trim());
            BigDecimal price = new BigDecimal(pricePerUnitField.getText().trim());
            BigDecimal subtotal = price.multiply(BigDecimal.valueOf(qty));
            subtotalLabel.setText(subtotal.toPlainString());
        } catch (Exception e) {
            subtotalLabel.setText("0.00");
        }
    }

    private void createPurchase() {
        try {
            Supplier supplier = (Supplier) supplierComboBox.getSelectedItem();
            Employee employee = (Employee) employeeComboBox.getSelectedItem();
            PurchaseItemOption item = (PurchaseItemOption) itemComboBox.getSelectedItem();
            validatePurchaseForm(supplier, employee, item);

            int purchaseId = purchaseService.createPurchase(
                    supplier,
                    employee,
                    item,
                    quantityField.getText(),
                    pricePerUnitField.getText()
            );

            MessageUtil.showSuccess(this, "Purchase saved successfully. Reference ID: " + purchaseId);

            quantityField.setText("");
            pricePerUnitField.setText("");
            subtotalLabel.setText("0.00");
            loadData();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void validatePurchaseForm(Supplier supplier, Employee employee, PurchaseItemOption item) {
        if (supplier == null || employee == null || item == null) {
            throw new IllegalArgumentException("Please reload the lists and make sure supplier, employee, and gold item are selected.");
        }

        String quantityText = quantityField.getText().trim();
        if (quantityText.isEmpty()) {
            throw new IllegalArgumentException("Please enter a quantity before creating the purchase.");
        }

        String priceText = pricePerUnitField.getText().trim();
        if (priceText.isEmpty()) {
            throw new IllegalArgumentException("Please enter the purchase price per unit.");
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Quantity must be a whole number greater than zero.");
        }

        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }

        BigDecimal unitPrice;
        try {
            unitPrice = new BigDecimal(priceText);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Price per unit must be a valid number.");
        }

        if (unitPrice.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Price per unit must be greater than zero.");
        }
    }

    private String buildAvailabilityMessage(List<Supplier> suppliers, List<Employee> employees, List<PurchaseItemOption> items) {
        if (suppliers.isEmpty() || employees.isEmpty() || items.isEmpty()) {
            return "Some required lists are empty. Make sure suppliers, employees, and gold items are available before saving.";
        }
        return "Ready to create a purchase. Pick the records, review the subtotal, then save.";
    }

    private Color glassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 120) : new Color(255, 255, 255, 215);
    }

    private Color innerGlassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 160) : new Color(248, 248, 248, 220);
    }

    private Color borderColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 80) : ThemeManager.getTheme().getBorder();
    }

    private Color borderSoftColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 100) : new Color(201, 162, 39, 90);
    }

    private static class SimpleDocumentListener implements javax.swing.event.DocumentListener {
        private final Runnable onChange;

        private SimpleDocumentListener(Runnable onChange) {
            this.onChange = onChange;
        }

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            onChange.run();
        }
    }
}
