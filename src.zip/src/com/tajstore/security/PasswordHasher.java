package com.tajstore.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordHasher {

    private PasswordHasher() {
    }

    // === 1. Ã˜ÂªÃ™Ë†Ã™â€žÃ™Å Ã˜Â¯ "Ã™â€¦Ã™â€žÃ˜Â­" Ã˜Â¹Ã˜Â´Ã™Ë†Ã˜Â§Ã˜Â¦Ã™Å  Ã™ÂÃ˜Â§Ã˜Â¦Ã™â€š Ã˜Â§Ã™â€žÃ˜Â£Ã™â€¦Ã˜Â§Ã™â€  Ã™â€žÃ™Æ’Ã™â€ž Ã™â€¦Ã˜Â³Ã˜ÂªÃ˜Â®Ã˜Â¯Ã™â€¦ ===
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    // === 2. Ã˜Â§Ã™â€žÃ˜ÂªÃ˜Â´Ã™ÂÃ™Å Ã˜Â± Ã˜Â§Ã™â€žÃ˜Â¬Ã˜Â¯Ã™Å Ã˜Â¯: Ã˜Â§Ã™â€žÃ˜Â¨Ã˜Â§Ã˜Â³Ã™Ë†Ã˜Â±Ã˜Â¯ + Ã˜Â§Ã™â€žÃ™â€¦Ã™â€žÃ˜Â­ ===
    public static String hash(String plainTextPassword, String salt) {
        if (plainTextPassword == null || plainTextPassword.isBlank()) {
            throw new IllegalArgumentException("Password cannot be empty.");
        }

        try {
            // Ã™â€žÃ˜ÂµÃ™â€š Ã˜Â§Ã™â€žÃ™â€¦Ã™â€žÃ˜Â­ Ã˜Â¨Ã˜Â§Ã™â€žÃ˜Â¨Ã˜Â§Ã˜Â³Ã™Ë†Ã˜Â±Ã˜Â¯ Ã˜Â¹Ã˜Â´Ã˜Â§Ã™â€  Ã™Å Ã˜ÂµÃ˜Â¹Ã˜Â¨ Ã˜Â§Ã™â€žÃ˜ÂªÃ˜Â®Ã™â€¦Ã™Å Ã™â€ 
            String saltedPassword = plainTextPassword + salt;
            
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(saltedPassword.getBytes(StandardCharsets.UTF_8));

            StringBuilder hex = new StringBuilder();
            for (byte b : hashBytes) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error while hashing password.", e);
        }
    }

    // === 3. Ã˜Â¯Ã˜Â§Ã™â€žÃ˜Â© Ã˜Â§Ã™â€žÃ˜ÂªÃ˜Â­Ã™â€šÃ™â€š Ã˜Â§Ã™â€žÃ˜Â§Ã˜Â­Ã˜ÂªÃ˜Â±Ã˜Â§Ã™ÂÃ™Å Ã˜Â© (Ã˜Â¨Ã˜ÂªÃ™â€šÃ˜Â§Ã˜Â±Ã™â€  Ã˜Â§Ã™â€žÃ™â€¦Ã˜Â¯Ã˜Â®Ã™â€ž Ã™â€¦Ã˜Â¹ Ã˜Â§Ã™â€žÃ™â€¡Ã˜Â§Ã˜Â´ Ã˜Â§Ã™â€žÃ™â€¦Ã˜Â®Ã˜Â²Ã™â€ ) ===
    public static boolean matches(String plainTextPassword, String hashedPassword, String salt) {
        if (plainTextPassword == null || hashedPassword == null) {
            return false;
        }

        if (salt != null && !salt.isBlank()) {
            String newHash = hash(plainTextPassword, salt);
            return newHash.equals(hashedPassword);
        }

        // Support legacy imported accounts that stored either plain text
        // or the older unsalted fallback hash.
        if (plainTextPassword.equals(hashedPassword)) {
            return true;
        }

        String legacyHash = hash(plainTextPassword);
        return legacyHash.equals(hashedPassword);
    }
    
    // === Ã˜Â¯Ã˜Â§Ã™â€žÃ˜Â© Ã™â€šÃ˜Â¯Ã™Å Ã™â€¦Ã˜Â© (Ã˜Â¹Ã˜Â´Ã˜Â§Ã™â€  Ã™â€¦Ã˜Â§ Ã˜ÂªÃ™Æ’Ã˜Â³Ã˜Â± Ã™Æ’Ã™Ë†Ã˜Â¯ Ã™â€šÃ˜Â¯Ã™Å Ã™â€¦ Ã™â€žÃ™Ë† Ã™ÂÃ™Å  Ã™â€¦Ã™Æ’Ã˜Â§Ã™â€  Ã˜ÂªÃ˜Â§Ã™â€ Ã™Å  Ã™â€¦Ã˜Â³Ã˜ÂªÃ˜Â®Ã˜Â¯Ã™â€¦Ã™â€¡Ã˜Â§) ===
    @Deprecated
    public static String hash(String plainTextPassword) {
        return hash(plainTextPassword, "default_static_salt_for_backward_compat");
    }
}