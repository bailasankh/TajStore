package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.Supplier;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SupplierDao {

    private static final String FIND_ALL_SQL =
            "SELECT supplier_id, supplier_name, phone, address, created_at " +
            "FROM supplier ORDER BY supplier_id DESC";

    private static final String SEARCH_SQL =
            "SELECT supplier_id, supplier_name, phone, address, created_at " +
            "FROM supplier " +
            "WHERE supplier_name LIKE ? OR phone LIKE ? " +
            "ORDER BY supplier_id DESC";

    private static final String INSERT_SQL =
            "INSERT INTO supplier (supplier_name, phone, address) VALUES (?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE supplier SET supplier_name = ?, phone = ?, address = ? WHERE supplier_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM supplier WHERE supplier_id = ?";

    private static final String EXISTS_BY_PHONE_SQL =
            "SELECT COUNT(*) FROM supplier WHERE phone = ? AND supplier_id <> ?";

    public List<Supplier> findAll() {
        List<Supplier> suppliers = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                suppliers.add(mapRow(rs));
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to load suppliers.", e);
        }

        return suppliers;
    }

    public List<Supplier> search(String keyword) {
        List<Supplier> suppliers = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_SQL)) {

            String value = "%" + keyword + "%";
            statement.setString(1, value);
            statement.setString(2, value);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    suppliers.add(mapRow(rs));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to search suppliers.", e);
        }

        return suppliers;
    }

    public int insert(Supplier supplier) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, supplier.getSupplierName());
            statement.setString(2, emptyToNull(supplier.getPhone()));
            statement.setString(3, emptyToNull(supplier.getAddress()));

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new RuntimeException("Creating supplier failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }

            throw new RuntimeException("Creating supplier failed, no ID obtained.");

        } catch (SQLIntegrityConstraintViolationException e) {
            throw new IllegalArgumentException("Phone number already exists.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to insert supplier.", e);
        }
    }

    public void update(Supplier supplier) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SQL)) {

            statement.setString(1, supplier.getSupplierName());
            statement.setString(2, emptyToNull(supplier.getPhone()));
            statement.setString(3, emptyToNull(supplier.getAddress()));
            statement.setInt(4, supplier.getSupplierId());

            statement.executeUpdate();

        } catch (SQLIntegrityConstraintViolationException e) {
            throw new IllegalArgumentException("Phone number already exists.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to update supplier.", e);
        }
    }

    public void delete(int supplierId) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SQL)) {

            statement.setInt(1, supplierId);
            statement.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to delete supplier.", e);
        }
    }

    public boolean existsByPhoneExcludingId(String phone, int supplierId) {
        if (phone == null || phone.isBlank()) {
            return false;
        }

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(EXISTS_BY_PHONE_SQL)) {

            statement.setString(1, phone);
            statement.setInt(2, supplierId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to check supplier phone uniqueness.", e);
        }

        return false;
    }

    private Supplier mapRow(ResultSet rs) throws SQLException {
        Supplier supplier = new Supplier();
        supplier.setSupplierId(rs.getInt("supplier_id"));
        supplier.setSupplierName(rs.getString("supplier_name"));
        supplier.setPhone(rs.getString("phone"));
        supplier.setAddress(rs.getString("address"));

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            supplier.setCreatedAt(createdAt.toLocalDateTime());
        }

        return supplier;
    }

    private String emptyToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }
}