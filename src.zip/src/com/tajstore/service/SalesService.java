package com.tajstore.service;

import com.tajstore.dao.GoldPriceHistoryDao;
import com.tajstore.dao.SalesDao;
import com.tajstore.dao.SalesSupportDao;
import com.tajstore.model.Customer;
import com.tajstore.model.Employee;
import com.tajstore.model.GoldPriceHistory;
import com.tajstore.model.PaymentMethod;
import com.tajstore.model.SalesItemOption;

import java.math.BigDecimal;
import java.util.List;

public class SalesService {

    private final SalesSupportDao salesSupportDao;
    private final SalesDao salesDao;
    private final GoldPriceHistoryDao goldPriceHistoryDao;

    public SalesService() {
        this.salesSupportDao = new SalesSupportDao();
        this.salesDao = new SalesDao();
        this.goldPriceHistoryDao = new GoldPriceHistoryDao();
    }

    public List<Customer> getCustomers() {
        return salesSupportDao.findAllCustomers();
    }

    public List<Employee> getEmployees() {
        return salesSupportDao.findAllEmployees();
    }

    public List<PaymentMethod> getPaymentMethods() {
        return salesSupportDao.findAllPaymentMethods();
    }

    public List<SalesItemOption> getAvailableItems() {
        return salesSupportDao.findAvailableItems();
    }

    public GoldPriceHistory getLatestGoldPrice() {
        return goldPriceHistoryDao.getLatestPrice();
    }

    public int createSale(
            Customer customer,
            Employee employee,
            SalesItemOption item,
            PaymentMethod paymentMethod,
            String quantityText,
            String salePriceText,
            String goldPriceText,
            String paymentAmountText,
            String paymentNote
    ) {
        if (customer == null) {
            throw new IllegalArgumentException("Please select a customer.");
        }

        if (employee == null) {
            throw new IllegalArgumentException("Please select an employee.");
        }

        if (item == null) {
            throw new IllegalArgumentException("Please select an item.");
        }

        if (paymentMethod == null) {
            throw new IllegalArgumentException("Please select a payment method.");
        }

        int quantity = parsePositiveQuantity(quantityText);
        BigDecimal salePrice = parsePositiveMoney(salePriceText, "Sale price");
        BigDecimal goldPriceAtSale = parsePositiveMoney(goldPriceText, "Gold price at sale");
        BigDecimal paymentAmount = parseNonNegativeMoney(paymentAmountText, "Payment amount");

        if (quantity > item.getQty()) {
            throw new IllegalArgumentException("Requested quantity is greater than the available stock for this item.");
        }

        if (paymentAmount.compareTo(salePrice) > 0) {
            throw new IllegalArgumentException("Payment amount cannot be greater than total sale price.");
        }

        return salesDao.createSale(
                customer.getCustomerId(),
                employee.getEmployeeId(),
                item.getItemId(),
                quantity,
                salePrice,
                goldPriceAtSale,
                item.getMakingCost(),
                paymentMethod.getMethodId(),
                paymentAmount,
                paymentNote == null || paymentNote.trim().isEmpty() ? null : paymentNote.trim()
        );
    }

    private BigDecimal parsePositiveMoney(String value, String fieldName) {
        try {
            BigDecimal result = new BigDecimal(value.trim());
            if (result.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException(fieldName + " must be greater than zero.");
            }
            return result;
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException(fieldName + " must be a valid number.");
        }
    }

    private BigDecimal parseNonNegativeMoney(String value, String fieldName) {
        try {
            BigDecimal result = new BigDecimal(value.trim());
            if (result.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException(fieldName + " cannot be negative.");
            }
            return result;
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException(fieldName + " must be a valid number.");
        }
    }

    private int parsePositiveQuantity(String value) {
        try {
            int quantity = Integer.parseInt(value.trim());
            if (quantity <= 0) {
                throw new IllegalArgumentException("Quantity must be greater than zero.");
            }
            return quantity;
        } catch (NumberFormatException | NullPointerException e) {
            throw new IllegalArgumentException("Quantity must be a valid whole number.");
        }
    }
}
