package com.tajstore.service;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.InvoiceHistoryRow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class InvoiceHistoryService {

    private static final String FIND_ALL_SQL =
            "SELECT i.invoice_id, c.full_name AS customer_name, e.full_name AS employee_name, " +
            "i.invoice_date, i.total_amount, i.status " +
            "FROM invoice i " +
            "JOIN customer c ON i.customer_id = c.customer_id " +
            "JOIN employee e ON i.employee_id = e.employee_id " +
            "ORDER BY i.invoice_date DESC, i.invoice_id DESC";

    private static final String SEARCH_SQL =
            "SELECT i.invoice_id, c.full_name AS customer_name, e.full_name AS employee_name, " +
            "i.invoice_date, i.total_amount, i.status " +
            "FROM invoice i " +
            "JOIN customer c ON i.customer_id = c.customer_id " +
            "JOIN employee e ON i.employee_id = e.employee_id " +
            "WHERE CAST(i.invoice_id AS CHAR) LIKE ? " +
            "   OR c.full_name LIKE ? " +
            "   OR e.full_name LIKE ? " +
            "   OR i.status LIKE ? " +
            "ORDER BY i.invoice_date DESC, i.invoice_id DESC";

    public List<InvoiceHistoryRow> getAllInvoices() {
        List<InvoiceHistoryRow> invoices = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                invoices.add(mapRow(rs));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load invoice history.", e);
        }

        return invoices;
    }

    public List<InvoiceHistoryRow> searchInvoices(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllInvoices();
        }

        List<InvoiceHistoryRow> invoices = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_SQL)) {

            String value = "%" + keyword.trim() + "%";
            statement.setString(1, value);
            statement.setString(2, value);
            statement.setString(3, value);
            statement.setString(4, value);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    invoices.add(mapRow(rs));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to search invoice history.", e);
        }

        return invoices;
    }

    private InvoiceHistoryRow mapRow(ResultSet rs) throws Exception {
        InvoiceHistoryRow row = new InvoiceHistoryRow();
        row.setInvoiceId(rs.getInt("invoice_id"));
        row.setCustomerName(rs.getString("customer_name"));
        row.setEmployeeName(rs.getString("employee_name"));

        Timestamp ts = rs.getTimestamp("invoice_date");
        if (ts != null) {
            row.setInvoiceDate(ts.toLocalDateTime());
        }

        row.setTotalAmount(rs.getBigDecimal("total_amount"));
        row.setStatus(rs.getString("status"));
        return row;
    }
}