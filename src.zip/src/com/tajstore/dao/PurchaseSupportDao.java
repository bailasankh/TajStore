package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.Employee;
import com.tajstore.model.PurchaseItemOption;
import com.tajstore.model.Supplier;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PurchaseSupportDao {

    private static final String FIND_SUPPLIERS_SQL =
            "SELECT supplier_id, supplier_name, phone, address, created_at FROM supplier ORDER BY supplier_name";

    private static final String FIND_EMPLOYEES_SQL =
            "SELECT employee_id, full_name FROM employee WHERE is_active = 1 ORDER BY full_name";

    private static final String FIND_ITEMS_SQL =
            "SELECT g.item_id, g.item_name, g.serial_no, c.category_name, g.weight_gram, g.karat, g.making_cost " +
            "FROM gold_item g " +
            "JOIN category c ON g.category_id = c.category_id " +
            "WHERE g.is_active = 1 " +
            "ORDER BY g.item_name";

    public List<Supplier> findAllSuppliers() {
        List<Supplier> suppliers = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_SUPPLIERS_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                Supplier supplier = new Supplier();
                supplier.setSupplierId(rs.getInt("supplier_id"));
                supplier.setSupplierName(rs.getString("supplier_name"));
                supplier.setPhone(rs.getString("phone"));
                supplier.setAddress(rs.getString("address"));
                suppliers.add(supplier);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load suppliers for purchases.", e);
        }

        return suppliers;
    }

    public List<Employee> findAllEmployees() {
        List<Employee> employees = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_EMPLOYEES_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt("employee_id"),
                        rs.getString("full_name")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load employees for purchases.", e);
        }

        return employees;
    }

    public List<PurchaseItemOption> findAllItems() {
        List<PurchaseItemOption> items = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ITEMS_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                PurchaseItemOption item = new PurchaseItemOption();
                item.setItemId(rs.getInt("item_id"));
                item.setItemName(rs.getString("item_name"));
                item.setSerialNo(rs.getString("serial_no"));
                item.setCategoryName(rs.getString("category_name"));
                item.setWeightGram(rs.getBigDecimal("weight_gram"));
                item.setKarat(rs.getInt("karat"));
                item.setMakingCost(rs.getBigDecimal("making_cost"));
                items.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load items for purchases.", e);
        }

        return items;
    }
}