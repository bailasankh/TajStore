package com.tajstore.ui.dashboard;

import com.tajstore.config.Routes;
import com.tajstore.dao.GoldPriceHistoryDao;
import com.tajstore.model.GoldPriceHistory;
import com.tajstore.security.AuthorizationService;
import com.tajstore.security.Permission;
import com.tajstore.service.DashboardService;
import com.tajstore.session.SessionManager;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.ui.components.StatsCard;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class DashboardPanel extends BasePanel {

    private final DashboardService dashboardService = new DashboardService();
    private final GoldPriceHistoryDao goldPriceDao = new GoldPriceHistoryDao();
    private final DecimalFormat moneyFormat = new DecimalFormat("0.00");
    private final Consumer<String> navigator;

    public DashboardPanel(Consumer<String> navigator) {
        this.navigator = navigator;
        initUI();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint background = new GradientPaint(
                0, 0, ThemeManager.isDarkMode() ? new Color(10, 6, 4) : new Color(248, 244, 236),
                0, getHeight(), ThemeManager.isDarkMode() ? new Color(24, 14, 10) : new Color(238, 232, 220)
        );
        g2.setPaint(background);
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.dispose();
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout());

        JPanel container = new JPanel();
        container.setOpaque(false);
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        container.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        if (!goldPriceDao.isTodayUpdated()) {
            container.add(buildGoldWarningBanner());
            container.add(Box.createVerticalStrut(16));
        }

        container.add(buildWelcomeBanner());
        container.add(Box.createVerticalStrut(16));
        container.add(buildStatsSection());

        add(createLuxuryScrollPane(container), BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel buildWelcomeBanner() {
        JPanel card = createLuxuryCard();
        card.setLayout(new BorderLayout(18, 0));
        card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));

        String fullName = SessionManager.getCurrentFullName() != null ? SessionManager.getCurrentFullName() : "User";
        String role = SessionManager.getCurrentRole() != null ? SessionManager.getCurrentRole() : "Unknown";

        JPanel contentPanel = new JPanel();
        contentPanel.setOpaque(false);
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Welcome back, " + fullName);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 30));
        titleLabel.setForeground(ThemeManager.getTheme().getPrimary());

        JLabel roleLabel = new JLabel("Role: " + role);
        roleLabel.setFont(UIStyle.FONT_BODY);
        roleLabel.setForeground(getTextSoftColor());

        JLabel description = new JLabel("<html><body style='width:520px'>Daily sales, profit, invoices, stock alerts, and latest saved gold prices.</body></html>");
        description.setFont(UIStyle.FONT_BODY);
        description.setForeground(getTextSoftColor());

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actions.setOpaque(false);

        PrimaryButton createSaleButton = new PrimaryButton("Create Sale");
        createSaleButton.setPreferredSize(new Dimension(130, 42));
        createSaleButton.setVisible(AuthorizationService.hasPermission(Permission.MANAGE_SALES));
        createSaleButton.addActionListener(e -> navigator.accept(Routes.SALES));

        PrimaryButton goldPriceButton = new PrimaryButton("Gold Prices");
        goldPriceButton.setPreferredSize(new Dimension(130, 42));
        goldPriceButton.addActionListener(e -> navigator.accept(Routes.GOLD_PRICES));

        SecondaryButton refreshButton = new SecondaryButton("Refresh");
        refreshButton.setPreferredSize(new Dimension(120, 42));
        refreshButton.addActionListener(e -> initUI());

        if (createSaleButton.isVisible()) {
            actions.add(createSaleButton);
        }
        actions.add(goldPriceButton);
        actions.add(refreshButton);

        contentPanel.add(titleLabel);
        contentPanel.add(Box.createVerticalStrut(8));
        contentPanel.add(roleLabel);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(description);
        contentPanel.add(Box.createVerticalStrut(16));
        contentPanel.add(actions);

        card.add(buildLogoPanel(), BorderLayout.WEST);
        card.add(contentPanel, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildLogoPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(150, 150));

        JLabel logoLabel = new JLabel("TAJ", JLabel.CENTER);
        logoLabel.setFont(new Font("Serif", Font.BOLD, 34));
        logoLabel.setForeground(ThemeManager.getTheme().getPrimary());

        try {
            java.net.URL imageUrl = getClass().getResource("/com/tajstore/assets/logo.png");
            if (imageUrl != null) {
                ImageIcon icon = new ImageIcon(imageUrl);
                Image scaled = icon.getImage().getScaledInstance(130, 130, Image.SCALE_SMOOTH);
                logoLabel.setText("");
                logoLabel.setIcon(new ImageIcon(scaled));
            }
        } catch (Exception ignored) {
        }

        panel.add(logoLabel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildGoldWarningBanner() {
        JPanel card = createLuxuryCard();
        card.setLayout(new BorderLayout(12, 12));
        card.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));

        JLabel info = new JLabel("<html><b>Attention:</b> Today's gold price is not saved yet.</html>");
        info.setFont(UIStyle.FONT_BODY);
        info.setForeground(getTextMainColor());

        PrimaryButton actionButton = new PrimaryButton("Open Gold Prices");
        actionButton.setPreferredSize(new Dimension(180, 40));
        actionButton.addActionListener(e -> navigator.accept(Routes.GOLD_PRICES));

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        actionPanel.setOpaque(false);
        actionPanel.add(actionButton);

        card.add(info, BorderLayout.CENTER);
        card.add(actionPanel, BorderLayout.EAST);
        return card;
    }

    private JPanel buildStatsSection() {
        List<JPanel> cards = new ArrayList<>();

        GoldPriceHistory latestGold = goldPriceDao.getLatestPrice();
        double salesToday = safeDouble(() -> dashboardService.getTodaySalesTotal());
        double profitToday = safeDouble(() -> dashboardService.getTodayEstimatedProfit());
        int invoicesToday = safeInt(() -> dashboardService.getTodayInvoiceCount());
        int lowStock = safeInt(() -> dashboardService.getLowStockCount());

        if (latestGold != null) {
            cards.add(routeCard("24K Price", moneyFormat.format(latestGold.getPrice24k()) + " NIS", "Saved on " + latestGold.getPriceDate(), Routes.GOLD_PRICES));
            cards.add(routeCard("21K Price", moneyFormat.format(latestGold.getPrice21k()) + " NIS", "Saved on " + latestGold.getPriceDate(), Routes.GOLD_PRICES));
            cards.add(routeCard("18K Price", moneyFormat.format(latestGold.getPrice18k()) + " NIS", "Saved on " + latestGold.getPriceDate(), Routes.GOLD_PRICES));
        }

        if (AuthorizationService.hasPermission(Permission.MANAGE_SALES)) {
            cards.add(routeCard("Today's Sales", moneyFormat.format(salesToday) + " NIS", "Total sold today", Routes.SALES));
            cards.add(routeCard("Today's Profit", moneyFormat.format(profitToday) + " NIS", "Sales minus purchase cost", Routes.REPORTS));
            cards.add(routeCard("Today's Invoices", String.valueOf(invoicesToday), "Number of invoices", Routes.INVOICE_HISTORY));
        }

        if (AuthorizationService.hasPermission(Permission.VIEW_INVENTORY)) {
            cards.add(routeCard("Low Quantity Items", String.valueOf(lowStock), "Quantity 1 or less", Routes.INVENTORY));
        }

        if (cards.isEmpty()) {
            JPanel empty = createLuxuryCard();
            empty.setLayout(new BorderLayout());
            empty.add(centerLabel("No important dashboard data is available for this role."), BorderLayout.CENTER);
            cards.add(empty);
        }

        int cols = Math.min(cards.size(), 4);
        if (cols == 0) {
            cols = 1;
        }

        int rows = (int) Math.ceil(cards.size() / (double) cols);
        JPanel grid = new JPanel(new GridLayout(rows, cols, 16, 16));
        grid.setOpaque(false);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, rows * 138));

        for (JPanel card : cards) {
            grid.add(card);
        }

        return grid;
    }

    private StatsCard routeCard(String title, String value, String subtitle, String route) {
        StatsCard card = new StatsCard(title, value);
        card.setSubtitle(subtitle);
        card.addMouseListener(createRouteClickListener(route));
        return card;
    }

    private JPanel createLuxuryCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(ThemeManager.isDarkMode() ? new Color(0, 0, 0, 120) : new Color(255, 255, 255, 212));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                g2.setColor(ThemeManager.isDarkMode() ? new Color(212, 175, 55, 95) : new Color(201, 162, 39, 140));
                g2.setStroke(new BasicStroke(1.1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 24, 24);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        return card;
    }

    private JLabel centerLabel(String text) {
        JLabel label = new JLabel(text, JLabel.CENTER);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(getTextSoftColor());
        return label;
    }

    private MouseAdapter createRouteClickListener(String route) {
        return new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                navigator.accept(route);
            }
        };
    }

    private int safeInt(IntSupplier supplier) {
        try {
            return supplier.get();
        } catch (Exception e) {
            return 0;
        }
    }

    private double safeDouble(DoubleSupplier supplier) {
        try {
            return supplier.get();
        } catch (Exception e) {
            return 0.0;
        }
    }

    @FunctionalInterface
    private interface IntSupplier {
        int get();
    }

    @FunctionalInterface
    private interface DoubleSupplier {
        double get();
    }

    private JScrollPane createLuxuryScrollPane(JPanel content) {
        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getHorizontalScrollBar().setUnitIncrement(16);
        return scrollPane;
    }

    private Color getTextMainColor() {
        return ThemeManager.isDarkMode() ? new Color(255, 248, 235) : new Color(43, 33, 23);
    }

    private Color getTextSoftColor() {
        return ThemeManager.isDarkMode() ? new Color(230, 215, 190) : new Color(95, 78, 54);
    }
}
