package com.tajstore.ui.components;

import com.tajstore.theme.UIStyle;

import javax.swing.JButton;

public class DangerButton extends JButton {

    public DangerButton(String text) {
        super(text);
        UIStyle.styleDangerButton(this);
    }
}