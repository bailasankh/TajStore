package com.tajstore.util;

public final class Validator {

    private Validator() {
    }

    public static void requireNotBlank(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }
    }

    public static void validateUsername(String username) {
        requireNotBlank(username, "Username");

        String trimmed = username.trim();

        if (trimmed.length() < 4) {
            throw new IllegalArgumentException("Username must be at least 4 characters.");
        }

        if (!trimmed.matches("[A-Za-z0-9._]+")) {
            throw new IllegalArgumentException("Username can contain letters, numbers, dot, and underscore only.");
        }
    }

    public static void validateFullName(String fullName) {
        requireNotBlank(fullName, "Full name");

        if (fullName.trim().length() < 3) {
            throw new IllegalArgumentException("Full name must be at least 3 characters.");
        }
    }

    public static void validatePassword(String password) {
        requireNotBlank(password, "Password");

        if (password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters.");
        }
    }

    public static void validatePasswordConfirmation(String password, String confirmPassword) {
        if (password == null || confirmPassword == null || !password.equals(confirmPassword)) {
            throw new IllegalArgumentException("Password and confirm password do not match.");
        }
    }
}