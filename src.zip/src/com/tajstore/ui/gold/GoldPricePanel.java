package com.tajstore.ui.gold;

import com.tajstore.dao.GoldPriceHistoryDao;
import com.tajstore.model.GoldPriceHistory;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.ModernTable;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.util.NotificationUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class GoldPricePanel extends BasePanel {

    private final GoldPriceHistoryDao goldPriceDao = new GoldPriceHistoryDao();
    private final DecimalFormat format = new DecimalFormat("0.00");
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private JTextField price24Field;
    private JTextField price21Field;
    private JTextField price18Field;
    private JLabel statusLabel;
    private JLabel latestInfoLabel;
    private JLabel reportStatusLabel;
    private ModernTable reportTable;
    private DefaultTableModel reportTableModel;

    public GoldPricePanel() {
        initUI();
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(0, 12));
        setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        SectionTitle title = new SectionTitle(
                "Gold Prices",
                "Update today's prices and keep the team aware of the latest saved market values"
        );
        add(title, BorderLayout.NORTH);

        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));

        body.add(buildTodayPriceForm());
        body.add(Box.createVerticalStrut(12));
        body.add(buildReportSection());

        add(body, BorderLayout.CENTER);
        loadData();
    }

    private JPanel buildTodayPriceForm() {
        JPanel card = new JPanel(new BorderLayout(14, 12));
        card.setOpaque(true);
        card.setBackground(ThemeManager.getTheme().getSurface());
        card.setBorder(UIStyle.createCardBorder());
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 175));

        JPanel infoPanel = new JPanel();
        infoPanel.setOpaque(false);
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));

        latestInfoLabel = new JLabel(" ");
        latestInfoLabel.setFont(UIStyle.FONT_BODY);
        latestInfoLabel.setForeground(ThemeManager.getTheme().getText());

        statusLabel = new JLabel(" ");
        statusLabel.setFont(UIStyle.FONT_SMALL);
        statusLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        infoPanel.add(latestInfoLabel);
        infoPanel.add(Box.createVerticalStrut(6));
        infoPanel.add(statusLabel);

        JPanel fields = new JPanel(new GridBagLayout());
        fields.setOpaque(false);

        price24Field = new JTextField();
        price21Field = new JTextField();
        price18Field = new JTextField();
        UIStyle.styleField(price24Field);
        UIStyle.styleField(price21Field);
        UIStyle.styleField(price18Field);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 8, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addPriceField(fields, gbc, 0, "24K Price", price24Field);
        addPriceField(fields, gbc, 1, "21K Price", price21Field);
        addPriceField(fields, gbc, 2, "18K Price", price18Field);

        PrimaryButton saveButton = new PrimaryButton("Save Today's Price");
        saveButton.addActionListener(e -> saveTodayPrice());

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        footer.setOpaque(false);
        footer.add(saveButton);

        JPanel content = new JPanel(new BorderLayout(18, 0));
        content.setOpaque(false);
        content.add(fields, BorderLayout.CENTER);
        content.add(footer, BorderLayout.EAST);

        card.add(infoPanel, BorderLayout.NORTH);
        card.add(content, BorderLayout.CENTER);
        return card;
    }

    private void addPriceField(JPanel parent, GridBagConstraints gbc, int column, String labelText, JTextField field) {
        JPanel wrapper = new JPanel(new BorderLayout(0, 6));
        wrapper.setOpaque(false);

        JLabel title = label(labelText);
        wrapper.add(title, BorderLayout.NORTH);
        wrapper.add(field, BorderLayout.CENTER);

        gbc.gridx = column;
        gbc.weightx = 1.0;
        parent.add(wrapper, gbc);
    }

    private JPanel buildReportSection() {
        JPanel card = new JPanel(new BorderLayout(0, 10));
        card.setOpaque(true);
        card.setBackground(ThemeManager.getTheme().getSurface());
        card.setBorder(UIStyle.createCardBorder());
        card.setPreferredSize(new Dimension(100, 420));
        card.setMinimumSize(new Dimension(100, 330));

        JLabel title = new JLabel("Gold Price History Report");
        title.setFont(UIStyle.FONT_HEADING);
        title.setForeground(ThemeManager.getTheme().getText());

        reportTableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"Date", "24K", "21K", "18K"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        reportTable = new ModernTable();
        reportTable.setModel(reportTableModel);
        reportTable.setFocusable(false);
        reportTable.setRowSelectionAllowed(false);
        reportTable.setFillsViewportHeight(true);
        reportTable.setRowHeight(38);
        reportTable.setPreferredScrollableViewportSize(new Dimension(100, 330));
        reportTable.getColumnModel().getColumn(0).setPreferredWidth(180);
        reportTable.getColumnModel().getColumn(1).setPreferredWidth(180);
        reportTable.getColumnModel().getColumn(2).setPreferredWidth(180);
        reportTable.getColumnModel().getColumn(3).setPreferredWidth(180);

        reportStatusLabel = new JLabel(" ");
        reportStatusLabel.setFont(UIStyle.FONT_SMALL);
        reportStatusLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        JScrollPane scrollPane = new JScrollPane(reportTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1));
        scrollPane.getViewport().setBackground(ThemeManager.getTheme().getSurface());
        scrollPane.setPreferredSize(new Dimension(100, 350));
        scrollPane.setMinimumSize(new Dimension(100, 300));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        card.add(title, BorderLayout.NORTH);
        card.add(scrollPane, BorderLayout.CENTER);
        card.add(reportStatusLabel, BorderLayout.SOUTH);
        return card;
    }

    private JLabel label(String text) {
        JLabel label = new JLabel(text);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());
        return label;
    }

    private void loadData() {
        LocalDate todayDate = LocalDate.now();
        GoldPriceHistory today = goldPriceDao.getByDate(todayDate);
        GoldPriceHistory latest = goldPriceDao.getLatestBeforeOrOn(todayDate);

        if (today != null) {
            populateFields(today);
            latestInfoLabel.setText("Today's saved prices are shown below.");
            statusLabel.setText("Last update date: " + dateFormatter.format(today.getPriceDate()));
        } else if (latest != null) {
            populateFields(latest);
            latestInfoLabel.setText("No price for today yet. Showing latest saved prices from " +
                    dateFormatter.format(latest.getPriceDate()) + ".");
            statusLabel.setText("Save these values as today's prices after review.");
        } else {
            clearFields();
            latestInfoLabel.setText("No saved gold prices were found yet.");
            statusLabel.setText("Add the first daily price entry to start the history.");
        }

        List<GoldPriceHistory> history = goldPriceDao.getAllPrices();
        reportTableModel.setRowCount(0);
        for (GoldPriceHistory row : history) {
            reportTableModel.addRow(new Object[]{
                    dateFormatter.format(row.getPriceDate()),
                    format.format(row.getPrice24k()),
                    format.format(row.getPrice21k()),
                    format.format(row.getPrice18k())
            });
        }
        reportStatusLabel.setText(history.isEmpty()
                ? "No saved gold price history records were found."
                : "Showing " + history.size() + " saved gold price record(s).");
    }

    private void populateFields(GoldPriceHistory history) {
        price24Field.setText(format.format(history.getPrice24k()));
        price21Field.setText(format.format(history.getPrice21k()));
        price18Field.setText(format.format(history.getPrice18k()));
    }

    private void clearFields() {
        price24Field.setText("");
        price21Field.setText("");
        price18Field.setText("");
    }

    private void saveTodayPrice() {
        try {
            GoldPriceHistory g = new GoldPriceHistory();
            g.setPriceDate(LocalDate.now());
            g.setPrice24k(Double.parseDouble(price24Field.getText().trim()));
            g.setPrice21k(Double.parseDouble(price21Field.getText().trim()));
            g.setPrice18k(Double.parseDouble(price18Field.getText().trim()));
            goldPriceDao.upsertByDate(g);
            NotificationUtil.showSuccess(this, "Today's gold price saved successfully.");
            loadData();
        } catch (Exception ex) {
            NotificationUtil.showError(this, "Please enter valid numeric values.");
        }
    }
}
