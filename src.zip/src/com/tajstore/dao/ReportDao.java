package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.InventoryReportRow;
import com.tajstore.model.SalesReportRow;
import com.tajstore.model.TopCategoryReportRow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ReportDao {

    private static final String SALES_REPORT_SQL =
            "SELECT i.invoice_id, i.invoice_date, c.full_name AS customer_name, e.full_name AS employee_name, " +
            "i.total_amount, i.status " +
            "FROM invoice i " +
            "JOIN customer c ON i.customer_id = c.customer_id " +
            "JOIN employee e ON i.employee_id = e.employee_id " +
            "WHERE DATE(i.invoice_date) BETWEEN ? AND ? " +
            "ORDER BY i.invoice_date DESC";

    private static final String INVENTORY_REPORT_SQL =
            "SELECT inv.inventory_id, g.item_name, g.serial_no, c.category_name, inv.qty " +
            "FROM inventory inv " +
            "JOIN gold_item g ON inv.item_id = g.item_id " +
            "JOIN category c ON g.category_id = c.category_id " +
            "ORDER BY inv.inventory_id DESC";

    private static final String TOP_CATEGORY_REPORT_SQL =
            "SELECT c.category_name, COALESCE(SUM(id.quantity), 0) AS sold_count, COALESCE(SUM(id.sale_price), 0) AS total_sales " +
            "FROM invoice_details id " +
            "JOIN gold_item g ON id.item_id = g.item_id " +
            "JOIN category c ON g.category_id = c.category_id " +
            "GROUP BY c.category_id, c.category_name " +
            "ORDER BY sold_count DESC, total_sales DESC";

    public List<SalesReportRow> getSalesReport(String fromDate, String toDate) {
        List<SalesReportRow> rows = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(SALES_REPORT_SQL)) {

            statement.setString(1, fromDate);
            statement.setString(2, toDate);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    SalesReportRow row = new SalesReportRow();
                    row.setInvoiceId(rs.getInt("invoice_id"));

                    Timestamp ts = rs.getTimestamp("invoice_date");
                    if (ts != null) {
                        row.setInvoiceDate(ts.toLocalDateTime());
                    }

                    row.setCustomerName(rs.getString("customer_name"));
                    row.setEmployeeName(rs.getString("employee_name"));
                    row.setTotalAmount(rs.getBigDecimal("total_amount"));
                    row.setStatus(rs.getString("status"));
                    rows.add(row);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load sales report.", e);
        }

        return rows;
    }

    public List<InventoryReportRow> getInventoryReport() {
        List<InventoryReportRow> rows = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(INVENTORY_REPORT_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                InventoryReportRow row = new InventoryReportRow();
                row.setInventoryId(rs.getInt("inventory_id"));
                row.setItemName(rs.getString("item_name"));
                row.setSerialNo(rs.getString("serial_no"));
                row.setCategoryName(rs.getString("category_name"));
                row.setQty(rs.getInt("qty"));
                rows.add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load inventory report.", e);
        }

        return rows;
    }

    public List<TopCategoryReportRow> getTopCategoryReport() {
        List<TopCategoryReportRow> rows = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(TOP_CATEGORY_REPORT_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                TopCategoryReportRow row = new TopCategoryReportRow();
                row.setCategoryName(rs.getString("category_name"));
                row.setSoldCount(rs.getInt("sold_count"));
                row.setTotalSales(rs.getBigDecimal("total_sales"));
                rows.add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load top category report.", e);
        }

        return rows;
    }
}
