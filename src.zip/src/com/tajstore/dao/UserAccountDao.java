package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.UserAccount;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class UserAccountDao {

    // 1. جملة السيلكت (صح)
    private static final String FIND_BY_USERNAME_SQL =
            "SELECT u.user_id, u.username, u.password_hash, u.salt, u.full_name, u.is_active, u.role_id, r.role_name " +
            "FROM user_account u " +
            "JOIN role r ON u.role_id = r.role_id " +
            "WHERE u.username = ?";

    private static final String EXISTS_BY_USERNAME_SQL =
            "SELECT COUNT(*) FROM user_account WHERE username = ?";

    // 2. جملة الإدخال (تم ترتيب الأعمدة بالضبط زي ما هي في الداتا بيس عشان ما يحصل لخبطة)
    private static final String INSERT_SQL =
            "INSERT INTO user_account (username, password_hash, salt, full_name, is_active, role_id) VALUES (?, ?, ?, ?, ?, ?)";

    // 3. جملة تحديث كلمة السر لما المستخدم ينسيها (هاد جديد عشان الفورجيت باسوورد)
    private static final String UPDATE_PASSWORD_SQL =
            "UPDATE user_account SET password_hash = ?, salt = ? WHERE username = ?";

    public UserAccount findByUsername(String username) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_BY_USERNAME_SQL)) {

            statement.setString(1, username);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to find user by username.", e);
        }

        return null;
    }

    public boolean existsByUsername(String username) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(EXISTS_BY_USERNAME_SQL)) {

            statement.setString(1, username);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to check username existence.", e);
        }

        return false;
    }

    public int insert(UserAccount userAccount) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            // 4. الترتيب المهم جداً (لازم يطابق جملة الـ SQL فوق بالضبط)
            statement.setString(1, userAccount.getUsername());
            statement.setString(2, userAccount.getPasswordHash());
            statement.setString(3, userAccount.getSalt());
            statement.setString(4, userAccount.getFullName());
            statement.setBoolean(5, userAccount.isActive());
            statement.setInt(6, userAccount.getRoleId());

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                throw new RuntimeException("Creating user failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }

            throw new RuntimeException("Creating user failed, no ID obtained.");

        } catch (Exception e) {
            // هيطبعلك السبب الحقيقي بالأسفل
            throw new RuntimeException("Failed to insert user account: " + e.getMessage(), e);
        }
    }

    // === 5. الدالة الجديدة عشان الفورجيت باسوورد (ربطناها فعلياً بالداتا بيس) ===
    public boolean resetPassword(String username, String newHashedPassword, String newSalt) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_PASSWORD_SQL)) {

            statement.setString(1, newHashedPassword);
            statement.setString(2, newSalt);
            statement.setString(3, username);

            int affectedRows = statement.executeUpdate();
            return affectedRows > 0;

        } catch (Exception e) {
            throw new RuntimeException("Failed to reset password.", e);
        }
    }

    private UserAccount mapRow(ResultSet rs) throws Exception {
        UserAccount user = new UserAccount();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setPasswordHash(rs.getString("password_hash"));
        user.setSalt(rs.getString("salt")); 
        user.setFullName(rs.getString("full_name"));
        user.setActive(rs.getBoolean("is_active"));
        user.setRoleId(rs.getInt("role_id"));
        user.setRoleName(rs.getString("role_name"));
        return user;
    }
}