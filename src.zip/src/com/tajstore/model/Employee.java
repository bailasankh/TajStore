package com.tajstore.model;

public class Employee {

    private int employeeId;
    private String fullName;

    public Employee() {
    }

    public Employee(int employeeId, String fullName) {
        this.employeeId = employeeId;
        this.fullName = fullName;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @Override
    public String toString() {
        return fullName;
    }
}