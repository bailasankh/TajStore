package com.tajstore.model;

import java.time.LocalDateTime;

public class InventoryMovement {

    private int moveId;
    private int itemId;
    private String itemName;
    private String serialNo;
    private String moveType;
    private Integer refInvoiceId;
    private Integer refPoId;
    private LocalDateTime moveDate;
    private String note;

    public int getMoveId() {
        return moveId;
    }

    public void setMoveId(int moveId) {
        this.moveId = moveId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getMoveType() {
        return moveType;
    }

    public void setMoveType(String moveType) {
        this.moveType = moveType;
    }

    public Integer getRefInvoiceId() {
        return refInvoiceId;
    }

    public void setRefInvoiceId(Integer refInvoiceId) {
        this.refInvoiceId = refInvoiceId;
    }

    public Integer getRefPoId() {
        return refPoId;
    }

    public void setRefPoId(Integer refPoId) {
        this.refPoId = refPoId;
    }

    public LocalDateTime getMoveDate() {
        return moveDate;
    }

    public void setMoveDate(LocalDateTime moveDate) {
        this.moveDate = moveDate;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}