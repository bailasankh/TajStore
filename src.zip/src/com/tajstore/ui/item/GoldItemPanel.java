package com.tajstore.ui.item;

import com.tajstore.model.Category;
import com.tajstore.model.GoldItem;
import com.tajstore.service.GoldItemService;
import com.tajstore.theme.ThemeManager;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.ModernTable;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SearchPanel;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.io.File;
import java.util.List;

public class GoldItemPanel extends BasePanel {

    private final GoldItemService goldItemService = new GoldItemService();

    private ModernTable itemTable;
    private DefaultTableModel tableModel;
    private SearchPanel searchPanel;

    public GoldItemPanel() {
        initUI();
        loadItems();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int width = getWidth();
        int height = getHeight();
        g2d.setColor(ThemeManager.isDarkMode() ? new Color(5, 2, 2) : new Color(248, 244, 236));
        g2d.fillRect(0, 0, width, height);

        Point center = new Point(width / 2, 0);
        float radius = Math.max(width, height) * 0.9f;
        float[] dist = {0.0f, 0.4f, 1.0f};
        Color[] colors = {
            ThemeManager.isDarkMode() ? new Color(70, 40, 10, 180) : new Color(201, 162, 39, 65),
            ThemeManager.isDarkMode() ? new Color(35, 18, 5, 100) : new Color(201, 162, 39, 30),
            new Color(0, 0, 0, 0)
        };
        RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
        g2d.setPaint(spotlight);
        g2d.fillRect(0, 0, width, height);
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(16, 16));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setOpaque(false);

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTableSection(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel mainHeader = new JPanel();
        mainHeader.setLayout(new BorderLayout(0, 12));
        mainHeader.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle("Gold Items", "Manage gold item records and optional image paths");

        JPanel toolBarCard = new JPanel(new BorderLayout(12, 0));
        toolBarCard.setOpaque(true);
        toolBarCard.setBackground(glassColor());
        toolBarCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(10, 16, 10, 16)
        ));

        searchPanel = new SearchPanel();
        searchPanel.getSearchField().setPreferredSize(new Dimension(320, 40));
        searchPanel.getSearchButton().addActionListener(e -> searchItems());
        searchPanel.getRefreshButton().addActionListener(e -> loadItems());

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonsPanel.setOpaque(false);

        PrimaryButton addButton = new PrimaryButton("Add Item");
        SecondaryButton editButton = new SecondaryButton("Edit");
        SecondaryButton viewImageButton = new SecondaryButton("View Image");

        addButton.addActionListener(e -> openAddDialog());
        editButton.addActionListener(e -> openEditDialog());
        viewImageButton.addActionListener(e -> openImagePreview());

        buttonsPanel.add(addButton);
        buttonsPanel.add(editButton);
        buttonsPanel.add(viewImageButton);

        JPanel searchWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        searchWrapper.setOpaque(false);
        searchWrapper.add(searchPanel);

        toolBarCard.add(searchWrapper, BorderLayout.WEST);
        toolBarCard.add(buttonsPanel, BorderLayout.EAST);

        mainHeader.add(sectionTitle, BorderLayout.NORTH);
        mainHeader.add(toolBarCard, BorderLayout.CENTER);
        return mainHeader;
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(true);
        panel.setBackground(glassColor());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(14, 14, 14, 14)
        ));

        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Item Name", "Serial No", "Category", "Weight", "Karat", "Making Cost", "Image", "Active", "Created At"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        itemTable = new ModernTable();
        itemTable.setModel(tableModel);
        itemTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        itemTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && itemTable.getSelectedRow() != -1) {
                    openImagePreview();
                }
            }
        });
        itemTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        itemTable.getColumnModel().getColumn(1).setPreferredWidth(170);
        itemTable.getColumnModel().getColumn(2).setPreferredWidth(110);
        itemTable.getColumnModel().getColumn(3).setPreferredWidth(95);
        itemTable.getColumnModel().getColumn(4).setPreferredWidth(80);
        itemTable.getColumnModel().getColumn(5).setPreferredWidth(70);
        itemTable.getColumnModel().getColumn(6).setPreferredWidth(110);
        itemTable.getColumnModel().getColumn(7).setPreferredWidth(160);
        itemTable.getColumnModel().getColumn(8).setPreferredWidth(70);
        itemTable.getColumnModel().getColumn(9).setPreferredWidth(160);

        JScrollPane scrollPane = new JScrollPane(itemTable);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));

        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private void loadItems() {
        try {
            fillTable(goldItemService.getAllGoldItems());
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void searchItems() {
        try {
            fillTable(goldItemService.searchGoldItems(searchPanel.getSearchText()));
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void fillTable(List<GoldItem> items) {
        tableModel.setRowCount(0);

        for (GoldItem item : items) {
            tableModel.addRow(new Object[]{
                    item.getItemId(),
                    item.getItemName(),
                    item.getSerialNo(),
                    item.getCategoryName(),
                    item.getWeightGram(),
                    item.getKarat(),
                    item.getMakingCost(),
                    displayImagePath(item.getImagePath()),
                    item.isActive() ? "Yes" : "No",
                    item.getCreatedAt()
            });
        }
    }

    private void openAddDialog() {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        GoldItemFormDialog dialog = new GoldItemFormDialog(owner, "Add Gold Item", null);
        dialog.setVisible(true);

        if (!dialog.isSaved()) {
            return;
        }

        try {
            Category category = dialog.getSelectedCategory();
            if (category == null) {
                throw new IllegalArgumentException("Please select a category.");
            }

            goldItemService.addGoldItem(
                    dialog.getItemNameValue(),
                    dialog.getSerialNoValue(),
                    category.getCategoryId(),
                    dialog.getWeightValue(),
                    dialog.getKaratValue(),
                    dialog.getMakingCostValue(),
                    dialog.getImagePathValue(),
                    dialog.isActiveValue()
            );

            MessageUtil.showSuccess(this, "Gold item added successfully.");
            loadItems();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void openEditDialog() {
        int selectedRow = itemTable.getSelectedRow();
        if (selectedRow == -1) {
            MessageUtil.showError(this, "Please select an item to edit.");
            return;
        }

        GoldItem item = new GoldItem();
        item.setItemId((Integer) tableModel.getValueAt(selectedRow, 0));
        item.setItemName((String) tableModel.getValueAt(selectedRow, 1));
        item.setSerialNo((String) tableModel.getValueAt(selectedRow, 2));
        item.setCategoryName((String) tableModel.getValueAt(selectedRow, 3));
        item.setWeightGram(new BigDecimal(tableModel.getValueAt(selectedRow, 4).toString()));
        item.setKarat((Integer) tableModel.getValueAt(selectedRow, 5));
        item.setMakingCost(new BigDecimal(tableModel.getValueAt(selectedRow, 6).toString()));
        item.setImagePath(getSelectedImagePath(selectedRow));
        item.setActive("Yes".equals(tableModel.getValueAt(selectedRow, 8)));

        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        GoldItemFormDialog dialog = new GoldItemFormDialog(owner, "Edit Gold Item", item);
        dialog.setVisible(true);

        if (!dialog.isSaved()) {
            return;
        }

        try {
            Category category = dialog.getSelectedCategory();
            if (category == null) {
                throw new IllegalArgumentException("Please select a category.");
            }

            goldItemService.updateGoldItem(
                    item.getItemId(),
                    dialog.getItemNameValue(),
                    dialog.getSerialNoValue(),
                    category.getCategoryId(),
                    dialog.getWeightValue(),
                    dialog.getKaratValue(),
                    dialog.getMakingCostValue(),
                    dialog.getImagePathValue(),
                    dialog.isActiveValue()
            );

            MessageUtil.showSuccess(this, "Gold item updated successfully.");
            loadItems();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void openImagePreview() {
        int selectedRow = itemTable.getSelectedRow();
        if (selectedRow == -1) {
            MessageUtil.showError(this, "Please select a gold item first.");
            return;
        }

        String itemName = String.valueOf(tableModel.getValueAt(selectedRow, 1));
        String imagePath = getSelectedImagePath(selectedRow);

        if (imagePath.isEmpty()) {
            MessageUtil.showInfo(this, "No image path is saved for " + itemName + ".");
            return;
        }

        File imageFile = new File(imagePath);
        if (!imageFile.exists()) {
            MessageUtil.showError(this, "The saved image path was not found:\n" + imagePath);
            return;
        }

        ImageIcon icon = new ImageIcon(imagePath);
        if (icon.getIconWidth() <= 0 || icon.getIconHeight() <= 0) {
            MessageUtil.showError(this, "The selected file could not be opened as an image.");
            return;
        }

        int maxWidth = 520;
        int maxHeight = 420;
        Image scaled = icon.getImage().getScaledInstance(
                Math.min(icon.getIconWidth(), maxWidth),
                Math.min(icon.getIconHeight(), maxHeight),
                Image.SCALE_SMOOTH
        );

        JLabel imageLabel = new JLabel(new ImageIcon(scaled));
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JOptionPane optionPane = new JOptionPane(
                imageLabel,
                JOptionPane.PLAIN_MESSAGE,
                JOptionPane.DEFAULT_OPTION,
                null,
                new Object[]{"Close"}
        );

        JDialog dialog = optionPane.createDialog(
                SwingUtilities.getWindowAncestor(this),
                itemName + " Image"
        );
        dialog.setModal(true);
        dialog.setResizable(true);
        dialog.setVisible(true);
    }

    private Color glassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 120) : new Color(255, 255, 255, 215);
    }

    private Color borderColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 80) : ThemeManager.getTheme().getBorder();
    }

    private String displayImagePath(String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) {
            return "";
        }
        return new File(imagePath).getName();
    }

    private String getSelectedImagePath(int selectedRow) {
        Object idValue = tableModel.getValueAt(selectedRow, 0);
        int itemId = Integer.parseInt(idValue.toString());

        for (GoldItem item : goldItemService.getAllGoldItems()) {
            if (item.getItemId() == itemId) {
                return item.getImagePath() == null ? "" : item.getImagePath();
            }
        }

        return "";
    }
}
