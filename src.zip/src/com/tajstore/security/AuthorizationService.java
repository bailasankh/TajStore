package com.tajstore.security;

import com.tajstore.session.SessionManager;

public final class AuthorizationService {

    private AuthorizationService() {
    }

    public static boolean hasPermission(Permission permission) {
        String roleName = SessionManager.getCurrentRole();

        if (roleName == null || permission == null) {
            return false;
        }

        return RolePermissions.getPermissionsByRole(roleName).contains(permission);
    }

    public static boolean isAdmin() {
        String roleName = SessionManager.getCurrentRole();
        return roleName != null && roleName.equalsIgnoreCase("ADMIN");
    }

    public static boolean isManager() {
        String roleName = SessionManager.getCurrentRole();
        return roleName != null && roleName.equalsIgnoreCase("MANAGER");
    }

    public static boolean isCashier() {
        String roleName = SessionManager.getCurrentRole();
        return roleName != null && roleName.equalsIgnoreCase("CASHIER");
    }
}