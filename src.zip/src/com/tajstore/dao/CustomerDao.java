package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDao {

    private static final String FIND_ALL_SQL =
            "SELECT customer_id, full_name, phone, address, created_at " +
            "FROM customer ORDER BY customer_id DESC";

    private static final String SEARCH_SQL =
            "SELECT customer_id, full_name, phone, address, created_at " +
            "FROM customer " +
            "WHERE full_name LIKE ? OR phone LIKE ? " +
            "ORDER BY customer_id DESC";

    private static final String INSERT_SQL =
            "INSERT INTO customer (full_name, phone, address) VALUES (?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE customer SET full_name = ?, phone = ?, address = ? WHERE customer_id = ?";

    private static final String DELETE_SQL =
            "DELETE FROM customer WHERE customer_id = ?";

    private static final String EXISTS_BY_PHONE_SQL =
            "SELECT COUNT(*) FROM customer WHERE phone = ? AND customer_id <> ?";

    public List<Customer> findAll() {
        List<Customer> customers = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                customers.add(mapRow(rs));
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to load customers.", e);
        }

        return customers;
    }

    public List<Customer> search(String keyword) {
        List<Customer> customers = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_SQL)) {

            String value = "%" + keyword + "%";
            statement.setString(1, value);
            statement.setString(2, value);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    customers.add(mapRow(rs));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to search customers.", e);
        }

        return customers;
    }

    public int insert(Customer customer) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, customer.getFullName());
            statement.setString(2, emptyToNull(customer.getPhone()));
            statement.setString(3, emptyToNull(customer.getAddress()));

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new RuntimeException("Creating customer failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }

            throw new RuntimeException("Creating customer failed, no ID obtained.");

        } catch (SQLIntegrityConstraintViolationException e) {
            throw new IllegalArgumentException("Phone number already exists.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to insert customer.", e);
        }
    }

    public void update(Customer customer) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SQL)) {

            statement.setString(1, customer.getFullName());
            statement.setString(2, emptyToNull(customer.getPhone()));
            statement.setString(3, emptyToNull(customer.getAddress()));
            statement.setInt(4, customer.getCustomerId());

            statement.executeUpdate();

        } catch (SQLIntegrityConstraintViolationException e) {
            throw new IllegalArgumentException("Phone number already exists.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to update customer.", e);
        }
    }

    public void delete(int customerId) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SQL)) {

            statement.setInt(1, customerId);
            statement.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to delete customer.", e);
        }
    }

    public boolean existsByPhoneExcludingId(String phone, int customerId) {
        if (phone == null || phone.isBlank()) {
            return false;
        }

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(EXISTS_BY_PHONE_SQL)) {

            statement.setString(1, phone);
            statement.setInt(2, customerId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to check phone uniqueness.", e);
        }

        return false;
    }

    private Customer mapRow(ResultSet rs) throws SQLException {
        Customer customer = new Customer();
        customer.setCustomerId(rs.getInt("customer_id"));
        customer.setFullName(rs.getString("full_name"));
        customer.setPhone(rs.getString("phone"));
        customer.setAddress(rs.getString("address"));

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            customer.setCreatedAt(createdAt.toLocalDateTime());
        }

        return customer;
    }

    private String emptyToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }
}