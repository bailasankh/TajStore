package com.tajstore.db;

public class DatabaseTest {
    public static void main(String[] args) {
        boolean connected = ConnectionManager.testConnection();
        System.out.println(connected ? "Database connected successfully." : "Database connection failed.");
    }
}