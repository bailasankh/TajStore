package com.tajstore.service;

import com.tajstore.dao.RoleDao;
import com.tajstore.dao.UserAccountDao;
import com.tajstore.model.Role;
import com.tajstore.model.UserAccount;
import com.tajstore.security.PasswordHasher;
import com.tajstore.session.CurrentSession;
import com.tajstore.session.SessionManager;

import java.util.List;

public class AuthService {

    private final UserAccountDao userAccountDao;
    private final RoleDao roleDao;

    public AuthService() {
        this.userAccountDao = new UserAccountDao();
        this.roleDao = new RoleDao();
    }

    public UserAccount login(String username, String plainPassword) {
        UserAccount user = userAccountDao.findByUsername(username);

        if (user == null) {
            throw new IllegalArgumentException("Invalid username or password.");
        }

        if (!user.isActive()) {
            throw new IllegalArgumentException("This account is inactive.");
        }

        // === التعديل 1: تمرير الـ Salt للدالة الجديدة ===
        boolean passwordMatches = PasswordHasher.matches(plainPassword, user.getPasswordHash(), user.getSalt());
        
        if (!passwordMatches) {
            throw new IllegalArgumentException("Invalid username or password.");
        }

        CurrentSession session = new CurrentSession(
                user.getUserId(),
                user.getUsername(),
                user.getFullName(),
                user.getRoleName(),
                user.isActive()
        );
        SessionManager.startSession(session);

        return user;
    }

    public void logout() {
        SessionManager.clearSession();
    }

    public int register(String fullName, String username, String plainPassword, int roleId) {
        if (userAccountDao.existsByUsername(username)) {
            throw new IllegalArgumentException("Username already exists.");
        }

        Role role = roleDao.findById(roleId);
        if (role == null) {
            throw new IllegalArgumentException("Selected role is invalid.");
        }

        // === التعديل 2: توليد الملح، وتشفير الباسورد مع الملح ===
        String generatedSalt = PasswordHasher.generateSalt();
        String hashedPassword = PasswordHasher.hash(plainPassword, generatedSalt);

        UserAccount user = new UserAccount();
        user.setFullName(fullName);
        user.setUsername(username);
        user.setPasswordHash(hashedPassword);
        user.setSalt(generatedSalt); // حفظ الملح مع المستخدم
        user.setActive(true);
        user.setRoleId(roleId);

        return userAccountDao.insert(user);
    }

    public List<Role> getAllRoles() {
        return roleDao.findAll();
    }
}