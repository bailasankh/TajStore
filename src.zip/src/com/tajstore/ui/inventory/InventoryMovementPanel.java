package com.tajstore.ui.inventory;

import com.tajstore.model.InventoryMovement;
import com.tajstore.service.InventoryMovementService;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.ModernTable;
import com.tajstore.ui.components.SearchPanel;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.util.List;

public class InventoryMovementPanel extends BasePanel {

    private final InventoryMovementService inventoryMovementService = new InventoryMovementService();

    private ModernTable movementTable;
    private DefaultTableModel tableModel;
    private SearchPanel searchPanel;
    private JLabel summaryLabel;
    private JLabel helperLabel;

    public InventoryMovementPanel() {
        initUI();
        loadMovements();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int width = getWidth();
        int height = getHeight();
        g2d.setColor(ThemeManager.isDarkMode() ? new Color(5, 2, 2) : new Color(248, 244, 236));
        g2d.fillRect(0, 0, width, height);

        Point center = new Point(width / 2, 0);
        float radius = Math.max(width, height) * 0.9f;
        float[] dist = {0.0f, 0.4f, 1.0f};
        Color[] colors = {
            ThemeManager.isDarkMode() ? new Color(70, 40, 10, 180) : new Color(201, 162, 39, 65),
            ThemeManager.isDarkMode() ? new Color(35, 18, 5, 100) : new Color(201, 162, 39, 30),
            new Color(0, 0, 0, 0)
        };
        RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
        g2d.setPaint(spotlight);
        g2d.fillRect(0, 0, width, height);
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(16, 16));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setOpaque(false);

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTableSection(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel mainHeader = new JPanel(new BorderLayout(12, 12));
        mainHeader.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle(
                "Inventory Movements",
                "Track incoming and outgoing stock movements"
        );

        JPanel toolBarCard = new JPanel(new BorderLayout(10, 10));
        toolBarCard.setOpaque(true);
        toolBarCard.setBackground(glassColor());
        toolBarCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(10, 16, 10, 16)
        ));

        searchPanel = new SearchPanel();
        searchPanel.getSearchButton().addActionListener(e -> searchMovements());
        searchPanel.getRefreshButton().addActionListener(e -> loadMovements());
        toolBarCard.add(searchPanel, BorderLayout.CENTER);

        mainHeader.add(sectionTitle, BorderLayout.WEST);
        mainHeader.add(toolBarCard, BorderLayout.EAST);
        return mainHeader;
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(true);
        panel.setBackground(glassColor());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(14, 14, 14, 14)
        ));

        JPanel summaryStrip = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        summaryStrip.setOpaque(true);
        summaryStrip.setBackground(innerGlassColor());
        summaryStrip.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderSoftColor(), 1, true),
                BorderFactory.createEmptyBorder(10, 16, 10, 16)
        ));

        JLabel lbl = new JLabel("Total Movements Recorded: ");
        lbl.setFont(UIStyle.FONT_BODY);
        lbl.setForeground(ThemeManager.getTheme().getTextMuted());

        summaryLabel = new JLabel("0");
        summaryLabel.setFont(UIStyle.FONT_HEADING);
        summaryLabel.setForeground(new Color(224, 190, 78));

        summaryStrip.add(lbl);
        summaryStrip.add(summaryLabel);

        helperLabel = new JLabel("Search by item, serial, movement type, or note to focus the audit trail.");
        helperLabel.setFont(UIStyle.FONT_SMALL);
        helperLabel.setForeground(ThemeManager.getTheme().getTextMuted());
        helperLabel.setBorder(BorderFactory.createEmptyBorder(10, 4, 0, 4));

        tableModel = new DefaultTableModel(
                new Object[]{"Move ID", "Item Name", "Serial No", "Move Type", "Invoice Ref", "Purchase Ref", "Move Date", "Note"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        movementTable = new ModernTable();
        movementTable.setModel(tableModel);
        movementTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        movementTable.getColumnModel().getColumn(0).setPreferredWidth(80);
        movementTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        movementTable.getColumnModel().getColumn(2).setPreferredWidth(120);
        movementTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        movementTable.getColumnModel().getColumn(4).setPreferredWidth(100);
        movementTable.getColumnModel().getColumn(5).setPreferredWidth(110);
        movementTable.getColumnModel().getColumn(6).setPreferredWidth(180);
        movementTable.getColumnModel().getColumn(7).setPreferredWidth(250);

        JScrollPane scrollPane = new JScrollPane(movementTable);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        panel.add(summaryStrip, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(helperLabel, BorderLayout.SOUTH);
        return panel;
    }

    private void loadMovements() {
        try {
            fillTable(inventoryMovementService.getAllMovements());
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void searchMovements() {
        try {
            fillTable(inventoryMovementService.searchMovements(searchPanel.getSearchText()));
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void fillTable(List<InventoryMovement> movements) {
        tableModel.setRowCount(0);

        for (InventoryMovement movement : movements) {
            tableModel.addRow(new Object[]{
                    movement.getMoveId(),
                    movement.getItemName(),
                    movement.getSerialNo(),
                    movement.getMoveType(),
                    movement.getRefInvoiceId(),
                    movement.getRefPoId(),
                    movement.getMoveDate(),
                    movement.getNote()
            });
        }

        summaryLabel.setText(String.valueOf(movements.size()));
        helperLabel.setText(movements.isEmpty()
                ? "No inventory movement matches the current search."
                : "Showing " + movements.size() + " movement record(s).");
    }

    private Color glassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 120) : new Color(255, 255, 255, 215);
    }

    private Color innerGlassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 100) : new Color(248, 248, 248, 220);
    }

    private Color borderColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 80) : ThemeManager.getTheme().getBorder();
    }

    private Color borderSoftColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 50) : new Color(201, 162, 39, 90);
    }
}
