package com.tajstore.model;

import java.math.BigDecimal;

public class InvoiceDetail {

    private int invoiceDetailId;
    private int invoiceId;
    private int itemId;
    private BigDecimal salePrice;
    private BigDecimal goldPriceAtSale;
    private BigDecimal makingCostAtSale;

    public int getInvoiceDetailId() {
        return invoiceDetailId;
    }

    public void setInvoiceDetailId(int invoiceDetailId) {
        this.invoiceDetailId = invoiceDetailId;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public BigDecimal getGoldPriceAtSale() {
        return goldPriceAtSale;
    }

    public void setGoldPriceAtSale(BigDecimal goldPriceAtSale) {
        this.goldPriceAtSale = goldPriceAtSale;
    }

    public BigDecimal getMakingCostAtSale() {
        return makingCostAtSale;
    }

    public void setMakingCostAtSale(BigDecimal makingCostAtSale) {
        this.makingCostAtSale = makingCostAtSale;
    }
}