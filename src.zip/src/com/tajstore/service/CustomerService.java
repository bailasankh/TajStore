package com.tajstore.service;

import com.tajstore.dao.CustomerDao;
import com.tajstore.model.Customer;

import java.util.List;

public class CustomerService {

    private final CustomerDao customerDao;

    public CustomerService() {
        this.customerDao = new CustomerDao();
    }

    public List<Customer> getAllCustomers() {
        return customerDao.findAll();
    }

    public List<Customer> searchCustomers(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllCustomers();
        }
        return customerDao.search(keyword.trim());
    }

    public int addCustomer(String fullName, String phone, String address) {
        validateCustomer(fullName, phone, address, 0, false);

        Customer customer = new Customer();
        customer.setFullName(fullName.trim());
        customer.setPhone(normalize(phone));
        customer.setAddress(normalize(address));

        return customerDao.insert(customer);
    }

    public int addBulkCustomers(int count) {
        if (count <= 0) {
            throw new IllegalArgumentException("Customer count must be greater than 0.");
        }
        if (count > 500) {
            throw new IllegalArgumentException("Maximum allowed bulk insert is 500 customers at a time.");
        }

        int inserted = 0;
        for (int i = 1; i <= count; i++) {
            Customer customer = new Customer();
            customer.setFullName("Customer " + System.currentTimeMillis() + "-" + i);
            customer.setPhone(null);
            customer.setAddress("Bulk inserted");
            customerDao.insert(customer);
            inserted++;
        }
        return inserted;
    }

    public void updateCustomer(int customerId, String fullName, String phone, String address) {
        validateCustomer(fullName, phone, address, customerId, true);

        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        customer.setFullName(fullName.trim());
        customer.setPhone(normalize(phone));
        customer.setAddress(normalize(address));

        customerDao.update(customer);
    }

    public void deleteCustomer(int customerId) {
        customerDao.delete(customerId);
    }

    private void validateCustomer(String fullName, String phone, String address, int customerId, boolean isUpdate) {
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new IllegalArgumentException("Full name is required.");
        }

        if (fullName.trim().length() < 3) {
            throw new IllegalArgumentException("Full name must be at least 3 characters.");
        }

        if (phone != null && !phone.trim().isEmpty()) {
            String normalizedPhone = phone.trim();

            if (!normalizedPhone.matches("[0-9+\\- ]{7,20}")) {
                throw new IllegalArgumentException("Phone number format is invalid.");
            }

            if (customerDao.existsByPhoneExcludingId(normalizedPhone, isUpdate ? customerId : 0)) {
                throw new IllegalArgumentException("Phone number already exists.");
            }
        }

        if (address != null && address.trim().length() > 200) {
            throw new IllegalArgumentException("Address is too long.");
        }
    }

    private String normalize(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }
}