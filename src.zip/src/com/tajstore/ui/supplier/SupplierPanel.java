package com.tajstore.ui.supplier;

import com.tajstore.model.Supplier;
import com.tajstore.service.SupplierService;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.DangerButton;
import com.tajstore.ui.components.ModernTable;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SearchPanel;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;
import com.tajstore.theme.ThemeManager;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.util.List;

public class SupplierPanel extends BasePanel {

    private final SupplierService supplierService = new SupplierService();

    private ModernTable supplierTable;
    private DefaultTableModel tableModel;
    private SearchPanel searchPanel;

    public SupplierPanel() {
        initUI();
        loadSuppliers();
    }

    // === 1. دالة الخلفية الملكية ===
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int width = getWidth();
        int height = getHeight();
        g2d.setColor(ThemeManager.isDarkMode() ? new Color(5, 2, 2) : new Color(248, 244, 236));
        g2d.fillRect(0, 0, width, height);

        Point center = new Point(width / 2, 0);
        float radius = Math.max(width, height) * 0.9f;
        float[] dist = {0.0f, 0.4f, 1.0f};
        Color[] colors = {
            ThemeManager.isDarkMode() ? new Color(70, 40, 10, 180) : new Color(201, 162, 39, 65),
            ThemeManager.isDarkMode() ? new Color(35, 18, 5, 100) : new Color(201, 162, 39, 30),
            new Color(0, 0, 0, 0)
        };
        RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
        g2d.setPaint(spotlight);
        g2d.fillRect(0, 0, width, height);
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(16, 16));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setOpaque(false); // مهم جداً عشان الخلفية تبان

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTableSection(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel mainHeader = new JPanel(new BorderLayout(12, 12));
        mainHeader.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle("Suppliers", "Manage supplier records");

        // === شريط أدوات زجاجي واحد يجمع البحث والأزرار ===
        JPanel toolBarCard = new JPanel(new BorderLayout(10, 10));
        toolBarCard.setOpaque(true);
        toolBarCard.setBackground(glassColor()); // خلفية متوافقة مع الثيم
        toolBarCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(10, 16, 10, 16)
        ));

        searchPanel = new SearchPanel();
        searchPanel.getSearchButton().addActionListener(e -> searchSuppliers());
        searchPanel.getRefreshButton().addActionListener(e -> loadSuppliers());

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonsPanel.setOpaque(false);

        PrimaryButton addButton = new PrimaryButton("Add Supplier");
        SecondaryButton editButton = new SecondaryButton("Edit");
        DangerButton deleteButton = new DangerButton("Delete");

        addButton.addActionListener(e -> openAddDialog());
        editButton.addActionListener(e -> openEditDialog());
        deleteButton.addActionListener(e -> deleteSelectedSupplier());

        buttonsPanel.add(addButton);
        buttonsPanel.add(editButton);
        buttonsPanel.add(deleteButton);

        toolBarCard.add(searchPanel, BorderLayout.CENTER);
        toolBarCard.add(buttonsPanel, BorderLayout.EAST);

        mainHeader.add(sectionTitle, BorderLayout.WEST);
        mainHeader.add(toolBarCard, BorderLayout.EAST);

        return mainHeader;
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(true);
        
        // === 2. الكارت الزجاجي الداكن للجدول ===
        panel.setBackground(glassColor()); 
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true), // بوردة ذهبية
                BorderFactory.createEmptyBorder(14, 14, 14, 14)
        ));

        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Supplier Name", "Phone", "Address", "Created At"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        supplierTable = new ModernTable();
        supplierTable.setModel(tableModel);

        JScrollPane scrollPane = new JScrollPane(supplierTable);
        scrollPane.setBorder(null);
        // === 3. شفافية السكرول عشان الخلفية السوداء تبان ===
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));

        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    // === باقي الكود (البيانات والنوافذ) مو تغير فيه شي ===

    private void loadSuppliers() {
        try {
            List<Supplier> suppliers = supplierService.getAllSuppliers();
            fillTable(suppliers);
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void searchSuppliers() {
        try {
            List<Supplier> suppliers = supplierService.searchSuppliers(searchPanel.getSearchText());
            fillTable(suppliers);
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void fillTable(List<Supplier> suppliers) {
        tableModel.setRowCount(0);

        for (Supplier supplier : suppliers) {
            tableModel.addRow(new Object[]{
                    supplier.getSupplierId(),
                    supplier.getSupplierName(),
                    supplier.getPhone(),
                    supplier.getAddress(),
                    supplier.getCreatedAt()
            });
        }
    }

    private void openAddDialog() {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        SupplierFormDialog dialog = new SupplierFormDialog(owner, "Add Supplier", null);
        dialog.setVisible(true);

        if (!dialog.isSaved()) return;

        try {
            supplierService.addSupplier(
                    dialog.getSupplierNameValue(),
                    dialog.getPhoneValue(),
                    dialog.getAddressValue()
            );
            MessageUtil.showSuccess(this, "Supplier added successfully.");
            loadSuppliers();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void openEditDialog() {
        int selectedRow = supplierTable.getSelectedRow();
        if (selectedRow == -1) {
            MessageUtil.showError(this, "Please select a supplier to edit.");
            return;
        }

        Supplier supplier = new Supplier();
        supplier.setSupplierId((Integer) tableModel.getValueAt(selectedRow, 0));
        supplier.setSupplierName((String) tableModel.getValueAt(selectedRow, 1));
        supplier.setPhone((String) tableModel.getValueAt(selectedRow, 2));
        supplier.setAddress((String) tableModel.getValueAt(selectedRow, 3));

        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        SupplierFormDialog dialog = new SupplierFormDialog(owner, "Edit Supplier", supplier);
        dialog.setVisible(true);

        if (!dialog.isSaved()) return;

        try {
            supplierService.updateSupplier(
                    supplier.getSupplierId(),
                    dialog.getSupplierNameValue(),
                    dialog.getPhoneValue(),
                    dialog.getAddressValue()
            );
            MessageUtil.showSuccess(this, "Supplier updated successfully.");
            loadSuppliers();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void deleteSelectedSupplier() {
        int selectedRow = supplierTable.getSelectedRow();
        if (selectedRow == -1) {
            MessageUtil.showError(this, "Please select a supplier to delete.");
            return;
        }

        int supplierId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String supplierName = (String) tableModel.getValueAt(selectedRow, 1);

        boolean confirmed = MessageUtil.confirm(this, "Delete supplier: " + supplierName + "?");
        if (!confirmed) return;

        try {
            supplierService.deleteSupplier(supplierId);
            MessageUtil.showSuccess(this, "Supplier deleted successfully.");
            loadSuppliers();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private Color glassColor() {
        return ThemeManager.isDarkMode() ? new Color(0, 0, 0, 120) : new Color(255, 255, 255, 215);
    }

    private Color borderColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 80) : ThemeManager.getTheme().getBorder();
    }
}