package com.tajstore.ui.components;

import com.tajstore.service.AuthService;
import com.tajstore.session.SessionManager;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.auth.LoginFrame;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class TopBar extends JPanel {

    private final Runnable themeToggleHandler;
    private final AuthService authService = new AuthService();

    public TopBar(Runnable themeToggleHandler) {
        this.themeToggleHandler = themeToggleHandler;
        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout(12, 12));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        JPanel glass = new JPanel(new BorderLayout(12, 12)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(ThemeManager.isDarkMode() ? new Color(22, 16, 13, 205) : new Color(255, 252, 247, 220));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);

                g2.setColor(ThemeManager.isDarkMode() ? new Color(212, 175, 55, 95) : new Color(201, 162, 39, 130));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 24, 24);

                g2.setColor(ThemeManager.isDarkMode() ? new Color(255, 230, 170, 25) : new Color(201, 162, 39, 70));
                g2.drawRoundRect(8, 8, getWidth() - 17, getHeight() - 17, 18, 18);

                g2.dispose();
                super.paintComponent(g);
            }
        };

        glass.setOpaque(false);
        glass.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));

        glass.add(buildLeftSection(), BorderLayout.WEST);
        glass.add(buildRightSection(), BorderLayout.EAST);

        add(glass, BorderLayout.CENTER);
    }

    private JPanel buildLeftSection() {
        JPanel wrapper = new JPanel();
        wrapper.setOpaque(false);
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));

        String fullName = SessionManager.getCurrentFullName() != null
                ? SessionManager.getCurrentFullName()
                : "User";

        String role = SessionManager.getCurrentRole() != null
                ? SessionManager.getCurrentRole()
                : "Unknown";

        JLabel welcomeLabel = new JLabel("Welcome back, " + fullName);
        welcomeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        welcomeLabel.setForeground(ThemeManager.getTheme().getText());

        JPanel rolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        rolePanel.setOpaque(false);
        rolePanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel roleLabel = new JLabel("Role: " + role, SwingConstants.CENTER);
        roleLabel.setFont(UIStyle.FONT_SMALL);
        roleLabel.setForeground(ThemeManager.getTheme().getPrimary());
        roleLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(212, 175, 55, 75), 1, true),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        roleLabel.setOpaque(true);
        roleLabel.setBackground(ThemeManager.isDarkMode() ? new Color(38, 24, 17, 165) : new Color(255, 248, 225, 220));

        JLabel subtitleLabel = new JLabel("Manage your gold shop operations from one place");
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        subtitleLabel.setFont(UIStyle.FONT_SMALL);
        subtitleLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        rolePanel.add(roleLabel);

        wrapper.add(welcomeLabel);
        wrapper.add(Box.createVerticalStrut(6));
        wrapper.add(rolePanel);
        wrapper.add(Box.createVerticalStrut(7));
        wrapper.add(subtitleLabel);

        return wrapper;
    }

    private JPanel buildRightSection() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        panel.setOpaque(false);

        ThemeToggleButton themeButton = new ThemeToggleButton();
        DangerButton logoutButton = new DangerButton("Logout");

        themeButton.addActionListener(e -> themeToggleHandler.run());

        logoutButton.addActionListener(e -> {
            boolean confirmed = MessageUtil.confirm(this, "Are you sure you want to logout?");
            if (!confirmed) {
                return;
            }

            authService.logout();
            java.awt.Window window = javax.swing.SwingUtilities.getWindowAncestor(this);
            if (window != null) {
                window.dispose();
            }
            new LoginFrame().setVisible(true);
        });

        panel.add(themeButton);
        panel.add(logoutButton);

        return panel;
    }
}
