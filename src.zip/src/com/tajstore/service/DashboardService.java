package com.tajstore.service;

import com.tajstore.db.ConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DashboardService {

    public int getCustomerCount() {
        return getCount("SELECT COUNT(*) FROM customer");
    }

    public int getSupplierCount() {
        return getCount("SELECT COUNT(*) FROM supplier");
    }

    public int getGoldItemCount() {
        return getCount("SELECT COUNT(*) FROM gold_item");
    }

    public int getInventoryRecordCount() {
        return getCount("SELECT COUNT(*) FROM inventory");
    }

    public int getInvoiceCount() {
        return getCount("SELECT COUNT(*) FROM invoice");
    }

    public int getLowStockCount() {
        return getCount("SELECT COUNT(*) FROM inventory WHERE qty <= 1");
    }

    public double getTodaySalesTotal() {
        return getDecimalValue(
                "SELECT COALESCE(SUM(total_amount), 0) FROM invoice WHERE DATE(invoice_date) = CURRENT_DATE"
        );
    }

    public double getPendingPaymentsTotal() {
        return getDecimalValue(
                "SELECT COALESCE(SUM(total_amount), 0) FROM invoice WHERE status IN ('UNPAID', 'PARTIAL')"
        );
    }

    public int getTodayInvoiceCount() {
        return getCount("SELECT COUNT(*) FROM invoice WHERE DATE(invoice_date) = CURRENT_DATE");
    }

    public double getTodayEstimatedProfit() {
        return getDecimalValue(
                "SELECT COALESCE(SUM(d.sale_price - (COALESCE((" +
                "SELECT AVG(pd.price_per_unit) FROM purchase_details pd WHERE pd.item_id = d.item_id" +
                "), 0) * COALESCE(d.quantity, 1))), 0) " +
                "FROM invoice i " +
                "JOIN invoice_details d ON i.invoice_id = d.invoice_id " +
                "WHERE DATE(i.invoice_date) = CURRENT_DATE"
        );
    }

    private int getCount(String sql) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load dashboard count.", e);
        }

        return 0;
    }

    private double getDecimalValue(String sql) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load dashboard numeric value.", e);
        }

        return 0.0;
    }
}
