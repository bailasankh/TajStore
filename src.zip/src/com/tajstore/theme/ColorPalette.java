package com.tajstore.theme;

import java.awt.Color;

public final class ColorPalette {

    private ColorPalette() {
    }

    // Gold / luxury colors
    public static final Color GOLD_PRIMARY = new Color(201, 162, 39);   // elegant gold
    public static final Color GOLD_DARK = new Color(161, 120, 20);      // deep gold
    public static final Color GOLD_LIGHT = new Color(230, 196, 92);     // soft gold

    // Light theme
    public static final Color LIGHT_BACKGROUND = new Color(246, 242, 235);
    public static final Color LIGHT_SURFACE = new Color(255, 252, 247);
    public static final Color LIGHT_SURFACE_ALT = new Color(240, 233, 221);
    public static final Color LIGHT_TEXT = new Color(33, 37, 41);
    public static final Color LIGHT_TEXT_MUTED = new Color(108, 117, 125);
    public static final Color LIGHT_BORDER = new Color(214, 202, 183);
    public static final Color LIGHT_SUCCESS = new Color(40, 167, 69);
    public static final Color LIGHT_DANGER = new Color(220, 53, 69);
    public static final Color LIGHT_WARNING = new Color(255, 193, 7);

    // Dark caramel theme
    public static final Color DARK_BACKGROUND = new Color(23, 18, 15);      // deep mocha
    public static final Color DARK_SURFACE = new Color(39, 30, 25);         // warm brown
    public static final Color DARK_SURFACE_ALT = new Color(58, 45, 36);     // caramel brown
    public static final Color DARK_TEXT = new Color(248, 240, 227);         // warm cream
    public static final Color DARK_TEXT_MUTED = new Color(214, 198, 173);   // muted sand
    public static final Color DARK_BORDER = new Color(142, 112, 78);        // soft bronze
    public static final Color DARK_SUCCESS = new Color(102, 187, 106);
    public static final Color DARK_DANGER = new Color(229, 115, 115);
    public static final Color DARK_WARNING = new Color(255, 202, 40);

    // Unified button text colors
    public static final Color BUTTON_TEXT_ON_GOLD = new Color(36, 24, 16);
    public static final Color BUTTON_TEXT_ON_DARK = new Color(245, 236, 220);
    public static final Color BUTTON_TEXT_ON_LIGHT = new Color(33, 37, 41);

    // Extra helper shades
    public static final Color SHADOW_SOFT = new Color(0, 0, 0, 25);
}
