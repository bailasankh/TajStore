package com.tajstore.model;

import java.time.LocalDate;
import java.sql.Timestamp;

public class GoldPriceHistory {

    private int priceId;
    private LocalDate priceDate;
    private double price24k;
    private double price21k;
    private double price18k;
    private Timestamp createdAt;

    // getters & setters

    public int getPriceId() {
        return priceId;
    }

    public void setPriceId(int priceId) {
        this.priceId = priceId;
    }

    public LocalDate getPriceDate() {
        return priceDate;
    }

    public void setPriceDate(LocalDate priceDate) {
        this.priceDate = priceDate;
    }

    public double getPrice24k() {
        return price24k;
    }

    public void setPrice24k(double price24k) {
        this.price24k = price24k;
    }

    public double getPrice21k() {
        return price21k;
    }

    public void setPrice21k(double price21k) {
        this.price21k = price21k;
    }

    public double getPrice18k() {
        return price18k;
    }

    public void setPrice18k(double price18k) {
        this.price18k = price18k;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
}