package com.tajstore.ui.components;

import com.tajstore.theme.UIStyle;
import com.tajstore.theme.ThemeManager;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class StatsCard extends JPanel {

    private final JLabel titleLabel;
    private final JLabel valueLabel;
    private final JLabel subtitleLabel;

    private final Color normalBg = ThemeManager.isDarkMode() ? new Color(24, 14, 10, 150) : new Color(255, 255, 255, 215);
    private final Color hoverBg = ThemeManager.isDarkMode() ? new Color(38, 22, 14, 185) : new Color(248, 242, 230, 235);
    private boolean hovered = false;

    public StatsCard(String title, String value) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);
        setPreferredSize(new Dimension(220, 120));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        titleLabel = new JLabel(title);
        titleLabel.setFont(UIStyle.FONT_BODY);
        titleLabel.setForeground(ThemeManager.getTheme().getTextMuted());
        titleLabel.setAlignmentX(LEFT_ALIGNMENT);

        valueLabel = new JLabel(value);
        valueLabel.setFont(UIStyle.FONT_TITLE);
        valueLabel.setForeground(ThemeManager.getTheme().getPrimary());
        valueLabel.setAlignmentX(LEFT_ALIGNMENT);

        subtitleLabel = new JLabel(" ");
        subtitleLabel.setFont(UIStyle.FONT_SMALL);
        subtitleLabel.setForeground(ThemeManager.getTheme().getTextMuted());
        subtitleLabel.setAlignmentX(LEFT_ALIGNMENT);

        add(titleLabel);
        add(Box.createVerticalStrut(12));
        add(valueLabel);
        add(Box.createVerticalStrut(8));
        add(subtitleLabel);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(hovered ? hoverBg : normalBg);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);

        g2.setColor(ThemeManager.isDarkMode() ? new Color(212, 175, 55, hovered ? 110 : 70) : new Color(201, 162, 39, hovered ? 160 : 110));
        g2.setStroke(new BasicStroke(1.2f));
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 24, 24);

        g2.setColor(ThemeManager.isDarkMode() ? new Color(255, 230, 170, hovered ? 35 : 20) : new Color(201, 162, 39, hovered ? 70 : 45));
        g2.drawRoundRect(8, 8, getWidth() - 17, getHeight() - 17, 18, 18);

        g2.dispose();
        super.paintComponent(g);
    }

    public void setValue(String value) {
        valueLabel.setText(value);
    }

    public void setTitle(String title) {
        titleLabel.setText(title);
    }

    public void setSubtitle(String subtitle) {
        subtitleLabel.setText(subtitle == null || subtitle.isBlank() ? " " : subtitle);
    }
}
