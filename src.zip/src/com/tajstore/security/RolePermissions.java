package com.tajstore.security;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class RolePermissions {

    private static final Map<String, Set<Permission>> ROLE_PERMISSION_MAP = new HashMap<>();

    static {
        ROLE_PERMISSION_MAP.put("ADMIN", EnumSet.allOf(Permission.class));

        ROLE_PERMISSION_MAP.put("MANAGER", EnumSet.of(
                Permission.VIEW_DASHBOARD,
                Permission.MANAGE_CUSTOMERS,
                Permission.VIEW_INVENTORY,
                Permission.VIEW_REPORTS
        ));

        ROLE_PERMISSION_MAP.put("CASHIER", EnumSet.of(
                Permission.VIEW_DASHBOARD,
                Permission.MANAGE_SALES
        ));
    }

    private RolePermissions() {
    }

    public static Set<Permission> getPermissionsByRole(String roleName) {
        if (roleName == null) {
            return EnumSet.noneOf(Permission.class);
        }
        return ROLE_PERMISSION_MAP.getOrDefault(
                roleName.trim().toUpperCase(),
                EnumSet.noneOf(Permission.class)
        );
    }
}