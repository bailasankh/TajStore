package com.tajstore.model;

public class PaymentMethod {

    private int methodId;
    private String name;

    public PaymentMethod() {
    }

    public PaymentMethod(int methodId, String name) {
        this.methodId = methodId;
        this.name = name;
    }

    public int getMethodId() {
        return methodId;
    }

    public void setMethodId(int methodId) {
        this.methodId = methodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}