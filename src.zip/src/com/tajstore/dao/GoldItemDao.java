package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.GoldItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GoldItemDao {

    private static final String FIND_ALL_SQL =
            "SELECT g.item_id, g.item_name, g.serial_no, g.category_id, c.category_name, " +
            "g.weight_gram, g.karat, g.making_cost, g.image_path, g.is_active, g.created_at " +
            "FROM gold_item g " +
            "JOIN category c ON g.category_id = c.category_id " +
            "ORDER BY g.item_id DESC";

    private static final String SEARCH_SQL =
            "SELECT g.item_id, g.item_name, g.serial_no, g.category_id, c.category_name, " +
            "g.weight_gram, g.karat, g.making_cost, g.image_path, g.is_active, g.created_at " +
            "FROM gold_item g " +
            "JOIN category c ON g.category_id = c.category_id " +
            "WHERE g.item_name LIKE ? OR g.serial_no LIKE ? OR c.category_name LIKE ? " +
            "ORDER BY g.item_id DESC";

    private static final String INSERT_SQL =
            "INSERT INTO gold_item (item_name, serial_no, category_id, weight_gram, karat, making_cost, image_path, is_active) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE_SQL =
            "UPDATE gold_item SET item_name = ?, serial_no = ?, category_id = ?, weight_gram = ?, karat = ?, making_cost = ?, image_path = ?, is_active = ? " +
            "WHERE item_id = ?";

    private static final String EXISTS_SERIAL_SQL =
            "SELECT COUNT(*) FROM gold_item WHERE serial_no = ? AND item_id <> ?";

    public List<GoldItem> findAll() {
        List<GoldItem> items = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                items.add(mapRow(rs));
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to load gold items.", e);
        }

        return items;
    }

    public List<GoldItem> search(String keyword) {
        List<GoldItem> items = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_SQL)) {

            String value = "%" + keyword + "%";
            statement.setString(1, value);
            statement.setString(2, value);
            statement.setString(3, value);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    items.add(mapRow(rs));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to search gold items.", e);
        }

        return items;
    }

    public int insert(GoldItem item) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, item.getItemName());
            statement.setString(2, item.getSerialNo());
            statement.setInt(3, item.getCategoryId());
            statement.setBigDecimal(4, item.getWeightGram());
            statement.setInt(5, item.getKarat());
            statement.setBigDecimal(6, item.getMakingCost());
            statement.setString(7, item.getImagePath());
            statement.setBoolean(8, item.isActive());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new RuntimeException("Creating gold item failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }

            throw new RuntimeException("Creating gold item failed, no ID obtained.");

        } catch (SQLIntegrityConstraintViolationException e) {
            throw new IllegalArgumentException("Serial number already exists.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to insert gold item.", e);
        }
    }

    public void update(GoldItem item) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SQL)) {

            statement.setString(1, item.getItemName());
            statement.setString(2, item.getSerialNo());
            statement.setInt(3, item.getCategoryId());
            statement.setBigDecimal(4, item.getWeightGram());
            statement.setInt(5, item.getKarat());
            statement.setBigDecimal(6, item.getMakingCost());
            statement.setString(7, item.getImagePath());
            statement.setBoolean(8, item.isActive());
            statement.setInt(9, item.getItemId());

            statement.executeUpdate();

        } catch (SQLIntegrityConstraintViolationException e) {
            throw new IllegalArgumentException("Serial number already exists.");
        } catch (Exception e) {
            throw new RuntimeException("Failed to update gold item.", e);
        }
    }

    public boolean existsSerialNoExcludingId(String serialNo, int itemId) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(EXISTS_SERIAL_SQL)) {

            statement.setString(1, serialNo);
            statement.setInt(2, itemId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to check serial number uniqueness.", e);
        }

        return false;
    }

    private GoldItem mapRow(ResultSet rs) throws SQLException {
        GoldItem item = new GoldItem();
        item.setItemId(rs.getInt("item_id"));
        item.setItemName(rs.getString("item_name"));
        item.setSerialNo(rs.getString("serial_no"));
        item.setCategoryId(rs.getInt("category_id"));
        item.setCategoryName(rs.getString("category_name"));
        item.setWeightGram(rs.getBigDecimal("weight_gram"));
        item.setKarat(rs.getInt("karat"));
        item.setMakingCost(rs.getBigDecimal("making_cost"));
        item.setImagePath(rs.getString("image_path"));
        item.setActive(rs.getBoolean("is_active"));

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            item.setCreatedAt(createdAt.toLocalDateTime());
        }

        return item;
    }
}
