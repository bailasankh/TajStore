package com.tajstore.ui.customer;

import com.tajstore.model.Customer;
import com.tajstore.service.CustomerService;
import com.tajstore.theme.ThemeManager;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.DangerButton;
import com.tajstore.ui.components.ModernTable;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SearchPanel;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.ui.components.SecondaryButton;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.util.List;

public class CustomerPanel extends BasePanel {

    private final CustomerService customerService = new CustomerService();

    private ModernTable customerTable;
    private DefaultTableModel tableModel;
    private SearchPanel searchPanel;

    public CustomerPanel() {
        initUI();
        loadCustomers();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();
        g2d.setColor(ThemeManager.getTheme().getBackground());
        g2d.fillRect(0, 0, width, height);

        Point center = new Point(width / 2, 0);
        float radius = Math.max(width, height) * 0.9f;
        float[] dist = {0.0f, 0.4f, 1.0f};
        Color[] colors = {
                ThemeManager.isDarkMode() ? new Color(70, 40, 10, 160) : new Color(201, 162, 39, 55),
                ThemeManager.isDarkMode() ? new Color(35, 18, 5, 85) : new Color(201, 162, 39, 22),
                new Color(0, 0, 0, 0)
        };
        RadialGradientPaint spotlight = new RadialGradientPaint(center, radius, dist, colors);
        g2d.setPaint(spotlight);
        g2d.fillRect(0, 0, width, height);
        g2d.dispose();
    }

    @Override
    protected void initUI() {
        removeAll();
        setLayout(new BorderLayout(16, 16));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setOpaque(false);

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTableSection(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout(0, 14));
        header.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle("Customers", "Manage customer records");

        JPanel toolBarCard = new JPanel(new BorderLayout(12, 12));
        toolBarCard.setOpaque(true);
        toolBarCard.setBackground(glassColor());
        toolBarCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));

        searchPanel = new SearchPanel();
        searchPanel.getSearchButton().addActionListener(e -> searchCustomers());
        searchPanel.getRefreshButton().addActionListener(e -> loadCustomers());

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttonsPanel.setOpaque(false);

        PrimaryButton addButton = new PrimaryButton("Add Customer");
        SecondaryButton bulkAddButton = new SecondaryButton("Bulk Add");
        SecondaryButton editButton = new SecondaryButton("Edit");
        DangerButton deleteButton = new DangerButton("Delete");

        addButton.addActionListener(e -> openAddDialog());
        bulkAddButton.addActionListener(e -> openBulkAddDialog());
        editButton.addActionListener(e -> openEditDialog());
        deleteButton.addActionListener(e -> deleteSelectedCustomer());

        buttonsPanel.add(addButton);
        buttonsPanel.add(bulkAddButton);
        buttonsPanel.add(editButton);
        buttonsPanel.add(deleteButton);

        JPanel actionsRow = new JPanel();
        actionsRow.setOpaque(false);
        actionsRow.setLayout(new BoxLayout(actionsRow, BoxLayout.X_AXIS));
        actionsRow.add(searchPanel);
        actionsRow.add(Box.createHorizontalStrut(12));
        actionsRow.add(buttonsPanel);

        toolBarCard.add(actionsRow, BorderLayout.CENTER);

        header.add(sectionTitle, BorderLayout.NORTH);
        header.add(toolBarCard, BorderLayout.CENTER);

        return header;
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(true);
        panel.setBackground(glassColor());
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor(), 1, true),
                BorderFactory.createEmptyBorder(14, 14, 14, 14)
        ));

        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Full Name", "Phone", "Address", "Created At"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        customerTable = new ModernTable();
        customerTable.setModel(tableModel);

        JScrollPane scrollPane = new JScrollPane(customerTable);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0, 0, 0, 0));
        scrollPane.setPreferredSize(new Dimension(100, 420));

        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private void loadCustomers() {
        try {
            List<Customer> customers = customerService.getAllCustomers();
            fillTable(customers);
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void searchCustomers() {
        try {
            List<Customer> customers = customerService.searchCustomers(searchPanel.getSearchText());
            fillTable(customers);
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void fillTable(List<Customer> customers) {
        tableModel.setRowCount(0);

        for (Customer customer : customers) {
            tableModel.addRow(new Object[]{
                    customer.getCustomerId(),
                    customer.getFullName(),
                    customer.getPhone(),
                    customer.getAddress(),
                    customer.getCreatedAt()
            });
        }
    }

    private void openAddDialog() {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        CustomerFormDialog dialog = new CustomerFormDialog(owner, "Add Customer", null);
        dialog.setVisible(true);

        if (!dialog.isSaved()) {
            return;
        }

        try {
            customerService.addCustomer(
                    dialog.getFullNameValue(),
                    dialog.getPhoneValue(),
                    dialog.getAddressValue()
            );
            MessageUtil.showSuccess(this, "Customer added successfully.");
            loadCustomers();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void openEditDialog() {
        int selectedRow = customerTable.getSelectedRow();
        if (selectedRow == -1) {
            MessageUtil.showError(this, "Please select a customer to edit.");
            return;
        }

        Customer customer = new Customer();
        customer.setCustomerId((Integer) tableModel.getValueAt(selectedRow, 0));
        customer.setFullName((String) tableModel.getValueAt(selectedRow, 1));
        customer.setPhone((String) tableModel.getValueAt(selectedRow, 2));
        customer.setAddress((String) tableModel.getValueAt(selectedRow, 3));

        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        CustomerFormDialog dialog = new CustomerFormDialog(owner, "Edit Customer", customer);
        dialog.setVisible(true);

        if (!dialog.isSaved()) {
            return;
        }

        try {
            customerService.updateCustomer(
                    customer.getCustomerId(),
                    dialog.getFullNameValue(),
                    dialog.getPhoneValue(),
                    dialog.getAddressValue()
            );
            MessageUtil.showSuccess(this, "Customer updated successfully.");
            loadCustomers();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void openBulkAddDialog() {
        String input = JOptionPane.showInputDialog(
                this,
                "Enter number of customers to add:",
                "Bulk Add Customers",
                JOptionPane.QUESTION_MESSAGE
        );

        if (input == null) {
            return;
        }

        try {
            int count = Integer.parseInt(input.trim());
            int inserted = customerService.addBulkCustomers(count);
            MessageUtil.showSuccess(this, inserted + " customers added successfully.");
            loadCustomers();
        } catch (NumberFormatException e) {
            MessageUtil.showError(this, "Please enter a valid number.");
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void deleteSelectedCustomer() {
        int selectedRow = customerTable.getSelectedRow();
        if (selectedRow == -1) {
            MessageUtil.showError(this, "Please select a customer to delete.");
            return;
        }

        int customerId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String customerName = (String) tableModel.getValueAt(selectedRow, 1);

        boolean confirmed = MessageUtil.confirm(this, "Delete customer: " + customerName + "?");
        if (!confirmed) {
            return;
        }

        try {
            customerService.deleteCustomer(customerId);
            MessageUtil.showSuccess(this, "Customer deleted successfully.");
            loadCustomers();
        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private Color glassColor() {
        return ThemeManager.isDarkMode() ? new Color(17, 12, 10, 210) : new Color(255, 252, 247, 228);
    }

    private Color borderColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 95) : ThemeManager.getTheme().getBorder();
    }
}
