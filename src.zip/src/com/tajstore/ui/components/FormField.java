package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.GridLayout;

public class FormField extends JPanel {

    public FormField(String labelText, JComponent field) {
        setOpaque(false);
        setLayout(new GridLayout(2, 1, 0, 6));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));

        JLabel label = new JLabel(labelText);
        label.setFont(UIStyle.FONT_BODY);
        label.setForeground(ThemeManager.getTheme().getText());

        add(label);
        add(field);
    }
}