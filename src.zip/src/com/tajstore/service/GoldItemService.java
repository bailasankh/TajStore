package com.tajstore.service;

import com.tajstore.dao.CategoryDao;
import com.tajstore.dao.GoldItemDao;
import com.tajstore.model.Category;
import com.tajstore.model.GoldItem;

import java.math.BigDecimal;
import java.util.List;

public class GoldItemService {

    private final GoldItemDao goldItemDao;
    private final CategoryDao categoryDao;

    public GoldItemService() {
        this.goldItemDao = new GoldItemDao();
        this.categoryDao = new CategoryDao();
    }

    public List<GoldItem> getAllGoldItems() {
        return goldItemDao.findAll();
    }

    public List<GoldItem> searchGoldItems(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllGoldItems();
        }
        return goldItemDao.search(keyword.trim());
    }

    public List<Category> getAllCategories() {
        return categoryDao.findAll();
    }

    public int addGoldItem(String itemName, String serialNo, int categoryId, String weightGram,
                           int karat, String makingCost, String imagePath, boolean active) {
        validateGoldItem(itemName, serialNo, categoryId, weightGram, karat, makingCost, imagePath, 0);

        GoldItem item = new GoldItem();
        item.setItemName(itemName.trim());
        item.setSerialNo(serialNo.trim());
        item.setCategoryId(categoryId);
        item.setWeightGram(new BigDecimal(weightGram.trim()));
        item.setKarat(karat);
        item.setMakingCost(new BigDecimal(makingCost.trim()));
        item.setImagePath(normalizeImagePath(imagePath));
        item.setActive(active);

        return goldItemDao.insert(item);
    }

    public void updateGoldItem(int itemId, String itemName, String serialNo, int categoryId, String weightGram,
                               int karat, String makingCost, String imagePath, boolean active) {
        validateGoldItem(itemName, serialNo, categoryId, weightGram, karat, makingCost, imagePath, itemId);

        GoldItem item = new GoldItem();
        item.setItemId(itemId);
        item.setItemName(itemName.trim());
        item.setSerialNo(serialNo.trim());
        item.setCategoryId(categoryId);
        item.setWeightGram(new BigDecimal(weightGram.trim()));
        item.setKarat(karat);
        item.setMakingCost(new BigDecimal(makingCost.trim()));
        item.setImagePath(normalizeImagePath(imagePath));
        item.setActive(active);

        goldItemDao.update(item);
    }

    private void validateGoldItem(String itemName, String serialNo, int categoryId, String weightGram,
                                  int karat, String makingCost, String imagePath, int itemId) {
        if (itemName == null || itemName.trim().isEmpty()) {
            throw new IllegalArgumentException("Item name is required.");
        }

        if (serialNo == null || serialNo.trim().isEmpty()) {
            throw new IllegalArgumentException("Serial number is required.");
        }

        if (goldItemDao.existsSerialNoExcludingId(serialNo.trim(), itemId)) {
            throw new IllegalArgumentException("Serial number already exists.");
        }

        if (categoryId <= 0) {
            throw new IllegalArgumentException("Please select a category.");
        }

        try {
            BigDecimal weight = new BigDecimal(weightGram.trim());
            if (weight.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("Weight must be greater than zero.");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Weight must be a valid number.");
        }

        if (karat != 18 && karat != 21 && karat != 24) {
            throw new IllegalArgumentException("Karat must be 18, 21, or 24.");
        }

        try {
            BigDecimal cost = new BigDecimal(makingCost.trim());
            if (cost.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException("Making cost cannot be negative.");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Making cost must be a valid number.");
        }

        if (imagePath != null && !imagePath.trim().isEmpty() && imagePath.trim().length() > 255) {
            throw new IllegalArgumentException("Image path is too long.");
        }
    }

    private String normalizeImagePath(String imagePath) {
        if (imagePath == null) {
            return null;
        }
        String value = imagePath.trim();
        return value.isEmpty() ? null : value;
    }
}
