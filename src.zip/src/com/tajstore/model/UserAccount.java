package com.tajstore.model;

public class UserAccount {

    private int userId;
    private String username;
    private String passwordHash;
    private String salt; // 1. أضفنا المتغير هنا مع باقي المتغيرات
    private String fullName;
    private boolean active;
    private int roleId;
    private String roleName;

    public UserAccount() {
    }

    public UserAccount(int userId, String username, String passwordHash, String fullName, boolean active, int roleId) {
        this.userId = userId;
        this.username = username;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
        this.active = active;
        this.roleId = roleId;
    }

    public UserAccount(int userId, String username, String passwordHash, String fullName, boolean active, int roleId, String roleName) {
        this.userId = userId;
        this.username = username;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
        this.active = active;
        this.roleId = roleId;
        this.roleName = roleName;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    // 2. مسحنا الدالتين اللي كانت مسببة مشاكل واستبدلناهم بالكود الصح
    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }
}