package com.tajstore.ui.auth;

import javax.swing.*;
import java.awt.*;

public class Splashscreen extends JWindow {

    private float opacityValue = 0.0f;

    public Splashscreen() {
        initUI();
        startFadeIn();
        startSplashTimer();
    }

    private void initUI() {
        setSize(900, 550);
        setLocationRelativeTo(null);
        setBackground(new Color(0, 0, 0, 0));

        JPanel mainPanel = new BackgroundPanel("/com/tajstore/assets/splash_bg.jpg");
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));

        // ===== Overlay content panel =====
        JPanel overlayPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();

                // dark luxury overlay
                g2.setColor(new Color(8, 8, 8, 170));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 35, 35);

                // golden soft glow
                g2.setColor(new Color(212, 175, 55, 30));
                g2.fillOval(-60, -40, 250, 250);
                g2.fillOval(getWidth() - 220, getHeight() - 170, 260, 260);

                // elegant border
                g2.setColor(new Color(212, 175, 55, 140));
                g2.setStroke(new BasicStroke(2.2f));
                g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 35, 35);

                // inner border
                g2.setColor(new Color(255, 230, 160, 60));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(10, 10, getWidth() - 21, getHeight() - 21, 28, 28);

                g2.dispose();
                super.paintComponent(g);
            }
        };
        overlayPanel.setOpaque(false);
        overlayPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // ===== Center content =====
        JPanel centerPanel = new JPanel();
        centerPanel.setOpaque(false);
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        centerPanel.add(Box.createVerticalStrut(20));

        JLabel logoLabel = new JLabel();
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        try {
            java.net.URL logoUrl = getClass().getResource("/com/tajstore/assets/logo.png");
            if (logoUrl != null) {
                Image logoImg = new ImageIcon(logoUrl).getImage()
                        .getScaledInstance(180, 180, Image.SCALE_SMOOTH);
                logoLabel.setIcon(new ImageIcon(logoImg));
            } else {
                logoLabel.setText("✦");
                logoLabel.setFont(new Font("Serif", Font.BOLD, 110));
                logoLabel.setForeground(new Color(212, 175, 55));
            }
        } catch (Exception e) {
            logoLabel.setText("✦");
            logoLabel.setFont(new Font("Serif", Font.BOLD, 110));
            logoLabel.setForeground(new Color(212, 175, 55));
        }

        JLabel titleLabel = new JLabel("TAJ STORE");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 50));
        titleLabel.setForeground(new Color(232, 196, 87));

        JLabel lineLabel = new JLabel("━━━━━━━━━━━━━━━━━━━━");
        lineLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        lineLabel.setFont(new Font("Serif", Font.PLAIN, 20));
        lineLabel.setForeground(new Color(190, 150, 50));

        JLabel subtitleLabel = new JLabel("Luxury Gold Management System");
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitleLabel.setFont(new Font("SansSerif", Font.PLAIN, 20));
        subtitleLabel.setForeground(new Color(245, 235, 220));

        JLabel welcomeLabel = new JLabel("Where Elegance Meets Smart Business");
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setFont(new Font("SansSerif", Font.ITALIC, 16));
        welcomeLabel.setForeground(new Color(220, 205, 175));

        JLabel versionLabel = new JLabel("Premium Edition");
        versionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        versionLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        versionLabel.setForeground(new Color(212, 175, 55));

        centerPanel.add(logoLabel);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(titleLabel);
        centerPanel.add(Box.createVerticalStrut(8));
        centerPanel.add(lineLabel);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(subtitleLabel);
        centerPanel.add(Box.createVerticalStrut(8));
        centerPanel.add(welcomeLabel);
        centerPanel.add(Box.createVerticalStrut(10));
        centerPanel.add(versionLabel);

        // ===== Bottom loading section =====
        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));

        JLabel loadingLabel = new JLabel("Loading Taj Store Experience...");
        loadingLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        loadingLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));
        loadingLabel.setForeground(new Color(240, 230, 210));

        JProgressBar loadingBar = new JProgressBar();
        loadingBar.setIndeterminate(true);
        loadingBar.setBorderPainted(false);
        loadingBar.setStringPainted(false);
        loadingBar.setForeground(new Color(212, 175, 55));
        loadingBar.setBackground(new Color(55, 40, 20));
        loadingBar.setMaximumSize(new Dimension(380, 10));
        loadingBar.setPreferredSize(new Dimension(380, 10));
        loadingBar.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel footerLabel = new JLabel("© Taj Store");
        footerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        footerLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        footerLabel.setForeground(new Color(180, 165, 130));

        bottomPanel.add(loadingLabel);
        bottomPanel.add(Box.createVerticalStrut(12));
        bottomPanel.add(loadingBar);
        bottomPanel.add(Box.createVerticalStrut(14));
        bottomPanel.add(footerLabel);

        overlayPanel.add(centerPanel, BorderLayout.CENTER);
        overlayPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(overlayPanel, BorderLayout.CENTER);
        setContentPane(mainPanel);
    }

    private void startFadeIn() {
        try {
            setOpacity(0f);
        } catch (Exception e) {
            return;
        }

        Timer fadeTimer = new Timer(35, null);
        fadeTimer.addActionListener(e -> {
            opacityValue += 0.05f;
            if (opacityValue >= 1f) {
                opacityValue = 1f;
                fadeTimer.stop();
            }
            try {
                setOpacity(opacityValue);
            } catch (Exception ignored) {
            }
        });
        fadeTimer.start();
    }

    private void startSplashTimer() {
        Timer timer = new Timer(4200, e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        });
        timer.setRepeats(false);
        timer.start();
    }

    // ===== Custom background panel =====
    static class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String imagePath) {
            try {
                java.net.URL bgUrl = getClass().getResource(imagePath);
                if (bgUrl != null) {
                    backgroundImage = new ImageIcon(bgUrl).getImage();
                }
            } catch (Exception e) {
                backgroundImage = null;
            }
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();

            if (backgroundImage != null) {
                g2.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            } else {
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(10, 10, 10),
                        0, getHeight(), new Color(45, 30, 15)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }
}