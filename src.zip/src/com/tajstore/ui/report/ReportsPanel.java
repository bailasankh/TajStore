package com.tajstore.ui.report;

import com.tajstore.model.InventoryReportRow;
import com.tajstore.model.SalesReportRow;
import com.tajstore.model.TopCategoryReportRow;
import com.tajstore.service.ReportService;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BasePanel;
import com.tajstore.ui.components.ModernTable;
import com.tajstore.ui.components.PrimaryButton;
import com.tajstore.ui.components.SectionTitle;
import com.tajstore.util.MessageUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Point;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.util.List;

public class ReportsPanel extends BasePanel {

    private final ReportService reportService = new ReportService();

    private ModernTable salesTable;
    private ModernTable inventoryTable;
    private ModernTable topCategoryTable;

    private DefaultTableModel salesTableModel;
    private DefaultTableModel inventoryTableModel;
    private DefaultTableModel topCategoryTableModel;

    private JTextField fromDateField;
    private JTextField toDateField;

    private JLabel salesSummaryLabel;
    private JLabel inventorySummaryLabel;
    private JLabel topCategorySummaryLabel;
    private JLabel salesHintLabel;
    private JLabel inventoryHintLabel;
    private JLabel topCategoryHintLabel;

    private static final Color PAGE_BG_TOP = new Color(18, 9, 5);
    private static final Color PAGE_BG_BOTTOM = new Color(7, 3, 2);

    private static final Color CARD_BG = new Color(20, 10, 6, 215);
    private static final Color CARD_INNER = new Color(34, 18, 11, 225);
    private static final Color SOFT_GOLD = new Color(212, 175, 55);
    private static final Color LIGHT_GOLD = new Color(235, 203, 108);
    private static final Color MUTED_GOLD = new Color(177, 145, 78);
    private static final Color TEXT_PRIMARY = new Color(247, 240, 230);
    private static final Color TEXT_SECONDARY = new Color(214, 197, 170);
    private static final Color TEXT_MUTED = new Color(170, 150, 125);
    private static final Color FIELD_BG = new Color(41, 24, 16);
    private static final Color TABLE_BG = new Color(16, 8, 5);
    private static final Color TABLE_ALT_BG = new Color(23, 12, 8);
    private static final Color TABLE_HEADER_BG = new Color(201, 168, 72);
    private static final Color TABLE_HEADER_TEXT = new Color(32, 16, 7);
    private static final Color ACCENT_LINE = new Color(212, 175, 55, 85);

    public ReportsPanel() {
        initUI();
        loadInventoryReport();
        loadTopCategoryReport();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        GradientPaint baseGradient = new GradientPaint(
                0, 0, PAGE_BG_TOP,
                0, h, PAGE_BG_BOTTOM
        );
        g2.setPaint(baseGradient);
        g2.fillRect(0, 0, w, h);

        float[] distTop = {0.0f, 0.28f, 1.0f};
        Color[] colorsTop = {
                new Color(120, 72, 18, 90),
                new Color(70, 38, 10, 35),
                new Color(0, 0, 0, 0)
        };
        RadialGradientPaint glowTop = new RadialGradientPaint(
                new Point((int) (w * 0.72), (int) (h * 0.08)),
                Math.max(w, h) * 0.65f,
                distTop,
                colorsTop
        );
        g2.setPaint(glowTop);
        g2.fillRect(0, 0, w, h);

        float[] distLeft = {0.0f, 0.35f, 1.0f};
        Color[] colorsLeft = {
                new Color(90, 48, 14, 55),
                new Color(45, 20, 8, 18),
                new Color(0, 0, 0, 0)
        };
        RadialGradientPaint glowLeft = new RadialGradientPaint(
                new Point((int) (w * 0.12), (int) (h * 0.45)),
                Math.max(w, h) * 0.55f,
                distLeft,
                colorsLeft
        );
        g2.setPaint(glowLeft);
        g2.fillRect(0, 0, w, h);

        g2.dispose();
    }

    @Override
    protected void initUI() {
        removeAll();
        setOpaque(false);
        setLayout(new BorderLayout(18, 18));
        setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));

        add(buildHeader(), BorderLayout.NORTH);
        add(buildMainCard(), BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        SectionTitle sectionTitle = new SectionTitle(
                "Reports",
                "Track sales performance, inventory status, and top-selling categories"
        );

        header.add(sectionTitle, BorderLayout.WEST);
        return header;
    }

    private JPanel buildMainCard() {
        JPanel outer = new RoundedPanel(30, new Color(8, 4, 3, 195));
        outer.setLayout(new BorderLayout());
        outer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(212, 175, 55, 70), 1, true),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)
        ));

        JPanel inner = new RoundedPanel(24, CARD_BG);
        inner.setLayout(new BorderLayout());
        inner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 18), 1, true),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)
        ));

        inner.add(buildTabsArea(), BorderLayout.CENTER);
        outer.add(inner, BorderLayout.CENTER);

        return outer;
    }

    private JPanel buildTabsArea() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        styleTabbedPaneUI();

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("SansSerif", Font.BOLD, 16));
        tabs.setBackground(new Color(0, 0, 0, 0));
        tabs.setForeground(TEXT_SECONDARY);
        tabs.setOpaque(false);
        tabs.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        tabs.addTab("Sales Report", buildSalesTab());
        tabs.addTab("Inventory Report", buildInventoryTab());
        tabs.addTab("Top Categories", buildTopCategoryTab());

        wrapper.add(tabs, BorderLayout.CENTER);
        return wrapper;
    }

    private void styleTabbedPaneUI() {
        UIManager.put("TabbedPane.contentOpaque", false);
        UIManager.put("TabbedPane.tabsOpaque", false);
        UIManager.put("TabbedPane.selected", new Color(36, 19, 11));
        UIManager.put("TabbedPane.background", new Color(0, 0, 0, 0));
        UIManager.put("TabbedPane.foreground", TEXT_SECONDARY);
        UIManager.put("TabbedPane.light", new Color(0, 0, 0, 0));
        UIManager.put("TabbedPane.highlight", new Color(0, 0, 0, 0));
        UIManager.put("TabbedPane.shadow", new Color(0, 0, 0, 0));
        UIManager.put("TabbedPane.darkShadow", new Color(0, 0, 0, 0));
        UIManager.put("TabbedPane.focus", new Color(0, 0, 0, 0));
        UIManager.put("TabbedPane.contentBorderInsets", new Insets(10, 0, 0, 0));
        UIManager.put("TabbedPane.tabInsets", new Insets(10, 18, 10, 18));
        UIManager.put("TabbedPane.selectedTabPadInsets", new Insets(0, 0, 0, 0));
    }

    private JPanel buildSalesTab() {
        JPanel content = createLuxuryContentCard();

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

        JPanel filterCard = createInnerCard();
        filterCard.setLayout(new BorderLayout(0, 12));

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 6));
        filterRow.setOpaque(false);

        JLabel fromLabel = createFieldLabel("From Date");
        JLabel toLabel = createFieldLabel("To Date");

        fromDateField = createLuxuryField("YYYY-MM-DD");
        toDateField = createLuxuryField("YYYY-MM-DD");

        JButton loadButton = createAccentButton("Load Sales Report");
        loadButton.addActionListener(e -> loadSalesReport());

        filterRow.add(fromLabel);
        filterRow.add(fromDateField);
        filterRow.add(Box.createHorizontalStrut(8));
        filterRow.add(toLabel);
        filterRow.add(toDateField);
        filterRow.add(Box.createHorizontalStrut(10));
        filterRow.add(loadButton);

        JPanel helperRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        helperRow.setOpaque(false);

        JLabel helperText = new JLabel("Tip: enter both dates in YYYY-MM-DD format to load invoice activity");
        helperText.setForeground(TEXT_MUTED);
        helperText.setFont(new Font("SansSerif", Font.PLAIN, 13));
        helperRow.add(helperText);

        filterCard.add(filterRow, BorderLayout.NORTH);
        filterCard.add(helperRow, BorderLayout.SOUTH);

        top.add(filterCard);
        top.add(Box.createVerticalStrut(14));
        top.add(createStatsStrip("Total Invoices", true));
        top.add(Box.createVerticalStrut(10));
        salesHintLabel = createHintLabel("Load a date range to review invoices and payment status.");
        top.add(salesHintLabel);

        salesTableModel = new DefaultTableModel(
                new Object[]{"Invoice ID", "Invoice Date", "Customer", "Employee", "Total Amount", "Status"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        salesTable = createStyledTable(salesTableModel);
        configureSalesTableColumns();

        JScrollPane scrollPane = createLuxuryScrollPane(salesTable);

        content.add(top, BorderLayout.NORTH);
        content.add(scrollPane, BorderLayout.CENTER);

        return content;
    }

    private JPanel buildInventoryTab() {
        JPanel content = createLuxuryContentCard();

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.add(createStatsStrip("Inventory Records", false));
        top.add(Box.createVerticalStrut(10));
        inventoryHintLabel = createHintLabel("This report shows the current inventory snapshot.");
        top.add(inventoryHintLabel);

        inventoryTableModel = new DefaultTableModel(
                new Object[]{"Inventory ID", "Item Name", "Serial No", "Category", "Quantity"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        inventoryTable = createStyledTable(inventoryTableModel);
        configureInventoryTableColumns();

        JScrollPane scrollPane = createLuxuryScrollPane(inventoryTable);

        content.add(top, BorderLayout.NORTH);
        content.add(scrollPane, BorderLayout.CENTER);

        return content;
    }

    private JPanel buildTopCategoryTab() {
        JPanel content = createLuxuryContentCard();

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.add(createStatsStrip("Top Categories", false));
        top.add(Box.createVerticalStrut(10));
        topCategoryHintLabel = createHintLabel("Use this tab to compare the strongest selling categories.");
        top.add(topCategoryHintLabel);

        topCategoryTableModel = new DefaultTableModel(
                new Object[]{"Category", "Sold Count", "Total Sales"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        topCategoryTable = createStyledTable(topCategoryTableModel);
        configureTopCategoryTableColumns();

        JScrollPane scrollPane = createLuxuryScrollPane(topCategoryTable);

        content.add(top, BorderLayout.NORTH);
        content.add(scrollPane, BorderLayout.CENTER);

        return content;
    }

    private JPanel createLuxuryContentCard() {
        JPanel panel = new RoundedPanel(24, CARD_INNER);
        panel.setLayout(new BorderLayout(14, 14));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(212, 175, 55, 55), 1, true),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)
        ));
        return panel;
    }

    private JPanel createInnerCard() {
        JPanel panel = new RoundedPanel(22, new Color(28, 15, 9, 220));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 22), 1, true),
                BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));
        return panel;
    }

    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT_SECONDARY);
        label.setFont(new Font("SansSerif", Font.BOLD, 14));
        return label;
    }

    private JLabel createHintLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT_MUTED);
        label.setFont(new Font("SansSerif", Font.PLAIN, 13));
        return label;
    }

    private JTextField createLuxuryField(String hintText) {
        JTextField field = new JTextField(12);
        field.setText("");
        field.setPreferredSize(new Dimension(150, 40));
        field.setBackground(FIELD_BG);
        field.setForeground(TEXT_PRIMARY);
        field.setCaretColor(LIGHT_GOLD);
        field.setFont(new Font("SansSerif", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(212, 175, 55, 55), 1, true),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        return field;
    }

    private JButton createAccentButton(String text) {
        JButton button = new PrimaryButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(190, 42));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
        return button;
    }

    private JPanel createStatsStrip(String title, boolean salesTab) {
        JPanel strip = new RoundedPanel(20, new Color(24, 13, 8, 230));
        strip.setLayout(new BorderLayout());
        strip.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(212, 175, 55, 45), 1, true),
                BorderFactory.createEmptyBorder(14, 18, 14, 18)
        ));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        left.setOpaque(false);

        JLabel titleLabel = new JLabel(title + "  ");
        titleLabel.setForeground(TEXT_SECONDARY);
        titleLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));

        JLabel valueLabel = new JLabel("0");
        valueLabel.setForeground(LIGHT_GOLD);
        valueLabel.setFont(new Font("SansSerif", Font.BOLD, 28));

        left.add(titleLabel);
        left.add(valueLabel);

        JLabel rightHint = new JLabel(salesTab ? "Filtered summary" : "Live overview");
        rightHint.setForeground(TEXT_MUTED);
        rightHint.setFont(new Font("SansSerif", Font.PLAIN, 13));

        strip.add(left, BorderLayout.WEST);
        strip.add(rightHint, BorderLayout.EAST);

        if (salesTab) {
            salesSummaryLabel = valueLabel;
        } else if (inventorySummaryLabel == null) {
            inventorySummaryLabel = valueLabel;
        } else {
            topCategorySummaryLabel = valueLabel;
        }

        return strip;
    }

    private ModernTable createStyledTable(DefaultTableModel model) {
        ModernTable table = new ModernTable();
        table.setModel(model);
        table.setRowHeight(38);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.setForeground(TEXT_PRIMARY);
        table.setBackground(TABLE_BG);
        table.setSelectionForeground(TEXT_PRIMARY);
        table.setSelectionBackground(new Color(95, 62, 20));
        table.setGridColor(new Color(212, 175, 55, 20));
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setFillsViewportHeight(true);
        table.setBorder(BorderFactory.createEmptyBorder());

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);

        DefaultTableCellRenderer left = new DefaultTableCellRenderer();
        left.setHorizontalAlignment(SwingConstants.LEFT);

        for (int i = 0; i < model.getColumnCount(); i++) {
            if (i == 0 || i == model.getColumnCount() - 1) {
                table.getColumnModel().getColumn(i).setCellRenderer(center);
            } else {
                table.getColumnModel().getColumn(i).setCellRenderer(left);
            }
        }

        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(header.getWidth(), 42));
        header.setReorderingAllowed(false);
        header.setResizingAllowed(true);
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        header.setForeground(TABLE_HEADER_TEXT);
        header.setBackground(TABLE_HEADER_BG);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(140, 111, 38)));

        return table;
    }

    private JScrollPane createLuxuryScrollPane(javax.swing.JTable table) {
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(true);
        scrollPane.getViewport().setBackground(TABLE_BG);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 18), 1, true),
                BorderFactory.createEmptyBorder(0, 0, 0, 0)
        ));
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        scrollPane.getHorizontalScrollBar().setUnitIncrement(14);
        return scrollPane;
    }

    private void configureSalesTableColumns() {
        salesTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        salesTable.getColumnModel().getColumn(0).setPreferredWidth(120);
        salesTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        salesTable.getColumnModel().getColumn(2).setPreferredWidth(220);
        salesTable.getColumnModel().getColumn(3).setPreferredWidth(220);
        salesTable.getColumnModel().getColumn(4).setPreferredWidth(170);
        salesTable.getColumnModel().getColumn(5).setPreferredWidth(120);
    }

    private void configureInventoryTableColumns() {
        inventoryTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        inventoryTable.getColumnModel().getColumn(0).setPreferredWidth(130);
        inventoryTable.getColumnModel().getColumn(1).setPreferredWidth(280);
        inventoryTable.getColumnModel().getColumn(2).setPreferredWidth(180);
        inventoryTable.getColumnModel().getColumn(3).setPreferredWidth(180);
        inventoryTable.getColumnModel().getColumn(4).setPreferredWidth(120);
    }

    private void configureTopCategoryTableColumns() {
        topCategoryTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        topCategoryTable.getColumnModel().getColumn(0).setPreferredWidth(260);
        topCategoryTable.getColumnModel().getColumn(1).setPreferredWidth(180);
        topCategoryTable.getColumnModel().getColumn(2).setPreferredWidth(200);
    }

    private void loadSalesReport() {
        try {
            String fromDate = fromDateField.getText().trim();
            String toDate = toDateField.getText().trim();
            validateSalesDateRange(fromDate, toDate);

            List<SalesReportRow> rows = reportService.getSalesReport(
                    fromDate,
                    toDate
            );

            salesTableModel.setRowCount(0);

            for (SalesReportRow row : rows) {
                salesTableModel.addRow(new Object[]{
                        row.getInvoiceId(),
                        row.getInvoiceDate(),
                        row.getCustomerName(),
                        row.getEmployeeName(),
                        row.getTotalAmount(),
                        row.getStatus()
                });
            }

            salesSummaryLabel.setText(String.valueOf(rows.size()));
            salesHintLabel.setText(rows.isEmpty()
                    ? "No sales invoices were found for the selected period."
                    : "Showing " + rows.size() + " invoice record(s) for the selected period.");

        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void loadInventoryReport() {
        try {
            List<InventoryReportRow> rows = reportService.getInventoryReport();

            inventoryTableModel.setRowCount(0);

            for (InventoryReportRow row : rows) {
                inventoryTableModel.addRow(new Object[]{
                        row.getInventoryId(),
                        row.getItemName(),
                        row.getSerialNo(),
                        row.getCategoryName(),
                        row.getQty()
                });
            }

            inventorySummaryLabel.setText(String.valueOf(rows.size()));
            inventoryHintLabel.setText(rows.isEmpty()
                    ? "No inventory report rows are available right now."
                    : "Showing " + rows.size() + " inventory record(s).");

        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void loadTopCategoryReport() {
        try {
            List<TopCategoryReportRow> rows = reportService.getTopCategoryReport();

            topCategoryTableModel.setRowCount(0);

            for (TopCategoryReportRow row : rows) {
                topCategoryTableModel.addRow(new Object[]{
                        row.getCategoryName(),
                        row.getSoldCount(),
                        row.getTotalSales()
                });
            }

            topCategorySummaryLabel.setText(String.valueOf(rows.size()));
            topCategoryHintLabel.setText(rows.isEmpty()
                    ? "No sold categories are available yet."
                    : "Showing " + rows.size() + " category performance row(s).");

        } catch (Exception e) {
            MessageUtil.showError(this, e.getMessage());
        }
    }

    private void validateSalesDateRange(String fromDate, String toDate) {
        if (fromDate.isEmpty() || toDate.isEmpty()) {
            throw new IllegalArgumentException("Please enter both From Date and To Date before loading the sales report.");
        }
        if (!fromDate.matches("\\d{4}-\\d{2}-\\d{2}") || !toDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new IllegalArgumentException("Dates must use the format YYYY-MM-DD.");
        }
    }

    private static class RoundedPanel extends JPanel {
        private final int radius;
        private final Color backgroundColor;

        public RoundedPanel(int radius, Color backgroundColor) {
            this.radius = radius;
            this.backgroundColor = backgroundColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            g2.setColor(backgroundColor);
            g2.fillRoundRect(0, 0, w - 1, h - 1, radius, radius);

            g2.setColor(new Color(255, 255, 255, 12));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0, 0, w - 1, h - 1, radius, radius);

            g2.setColor(ACCENT_LINE);
            g2.drawRoundRect(1, 1, w - 3, h - 3, radius, radius);

            g2.dispose();
            super.paintComponent(g);
        }
    }
}
