package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.FlowLayout;

public class SearchPanel extends JPanel {

    private final JTextField searchField;
    private final javax.swing.JButton searchButton;
    private final SecondaryButton refreshButton;

    public SearchPanel() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 0));
        setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        searchField = new JTextField(20);
        UIStyle.styleField(searchField);
        searchField.setPreferredSize(new Dimension(240, 40));

        searchButton = new javax.swing.JButton("Search");
        refreshButton = new SecondaryButton("Refresh");

        UIStyle.styleGoldButton(searchButton);

        add(searchField);
        add(searchButton);
        add(refreshButton);
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public javax.swing.JButton getSearchButton() {
        return searchButton;
    }

    public SecondaryButton getRefreshButton() {
        return refreshButton;
    }

    public String getSearchText() {
        return searchField.getText().trim();
    }
}
