package com.tajstore.service;

import com.tajstore.dao.SupplierDao;
import com.tajstore.model.Supplier;

import java.util.List;

public class SupplierService {

    private final SupplierDao supplierDao;

    public SupplierService() {
        this.supplierDao = new SupplierDao();
    }

    public List<Supplier> getAllSuppliers() {
        return supplierDao.findAll();
    }

    public List<Supplier> searchSuppliers(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllSuppliers();
        }

        String normalized = keyword.trim().replaceAll("\\s+", "");
        return supplierDao.search(normalized);
    }

    public int addSupplier(String supplierName, String phone, String address) {
        validateSupplier(supplierName, phone, address, 0, false);

        Supplier supplier = new Supplier();
        supplier.setSupplierName(supplierName.trim());
        supplier.setPhone(normalize(phone));
        supplier.setAddress(normalize(address));

        return supplierDao.insert(supplier);
    }

    public void updateSupplier(int supplierId, String supplierName, String phone, String address) {
        validateSupplier(supplierName, phone, address, supplierId, true);

        Supplier supplier = new Supplier();
        supplier.setSupplierId(supplierId);
        supplier.setSupplierName(supplierName.trim());
        supplier.setPhone(normalize(phone));
        supplier.setAddress(normalize(address));

        supplierDao.update(supplier);
    }

    public void deleteSupplier(int supplierId) {
        supplierDao.delete(supplierId);
    }

    private void validateSupplier(String supplierName, String phone, String address, int supplierId, boolean isUpdate) {
        if (supplierName == null || supplierName.trim().isEmpty()) {
            throw new IllegalArgumentException("Supplier name is required.");
        }

        if (supplierName.trim().length() < 3) {
            throw new IllegalArgumentException("Supplier name must be at least 3 characters.");
        }

        if (phone != null && !phone.trim().isEmpty()) {
            String normalizedPhone = phone.trim();

            if (!normalizedPhone.matches("[0-9+\\- ]{7,20}")) {
                throw new IllegalArgumentException("Phone number format is invalid.");
            }

            if (supplierDao.existsByPhoneExcludingId(normalizedPhone, isUpdate ? supplierId : 0)) {
                throw new IllegalArgumentException("Phone number already exists.");
            }
        }

        if (address != null && address.trim().length() > 200) {
            throw new IllegalArgumentException("Address is too long.");
        }
    }

    private String normalize(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }
}