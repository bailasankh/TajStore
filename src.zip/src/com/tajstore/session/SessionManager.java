package com.tajstore.session;

public final class SessionManager {

    private static CurrentSession currentSession;

    private SessionManager() {
    }

    public static void startSession(CurrentSession session) {
        currentSession = session;
    }

    public static CurrentSession getCurrentSession() {
        return currentSession;
    }

    public static boolean isLoggedIn() {
        return currentSession != null;
    }

    public static void clearSession() {
        currentSession = null;
    }

    public static String getCurrentRole() {
        return currentSession != null ? currentSession.getRoleName() : null;
    }

    public static String getCurrentFullName() {
        return currentSession != null ? currentSession.getFullName() : null;
    }

    public static int getCurrentUserId() {
        return currentSession != null ? currentSession.getUserId() : -1;
    }
}