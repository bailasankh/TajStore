package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class PurchaseDao {

    public int createPurchase(
            int supplierId,
            int employeeId,
            int itemId,
            int quantity,
            BigDecimal pricePerUnit,
            BigDecimal subtotal
    ) {
        Connection connection = null;

        try {
            connection = ConnectionManager.getConnection();
            connection.setAutoCommit(false);

            int purchaseId = insertPurchaseOrder(connection, supplierId, employeeId, subtotal);
            insertPurchaseDetail(connection, purchaseId, itemId, quantity, pricePerUnit, subtotal);
            increaseInventory(connection, itemId, quantity);
            insertInventoryMovement(connection, itemId, purchaseId);

            connection.commit();
            return purchaseId;

        } catch (Exception e) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (Exception ignored) {
                }
            }
            throw new RuntimeException("Failed to create purchase transaction.", e);
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(true);
                    connection.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private int insertPurchaseOrder(Connection connection, int supplierId, int employeeId, BigDecimal totalAmount) throws Exception {
        String sql = "INSERT INTO purchase_order (supplier_id, employee_id, purchase_date, total_amount) VALUES (?, ?, CURRENT_DATE, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, supplierId);
            statement.setInt(2, employeeId);
            statement.setBigDecimal(3, totalAmount);

            statement.executeUpdate();

            try (ResultSet rs = statement.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        throw new RuntimeException("Failed to create purchase order.");
    }

    private void insertPurchaseDetail(Connection connection, int purchaseId, int itemId, int quantity,
                                      BigDecimal pricePerUnit, BigDecimal subtotal) throws Exception {
        String sql = "INSERT INTO purchase_details (purchase_id, item_id, quantity, price_per_unit, subtotal) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, purchaseId);
            statement.setInt(2, itemId);
            statement.setInt(3, quantity);
            statement.setBigDecimal(4, pricePerUnit);
            statement.setBigDecimal(5, subtotal);
            statement.executeUpdate();
        }
    }

    private void increaseInventory(Connection connection, int itemId, int quantity) throws Exception {
        String checkSql = "SELECT qty FROM inventory WHERE item_id = ?";
        boolean exists = false;

        try (PreparedStatement check = connection.prepareStatement(checkSql)) {
            check.setInt(1, itemId);

            try (ResultSet rs = check.executeQuery()) {
                if (rs.next()) {
                    exists = true;
                }
            }
        }

        if (exists) {
            String updateSql = "UPDATE inventory SET qty = qty + ? WHERE item_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(updateSql)) {
                statement.setInt(1, quantity);
                statement.setInt(2, itemId);
                statement.executeUpdate();
            }
        } else {
            String insertSql = "INSERT INTO inventory (item_id, qty) VALUES (?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(insertSql)) {
                statement.setInt(1, itemId);
                statement.setInt(2, quantity);
                statement.executeUpdate();
            }
        }
    }

    private void insertInventoryMovement(Connection connection, int itemId, int purchaseId) throws Exception {
        String sql = "INSERT INTO inventory_movement (item_id, move_type, ref_po_id, note) VALUES (?, 'IN', ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, itemId);
            statement.setInt(2, purchaseId);
            statement.setString(3, "Purchased from supplier");
            statement.executeUpdate();
        }
    }
}