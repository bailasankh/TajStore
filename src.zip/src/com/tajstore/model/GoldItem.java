package com.tajstore.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class GoldItem {

    private int itemId;
    private String itemName;
    private String serialNo;
    private int categoryId;
    private String categoryName;
    private BigDecimal weightGram;
    private int karat;
    private BigDecimal makingCost;
    private String imagePath;
    private boolean active;
    private LocalDateTime createdAt;

    public GoldItem() {
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getWeightGram() {
        return weightGram;
    }

    public void setWeightGram(BigDecimal weightGram) {
        this.weightGram = weightGram;
    }

    public int getKarat() {
        return karat;
    }

    public void setKarat(int karat) {
        this.karat = karat;
    }

    public BigDecimal getMakingCost() {
        return makingCost;
    }

    public void setMakingCost(BigDecimal makingCost) {
        this.makingCost = makingCost;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
