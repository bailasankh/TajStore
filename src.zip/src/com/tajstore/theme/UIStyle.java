package com.tajstore.theme;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public final class UIStyle {

    private UIStyle() {
    }

    public static final Font FONT_TITLE = new Font("SansSerif", Font.BOLD, 24);
    public static final Font FONT_SUBTITLE = new Font("SansSerif", Font.PLAIN, 16);
    public static final Font FONT_HEADING = new Font("SansSerif", Font.BOLD, 18);
    public static final Font FONT_BODY = new Font("SansSerif", Font.PLAIN, 14);
    public static final Font FONT_SMALL = new Font("SansSerif", Font.PLAIN, 12);

    public static Border createPadding(int top, int left, int bottom, int right) {
        return BorderFactory.createEmptyBorder(top, left, bottom, right);
    }

    public static Border createLineBorder() {
        return BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1);
    }

    public static Border createRoundedLineBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1, true),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
        );
    }

    public static Border createCardBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1, true),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
        );
    }

    private static void prepareButton(JButton button) {
        button.setFocusPainted(false);
        button.setFont(FONT_BODY);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setMargin(new Insets(10, 18, 10, 18));
        button.setMinimumSize(new Dimension(110, 40));
        button.setPreferredSize(new Dimension(
                Math.max(button.getPreferredSize().width + 8, 110), 40
        ));
    }

    public static void stylePrimaryButton(JButton button) {
        prepareButton(button);
        button.setBackground(ThemeManager.getTheme().getPrimary());
        button.setForeground(ColorPalette.BUTTON_TEXT_ON_GOLD);
        button.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
    }

    public static void styleSecondaryButton(JButton button) {
        prepareButton(button);
        if (ThemeManager.isDarkMode()) {
            button.setBackground(new Color(245, 241, 234));
            button.setForeground(ColorPalette.BUTTON_TEXT_ON_LIGHT);
        } else {
            button.setBackground(ThemeManager.getTheme().getSurfaceAlt());
            button.setForeground(ThemeManager.getTheme().getText());
        }
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1, true),
                BorderFactory.createEmptyBorder(9, 17, 9, 17)
        ));
        button.setBorderPainted(true);
    }

    public static void styleGoldButton(JButton button) {
        stylePrimaryButton(button);
    }

    public static void styleDangerButton(JButton button) {
        prepareButton(button);
        button.setBackground(ThemeManager.getTheme().getDanger());
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
    }

    public static void styleField(JComponent component) {
        component.setFont(FONT_BODY);
        component.setBackground(ThemeManager.getTheme().getSurface());
        component.setForeground(ThemeManager.getTheme().getText());
        component.setBorder(createRoundedLineBorder());

        if (component instanceof JTextField) {
            JTextField field = (JTextField) component;
            field.setCaretColor(ThemeManager.getTheme().getPrimaryDark());
            field.setPreferredSize(new Dimension(Math.max(field.getPreferredSize().width, 180), 40));
        }

        if (component instanceof JTextArea) {
            ((JTextArea) component).setCaretColor(ThemeManager.getTheme().getPrimaryDark());
        }

        if (component instanceof JComboBox) {
            JComboBox<?> comboBox = (JComboBox<?>) component;
            comboBox.setPreferredSize(new Dimension(Math.max(comboBox.getPreferredSize().width, 160), 40));
            if (ThemeManager.isDarkMode()) {
                comboBox.setBackground(new Color(245, 241, 234));
                comboBox.setForeground(ColorPalette.BUTTON_TEXT_ON_LIGHT);
            } else {
                comboBox.setBackground(ThemeManager.getTheme().getSurface());
                comboBox.setForeground(ThemeManager.getTheme().getText());
            }

            comboBox.setRenderer(new javax.swing.DefaultListCellRenderer() {
                @Override
                public java.awt.Component getListCellRendererComponent(
                        javax.swing.JList<?> list,
                        Object value,
                        int index,
                        boolean isSelected,
                        boolean cellHasFocus) {

                    java.awt.Component c = super.getListCellRendererComponent(
                            list, value, index, isSelected, cellHasFocus
                    );

                    if (isSelected) {
                        c.setBackground(ThemeManager.getTheme().getPrimary());
                        c.setForeground(ColorPalette.BUTTON_TEXT_ON_GOLD);
                    } else {
                        if (ThemeManager.isDarkMode()) {
                            c.setBackground(new Color(245, 241, 234));
                            c.setForeground(ColorPalette.BUTTON_TEXT_ON_LIGHT);
                        } else {
                            c.setBackground(ThemeManager.getTheme().getSurface());
                            c.setForeground(ThemeManager.getTheme().getText());
                        }
                    }

                    return c;
                }
            });
        }
    }
}
