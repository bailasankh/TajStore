package com.tajstore.config;

public final class Routes {

    private Routes() {
    }

    public static final String DASHBOARD = "dashboard";
    public static final String CUSTOMERS = "customers";
    public static final String SUPPLIERS = "suppliers";
    public static final String ITEMS = "items";
    public static final String INVENTORY = "inventory";
    public static final String INVENTORY_MOVEMENTS = "inventory_movements";
    public static final String SALES = "sales";
    public static final String INVOICE_HISTORY = "invoice_history";
    public static final String PURCHASES = "purchases";
    public static final String REPORTS = "reports";
    public static final String GOLD_PRICES = "gold_prices";
}