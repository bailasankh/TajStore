package com.tajstore.ui.components;

import com.tajstore.config.Routes;
import com.tajstore.security.AuthorizationService;
import com.tajstore.security.Permission;
import com.tajstore.session.SessionManager;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

public class Sidebar extends JPanel {

    private final Consumer<String> navigationHandler;
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();
    private String activeRoute;

    public Sidebar(Consumer<String> navigationHandler) {
        this.navigationHandler = navigationHandler;
        initUI();
    }

    private void initUI() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(250, 0));
        setOpaque(true);
        setBackground(ThemeManager.getTheme().getSurfaceAlt());
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 0, 1, ThemeManager.getTheme().getBorder()),
                BorderFactory.createEmptyBorder(18, 16, 18, 16)
        ));

        add(buildBrandCard());
        add(Box.createVerticalStrut(22));
        add(buildSectionLabel("MAIN NAVIGATION"));
        add(Box.createVerticalStrut(10));

        addNavIfAllowed("Dashboard", Routes.DASHBOARD, Permission.VIEW_DASHBOARD);
        addNavIfAllowed("Customers", Routes.CUSTOMERS, Permission.MANAGE_CUSTOMERS);
        addNavIfAllowed("Suppliers", Routes.SUPPLIERS, Permission.MANAGE_SUPPLIERS);
        addNavIfAllowed("Gold Items", Routes.ITEMS, Permission.MANAGE_ITEMS);
        addNavIfAllowed("Inventory", Routes.INVENTORY, Permission.VIEW_INVENTORY);
        addNavIfAllowed("Stock Movements", Routes.INVENTORY_MOVEMENTS, Permission.VIEW_INVENTORY);
        addNavIfAllowed("Sales", Routes.SALES, Permission.MANAGE_SALES);
        addNavIfAllowed("Invoice History", Routes.INVOICE_HISTORY, Permission.MANAGE_SALES);
        addNavIfAllowed("Purchases", Routes.PURCHASES, Permission.MANAGE_PURCHASES);
        addNavIfAllowed("Gold Prices", Routes.GOLD_PRICES, Permission.VIEW_REPORTS);
        addNavIfAllowed("Reports", Routes.REPORTS, Permission.VIEW_REPORTS);

        add(Box.createVerticalGlue());
        add(buildFooterCard());
    }

    private JPanel buildBrandCard() {
        JPanel card = createLuxuryCard();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 94));
        card.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel title = new JLabel("TAJ STORE");
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        title.setFont(UIStyle.FONT_TITLE);
        title.setForeground(new Color(224, 190, 78));

        JLabel subtitle = new JLabel("Luxury Gold Management");
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        subtitle.setFont(UIStyle.FONT_SMALL);
        subtitle.setForeground(ThemeManager.getTheme().getTextMuted());

        card.add(title);
        card.add(Box.createVerticalStrut(6));
        card.add(subtitle);

        return card;
    }

    private JLabel buildSectionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setFont(UIStyle.FONT_SMALL);
        label.setForeground(ThemeManager.getTheme().getTextMuted());
        return label;
    }

    private JPanel buildFooterCard() {
        JPanel card = createLuxuryCard();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 88));
        card.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        String fullName = SessionManager.getCurrentFullName() != null
                ? SessionManager.getCurrentFullName()
                : "User";

        String role = SessionManager.getCurrentRole() != null
                ? SessionManager.getCurrentRole()
                : "Unknown";

        JLabel userLabel = new JLabel(fullName);
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        userLabel.setFont(UIStyle.FONT_BODY);
        userLabel.setForeground(ThemeManager.getTheme().getText());

        JLabel roleLabel = new JLabel(role);
        roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        roleLabel.setFont(UIStyle.FONT_SMALL);
        roleLabel.setForeground(new Color(224, 190, 78));

        card.add(userLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(roleLabel);

        return card;
    }

    private void addNavIfAllowed(String title, String route, Permission permission) {
        if (!AuthorizationService.hasPermission(permission)) {
            return;
        }

        JButton button = createNavButton(title, route);
        navButtons.put(route, button);
        add(button);
        add(Box.createVerticalStrut(8));
    }

    private JButton createNavButton(String title, String route) {
        JButton button = new JButton(title);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        button.setFocusPainted(false);
        button.setFont(UIStyle.FONT_BODY);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(11, 14, 11, 14));

        setButtonNormalStyle(button);

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (!route.equals(activeRoute)) {
                    button.setBackground(ThemeManager.getTheme().getPrimaryDark());
                    button.setForeground(ThemeManager.getTheme().getSurface());
                }
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (!route.equals(activeRoute)) {
                    setButtonNormalStyle(button);
                }
            }
        });

        button.addActionListener(e -> {
            setActiveRoute(route);
            navigationHandler.accept(route);
        });

        return button;
    }

    private void setButtonNormalStyle(JButton button) {
        button.setBackground(ThemeManager.getTheme().getSurface());
        button.setForeground(ThemeManager.getTheme().getText());
        button.setBorder(BorderFactory.createEmptyBorder(11, 14, 11, 14));
    }

    public void setActiveRoute(String activeRoute) {
        this.activeRoute = activeRoute;

        for (Map.Entry<String, JButton> entry : navButtons.entrySet()) {
            boolean isActive = entry.getKey().equals(activeRoute);
            JButton button = entry.getValue();

            if (isActive) {
                button.setBackground(ThemeManager.getTheme().getPrimary());
                button.setForeground(new Color(40, 28, 12));
                button.setBorder(BorderFactory.createEmptyBorder(11, 15, 11, 15));
            } else {
                setButtonNormalStyle(button);
            }
        }
    }

    private JPanel createLuxuryCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(ThemeManager.getTheme().getSurface());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);

                g2.setColor(ThemeManager.getTheme().getBorder());
                g2.setStroke(new BasicStroke(1.1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);

                g2.setColor(ThemeManager.isDarkMode() ? new Color(255, 220, 150, 18) : new Color(201, 162, 39, 60));
                g2.drawRoundRect(7, 7, getWidth() - 15, getHeight() - 15, 14, 14);

                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        return card;
    }
}
