package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.Role;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RoleDao {

    private static final String FIND_ALL_SQL =
            "SELECT role_id, role_name FROM role ORDER BY role_name";

    private static final String FIND_BY_ID_SQL =
            "SELECT role_id, role_name FROM role WHERE role_id = ?";

    private static final String FIND_BY_NAME_SQL =
            "SELECT role_id, role_name FROM role WHERE role_name = ?";

    public List<Role> findAll() {
        List<Role> roles = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                roles.add(mapRow(rs));
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to load roles.", e);
        }

        return roles;
    }

    public Role findById(int roleId) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_BY_ID_SQL)) {

            statement.setInt(1, roleId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to find role by id.", e);
        }

        return null;
    }

    public Role findByName(String roleName) {
        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_BY_NAME_SQL)) {

            statement.setString(1, roleName);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to find role by name.", e);
        }

        return null;
    }

    private Role mapRow(ResultSet rs) throws Exception {
        Role role = new Role();
        role.setRoleId(rs.getInt("role_id"));
        role.setRoleName(rs.getString("role_name"));
        return role;
    }
}