package com.tajstore.ui1;

import com.tajstore.config.Routes;
import com.tajstore.session.SessionManager;
import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;
import com.tajstore.ui.components.BaseFrame;
import com.tajstore.ui.components.Sidebar;
import com.tajstore.ui.components.TopBar;
import com.tajstore.ui.dashboard.DashboardPanel;
import com.tajstore.util.NotificationUtil;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class MainFrame extends BaseFrame {

    private Sidebar sidebar;
    private TopBar topBar;
    private JPanel contentPanel;
    private CardLayout cardLayout;
    private JLabel statusLabel;

    public MainFrame() {
        super("Taj Store - Main System", 1400, 850);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
        initUI();
        startFadeIn();
    }

    @Override
    protected void initUI() {
        JPanel root = new JPanel(new BorderLayout()) {
            private final java.net.URL bgUrl = getClass().getResource("/com/tajstore/assets/background.png");
            private final Image bg = bgUrl != null ? new ImageIcon(bgUrl).getImage() : null;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                if (bg != null) {
                    g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g.setColor(ThemeManager.getTheme().getBackground());
                    g.fillRect(0, 0, getWidth(), getHeight());
                }

                Color overlay = ThemeManager.isDarkMode()
                        ? new Color(0, 0, 0, 120)
                        : new Color(255, 255, 255, 70);
                g.setColor(overlay);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        root.setOpaque(false);

        sidebar = new Sidebar(this::showRoute);
        topBar = new TopBar(this::toggleTheme);

        JPanel centerWrapper = new JPanel(new BorderLayout(0, 14));
        centerWrapper.setOpaque(false);
        centerWrapper.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));

        centerWrapper.add(topBar, BorderLayout.NORTH);
        centerWrapper.add(buildContentShell(), BorderLayout.CENTER);
        centerWrapper.add(buildFooterBar(), BorderLayout.SOUTH);

        root.add(sidebar, BorderLayout.WEST);
        root.add(centerWrapper, BorderLayout.CENTER);

        setContentPane(root);
        showRoute(Routes.DASHBOARD, false);
    }

    private JPanel buildContentShell() {
        JPanel shell = new JPanel(new BorderLayout());
        shell.setOpaque(true);
        shell.setBackground(ThemeManager.getTheme().getSurface());
        shell.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1, true),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(true);
        contentPanel.setBackground(ThemeManager.getTheme().getBackground());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        registerScreens();

        shell.add(contentPanel, BorderLayout.CENTER);
        return shell;
    }

    private JPanel buildFooterBar() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(ThemeManager.getTheme().getSurface());
        footer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1, true),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)
        ));

        JPanel leftPanel = new JPanel();
        leftPanel.setOpaque(false);
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.X_AXIS));

        String fullName = SessionManager.getCurrentFullName() != null
                ? SessionManager.getCurrentFullName()
                : "User";

        String role = SessionManager.getCurrentRole() != null
                ? SessionManager.getCurrentRole()
                : "Unknown";

        JLabel sessionLabel = new JLabel("Signed in as: " + fullName + " (" + role + ")");
        sessionLabel.setFont(UIStyle.FONT_SMALL);
        sessionLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        leftPanel.add(sessionLabel);
        leftPanel.add(Box.createHorizontalStrut(20));

        statusLabel = new JLabel("Ready");
        statusLabel.setFont(UIStyle.FONT_SMALL);
        statusLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightPanel.setOpaque(false);

        JLabel appLabel = new JLabel("Taj Store Management System");
        appLabel.setFont(UIStyle.FONT_SMALL);
        appLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        rightPanel.add(appLabel);

        footer.add(leftPanel, BorderLayout.WEST);
        footer.add(statusLabel, BorderLayout.CENTER);
        footer.add(rightPanel, BorderLayout.EAST);

        return footer;
    }

    private void registerScreens() {
        contentPanel.add(new DashboardPanel(this::showRoute), Routes.DASHBOARD);
        contentPanel.add(new com.tajstore.ui.customer.CustomerPanel(), Routes.CUSTOMERS);
        contentPanel.add(new com.tajstore.ui.supplier.SupplierPanel(), Routes.SUPPLIERS);
        contentPanel.add(new com.tajstore.ui.item.GoldItemPanel(), Routes.ITEMS);
        contentPanel.add(new com.tajstore.ui.inventory.InventoryPanel(), Routes.INVENTORY);
        contentPanel.add(new com.tajstore.ui.inventory.InventoryMovementPanel(), Routes.INVENTORY_MOVEMENTS);
        contentPanel.add(new com.tajstore.ui.sales.SalesPanel(), Routes.SALES);
        contentPanel.add(new com.tajstore.ui.sales.InvoiceHistoryPanel(), Routes.INVOICE_HISTORY);
        contentPanel.add(new com.tajstore.ui.purchase.PurchasePanel(), Routes.PURCHASES);
        contentPanel.add(new com.tajstore.ui.gold.GoldPricePanel(), Routes.GOLD_PRICES);
        contentPanel.add(new com.tajstore.ui.report.ReportsPanel(), Routes.REPORTS);
    }

    private void showRoute(String route) {
        showRoute(route, true);
    }

    private void showRoute(String route, boolean showNotification) {
        if (cardLayout == null || contentPanel == null) {
            return;
        }

        cardLayout.show(contentPanel, route);

        if (sidebar != null) {
            sidebar.setActiveRoute(route);
        }

        updateStatus(route);

        if (showNotification) {
            NotificationUtil.showInfo(this, getRouteMessage(route));
        }
    }

    private void updateStatus(String route) {
        if (statusLabel == null) {
            return;
        }

        switch (route) {
            case Routes.DASHBOARD:
                statusLabel.setText("Dashboard loaded");
                break;
            case Routes.CUSTOMERS:
                statusLabel.setText("Customer records loaded");
                break;
            case Routes.SUPPLIERS:
                statusLabel.setText("Supplier records loaded");
                break;
            case Routes.ITEMS:
                statusLabel.setText("Gold item records loaded");
                break;
            case Routes.INVENTORY:
                statusLabel.setText("Inventory records loaded");
                break;
            case Routes.INVENTORY_MOVEMENTS:
                statusLabel.setText("Inventory movement history loaded");
                break;
            case Routes.SALES:
                statusLabel.setText("Sales screen ready");
                break;
            case Routes.INVOICE_HISTORY:
                statusLabel.setText("Invoice history loaded");
                break;
            case Routes.PURCHASES:
                statusLabel.setText("Purchases screen ready");
                break;
            case Routes.GOLD_PRICES:
                statusLabel.setText("Gold prices screen ready");
                break;
            case Routes.REPORTS:
                statusLabel.setText("Reports loaded");
                break;
            default:
                statusLabel.setText("Ready");
                break;
        }
    }

    private String getRouteMessage(String route) {
        switch (route) {
            case Routes.DASHBOARD:
                return "Dashboard loaded successfully.";
            case Routes.CUSTOMERS:
                return "Customers screen opened.";
            case Routes.SUPPLIERS:
                return "Suppliers screen opened.";
            case Routes.ITEMS:
                return "Gold Items screen opened.";
            case Routes.INVENTORY:
                return "Inventory screen opened.";
            case Routes.INVENTORY_MOVEMENTS:
                return "Stock Movements screen opened.";
            case Routes.SALES:
                return "Sales screen opened.";
            case Routes.INVOICE_HISTORY:
                return "Invoice History screen opened.";
            case Routes.PURCHASES:
                return "Purchases screen opened.";
            case Routes.GOLD_PRICES:
                return "Gold Prices screen opened.";
            case Routes.REPORTS:
                return "Reports screen opened.";
            default:
                return "Screen loaded.";
        }
    }

    private void toggleTheme() {
        ThemeManager.toggleTheme();
        dispose();
        MainFrame frame = new MainFrame();
        frame.setVisible(true);
        NotificationUtil.showSuccess(frame, "Theme changed successfully.");
    }

    private void startFadeIn() {
        try {
            setOpacity(0f);
        } catch (Exception e) {
            return;
        }

        Timer fadeTimer = new Timer(25, null);
        fadeTimer.addActionListener(e -> {
            float currentOpacity = getOpacity();
            float nextOpacity = currentOpacity + 0.07f;

            if (nextOpacity >= 1f) {
                setOpacity(1f);
                fadeTimer.stop();
            } else {
                setOpacity(nextOpacity);
            }
        });
        fadeTimer.start();
    }
}