package com.tajstore.service;

import com.tajstore.dao.InventoryDao;
import com.tajstore.model.Inventory;

import java.util.List;

public class InventoryService {

    private final InventoryDao inventoryDao;

    public InventoryService() {
        this.inventoryDao = new InventoryDao();
    }

    public List<Inventory> getAllInventoryRecords() {
        return inventoryDao.findAll();
    }

    public List<Inventory> searchInventory(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllInventoryRecords();
        }

        return inventoryDao.search(keyword.trim());
    }
}