package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.Category;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CategoryDao {

    private static final String FIND_ALL_SQL =
            "SELECT category_id, category_name FROM category ORDER BY category_name";

    public List<Category> findAll() {
        List<Category> categories = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                Category category = new Category();
                category.setCategoryId(rs.getInt("category_id"));
                category.setCategoryName(rs.getString("category_name"));
                categories.add(category);
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to load categories.", e);
        }

        return categories;
    }
}