package com.tajstore.dao;

import com.tajstore.db.ConnectionManager;
import com.tajstore.model.Inventory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class InventoryDao {

    private static final String FIND_ALL_SQL =
            "SELECT i.inventory_id, i.item_id, i.qty, i.last_updated, " +
            "g.item_name, g.serial_no, c.category_name " +
            "FROM inventory i " +
            "JOIN gold_item g ON i.item_id = g.item_id " +
            "JOIN category c ON g.category_id = c.category_id " +
            "ORDER BY i.inventory_id DESC";

    private static final String SEARCH_SQL =
            "SELECT i.inventory_id, i.item_id, i.qty, i.last_updated, " +
            "g.item_name, g.serial_no, c.category_name " +
            "FROM inventory i " +
            "JOIN gold_item g ON i.item_id = g.item_id " +
            "JOIN category c ON g.category_id = c.category_id " +
            "WHERE g.item_name LIKE ? OR g.serial_no LIKE ? OR c.category_name LIKE ? " +
            "ORDER BY i.inventory_id DESC";

    public List<Inventory> findAll() {
        List<Inventory> records = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(FIND_ALL_SQL);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                records.add(mapRow(rs));
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to load inventory records.", e);
        }

        return records;
    }

    public List<Inventory> search(String keyword) {
        List<Inventory> records = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_SQL)) {

            String value = "%" + keyword + "%";
            statement.setString(1, value);
            statement.setString(2, value);
            statement.setString(3, value);

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    records.add(mapRow(rs));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to search inventory records.", e);
        }

        return records;
    }

    private Inventory mapRow(ResultSet rs) throws Exception {
        Inventory inventory = new Inventory();
        inventory.setInventoryId(rs.getInt("inventory_id"));
        inventory.setItemId(rs.getInt("item_id"));
        inventory.setQty(rs.getInt("qty"));
        inventory.setItemName(rs.getString("item_name"));
        inventory.setSerialNo(rs.getString("serial_no"));
        inventory.setCategoryName(rs.getString("category_name"));

        Timestamp lastUpdated = rs.getTimestamp("last_updated");
        if (lastUpdated != null) {
            inventory.setLastUpdated(lastUpdated.toLocalDateTime());
        }

        return inventory;
    }
}