package com.tajstore.ui.components;

import com.tajstore.theme.UIStyle;
import com.tajstore.theme.ThemeManager;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

public class ModernTable extends JTable {

    public ModernTable() {
        initTable();
    }

    private void initTable() {
        setRowHeight(34);
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setFont(UIStyle.FONT_BODY);

        setBackground(tableBg());
        setForeground(tableText());
        setGridColor(gridColor());

        setSelectionBackground(selectBg());
        setSelectionForeground(selectText());

        setShowHorizontalLines(true);
        setShowVerticalLines(false);
        setIntercellSpacing(new Dimension(1, 1));
        setFillsViewportHeight(true);

        styleHeader();
        styleRows();
    }

    private void styleHeader() {
        JTableHeader header = getTableHeader();
        header.setFont(UIStyle.FONT_HEADING);
        header.setBackground(headerBg());
        header.setForeground(headerText());
        header.setOpaque(true);
        header.setReorderingAllowed(false);
        header.setResizingAllowed(true);
        header.setPreferredSize(new Dimension(header.getWidth(), 38));

        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setHorizontalAlignment(DefaultTableCellRenderer.LEFT);
        headerRenderer.setBackground(headerBg());
        headerRenderer.setForeground(headerText());
        headerRenderer.setFont(UIStyle.FONT_HEADING);
        headerRenderer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, headerBorder()),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));

        header.setDefaultRenderer(headerRenderer);
    }

    private void styleRows() {
        setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

                JLabel label = (JLabel) super.getTableCellRendererComponent(
                        table, value, isSelected, hasFocus, row, column
                );

                label.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
                label.setFont(UIStyle.FONT_BODY);

                if (isSelected) {
                    label.setBackground(selectBg());
                    label.setForeground(selectText());
                } else {
                    if (row % 2 == 0) {
                        label.setBackground(tableBg());
                    } else {
                        label.setBackground(tableAltBg());
                    }

                    if (column == 0) {
                        label.setForeground(ThemeManager.getTheme().getPrimary());
                    } else {
                        label.setForeground(tableText());
                    }
                }

                return label;
            }
        });
    }

    private Color tableBg() {
        return ThemeManager.isDarkMode() ? new Color(20, 12, 8) : ThemeManager.getTheme().getSurface();
    }

    private Color tableAltBg() {
        return ThemeManager.isDarkMode() ? new Color(28, 16, 10) : ThemeManager.getTheme().getSurfaceAlt();
    }

    private Color tableText() {
        return ThemeManager.getTheme().getText();
    }

    private Color headerBg() {
        return ThemeManager.isDarkMode() ? new Color(99, 77, 44) : new Color(234, 225, 210);
    }

    private Color headerText() {
        return ThemeManager.isDarkMode() ? new Color(246, 236, 220) : new Color(43, 33, 23);
    }

    private Color headerBorder() {
        return ThemeManager.isDarkMode() ? new Color(170, 135, 45) : ThemeManager.getTheme().getBorder();
    }

    private Color gridColor() {
        return ThemeManager.isDarkMode() ? new Color(212, 175, 55, 28) : new Color(180, 180, 180, 55);
    }

    private Color selectBg() {
        return ThemeManager.getTheme().getPrimary();
    }

    private Color selectText() {
        return new Color(35, 25, 12);
    }
}
