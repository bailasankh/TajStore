package com.tajstore.ui.components;

import com.tajstore.theme.ThemeManager;
import com.tajstore.theme.UIStyle;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Component;

public class EmptyStatePanel extends JPanel {

    public EmptyStatePanel(String title, String message) {
        setOpaque(true);
        setBackground(ThemeManager.getTheme().getSurface());
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ThemeManager.getTheme().getBorder(), 1, true),
                BorderFactory.createEmptyBorder(40, 30, 40, 30)
        ));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setFont(UIStyle.FONT_HEADING);
        titleLabel.setForeground(ThemeManager.getTheme().getText());

        JLabel messageLabel = new JLabel(message);
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        messageLabel.setFont(UIStyle.FONT_BODY);
        messageLabel.setForeground(ThemeManager.getTheme().getTextMuted());

        add(Box.createVerticalGlue());
        add(titleLabel);
        add(Box.createVerticalStrut(10));
        add(messageLabel);
        add(Box.createVerticalGlue());
    }
}