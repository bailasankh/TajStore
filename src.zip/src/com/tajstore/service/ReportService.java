package com.tajstore.service;

import com.tajstore.dao.ReportDao;
import com.tajstore.model.InventoryReportRow;
import com.tajstore.model.SalesReportRow;
import com.tajstore.model.TopCategoryReportRow;

import java.util.List;

public class ReportService {

    private final ReportDao reportDao;

    public ReportService() {
        this.reportDao = new ReportDao();
    }

    public List<SalesReportRow> getSalesReport(String fromDate, String toDate) {
        validateDate(fromDate, "From date");
        validateDate(toDate, "To date");
        return reportDao.getSalesReport(fromDate, toDate);
    }

    public List<InventoryReportRow> getInventoryReport() {
        return reportDao.getInventoryReport();
    }

    public List<TopCategoryReportRow> getTopCategoryReport() {
        return reportDao.getTopCategoryReport();
    }

    private void validateDate(String date, String fieldName) {
        if (date == null || date.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " is required.");
        }

        if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new IllegalArgumentException(fieldName + " must be in format YYYY-MM-DD.");
        }
    }
}